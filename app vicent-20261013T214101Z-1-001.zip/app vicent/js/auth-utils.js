/**
 * ============================================================================
 * VICENTE IMPORTS - UTILITÁRIOS DE AUTENTICAÇÃO E FORMULÁRIOS
 * 1. Alternância de Visualização de Senha (Ver / Ocultar Senha)
 * 2. Máscara Automática Inteligente de Telefone Brasileiro: (XX) XXXXX-XXXX
 * ============================================================================
 */

(function () {
  /**
   * 1. Alternância de Visualização de Senha
   * Permite que o usuário veja a senha enquanto digita clicando no ícone do olho
   */
  function inicializarToggleSenhas() {
    const buttons = document.querySelectorAll('.btn-toggle-password');
    buttons.forEach((btn) => {
      // Evita registrar múltiplos listeners caso a função seja chamada mais de uma vez
      if (btn.dataset.toggleInitialized) return;
      btn.dataset.toggleInitialized = 'true';

      btn.addEventListener('click', (e) => {
        e.preventDefault();
        const targetId = btn.getAttribute('data-target');
        const input = document.getElementById(targetId);
        if (!input) return;

        const isPass = input.type === 'password';
        input.type = isPass ? 'text' : 'password';

        btn.classList.toggle('active', isPass);
        btn.setAttribute('aria-label', isPass ? 'Ocultar senha' : 'Ver senha');
        btn.setAttribute('title', isPass ? 'Ocultar senha' : 'Ver senha');

        const iconEye = btn.querySelector('.icon-eye');
        const iconEyeOff = btn.querySelector('.icon-eye-off');
        if (iconEye && iconEyeOff) {
          iconEye.style.display = isPass ? 'none' : 'block';
          iconEyeOff.style.display = isPass ? 'block' : 'none';
        }

        // Mantém o foco no campo de texto para continuar a digitação
        input.focus();
      });
    });
  }

  /**
   * 2. Máscara Automática de Telefone Brasileiro
   * Ajusta dinamicamente para fixo (10 dígitos) ou celular (11 dígitos):
   * Ex: (27) 99999-9999 ou (27) 3721-1234
   */
  function formatarTelefoneBR(valor) {
    if (!valor) return '';
    let v = valor.replace(/\D/g, '');
    if (v.length > 11) v = v.substring(0, 11);

    if (v.length === 0) return '';
    if (v.length <= 2) return `(${v}`;
    if (v.length <= 6) return `(${v.substring(0, 2)}) ${v.substring(2)}`;
    if (v.length <= 10) {
      // Formato fixo: (XX) XXXX-XXXX
      return `(${v.substring(0, 2)}) ${v.substring(2, 6)}-${v.substring(6)}`;
    }
    // Formato celular: (XX) XXXXX-XXXX
    return `(${v.substring(0, 2)}) ${v.substring(2, 7)}-${v.substring(7, 11)}`;
  }

  function aplicarMascaraTelefones() {
    const inputs = document.querySelectorAll('input[type="tel"], #modal-reg-tel, #telefone, input[name="telefone"]');
    inputs.forEach((input) => {
      if (input.dataset.maskInitialized) return;
      input.dataset.maskInitialized = 'true';

      input.setAttribute('maxlength', '15');
      if (!input.getAttribute('placeholder')) {
        input.setAttribute('placeholder', '(27) 99999-9999');
      }

      // Aplica formatação caso já venha preenchido (ex: edição de perfil)
      if (input.value) {
        input.value = formatarTelefoneBR(input.value);
      }

      input.addEventListener('input', () => {
        input.value = formatarTelefoneBR(input.value);
      });

      input.addEventListener('paste', () => {
        setTimeout(() => {
          input.value = formatarTelefoneBR(input.value);
        }, 10);
      });
    });
  }

  // Inicializa automaticamente no carregamento do documento
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
      inicializarToggleSenhas();
      aplicarMascaraTelefones();
    });
  } else {
    inicializarToggleSenhas();
    aplicarMascaraTelefones();
  }

  // Exporta globalmente para inicializações dinâmicas
  window.AuthUtils = {
    inicializarToggleSenhas,
    aplicarMascaraTelefones,
    formatarTelefoneBR
  };
})();
