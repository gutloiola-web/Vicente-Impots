/**
 * ============================================================================
 * VICENT IMPORTS - JAVASCRIPT DO PAINEL ADMINISTRATIVO
 * Gerenciamento de modais de edição, confirmações de exclusão e previews
 * ============================================================================
 */

document.addEventListener('DOMContentLoaded', () => {
  // Elementos do Modal de Edição
  const editModalOverlay = document.getElementById('edit-modal-overlay');
  const btnCloseModal = document.getElementById('btn-close-modal');
  const btnCancelModal = document.getElementById('btn-cancel-modal');
  
  // Campos do formulário de edição
  const editId = document.getElementById('edit-id');
  const editNome = document.getElementById('edit-nome');
  const editCategoria = document.getElementById('edit-categoria');
  const editPreco = document.getElementById('edit-preco');
  const editPrecoAntigo = document.getElementById('edit-preco-antigo');
  const editTamanhos = document.getElementById('edit-tamanhos');
  const editImagem = document.getElementById('edit-imagem');
  const editDescricao = document.getElementById('edit-descricao');
  const editDestaque = document.getElementById('edit-destaque');
  const editImagePreview = document.getElementById('edit-image-preview');

  // Preview de imagem do formulário de cadastro
  const addImagemInput = document.getElementById('add-imagem');
  const addImagePreview = document.getElementById('add-image-preview');

  /**
   * 1. Abertura e Preenchimento do Modal de Edição
   */
  const editButtons = document.querySelectorAll('.btn-action-edit');
  editButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      // Coleta dados dos atributos do botão
      const id = btn.getAttribute('data-id');
      const nome = btn.getAttribute('data-nome');
      const categoria = btn.getAttribute('data-categoria');
      const preco = btn.getAttribute('data-preco');
      const precoAntigo = btn.getAttribute('data-preco-antigo');
      const tamanhos = btn.getAttribute('data-tamanhos');
      const imagem = btn.getAttribute('data-imagem');
      const descricao = btn.getAttribute('data-descricao');
      const destaque = btn.getAttribute('data-destaque');
      const esgotado = btn.getAttribute('data-esgotado') === '1';

      // Preenche o formulário modal
      if (editId) editId.value = id;
      if (editNome) editNome.value = nome;
      if (editCategoria) editCategoria.value = categoria;
      if (editPreco) editPreco.value = preco;
      if (editPrecoAntigo) editPrecoAntigo.value = precoAntigo || '';
      if (editTamanhos) editTamanhos.value = tamanhos;
      if (editDescricao) editDescricao.value = descricao;
      if (editDestaque) editDestaque.value = destaque;
      const editEsgotado = document.getElementById('edit-esgotado');
      if (editEsgotado) editEsgotado.checked = esgotado;

      // Carrega fotos da galeria (até 4 fotos)
      const galeriaRaw = btn.getAttribute('data-galeria');
      let galeria = [];
      try {
        galeria = galeriaRaw ? JSON.parse(galeriaRaw) : [];
      } catch (e) {
        galeria = [];
      }
      if (!Array.isArray(galeria) || galeria.length === 0) {
        if (imagem) galeria = [imagem];
      }

      for (let i = 1; i <= 4; i++) {
        const inpUrl = document.getElementById(`edit-imagem-${i}`);
        const inpHidden = document.getElementById(`edit-foto-existente-${i}`);
        const inpFile = document.getElementById(`edit-upload-${i}`);
        const prevImg = document.getElementById(`edit-preview-${i}`);
        if (inpFile) inpFile.value = '';
        const urlFoto = galeria[i - 1] || '';
        if (inpUrl) inpUrl.value = urlFoto;
        if (inpHidden) inpHidden.value = urlFoto;
        if (prevImg) {
          if (urlFoto) {
            prevImg.src = urlFoto;
            prevImg.style.display = 'block';
          } else {
            prevImg.src = '';
            prevImg.style.display = 'none';
          }
        }
      }

      // Exibe o modal
      if (editModalOverlay) {
        editModalOverlay.classList.add('active');
        document.body.style.overflow = 'hidden';
      }
    });
  });

  /**
   * 2. Fechamento do Modal
   */
  function fecharModal() {
    if (editModalOverlay) {
      editModalOverlay.classList.remove('active');
      document.body.style.overflow = '';
    }
  }

  if (btnCloseModal) btnCloseModal.addEventListener('click', fecharModal);
  if (btnCancelModal) btnCancelModal.addEventListener('click', fecharModal);
  
  if (editModalOverlay) {
    editModalOverlay.addEventListener('click', (e) => {
      if (e.target === editModalOverlay) {
        fecharModal();
      }
    });
  }

  // Tecla ESC fecha modal
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && editModalOverlay && editModalOverlay.classList.contains('active')) {
      fecharModal();
    }
  });

  /**
   * 3. Confirmação de Exclusão de Produto
   */
  const deleteButtons = document.querySelectorAll('.btn-action-delete');
  deleteButtons.forEach(btn => {
    btn.addEventListener('click', (e) => {
      const nome = btn.getAttribute('data-nome') || 'este produto';
      const confirmacao = confirm(`⚠️ Confirmação de Exclusão:\n\nTem certeza de que deseja excluir "${nome}" do catálogo da Vicent Imports?\n\nEsta ação removerá o produto do produtos.json imediatamente.`);
      
      if (!confirmacao) {
        e.preventDefault();
      }
    });
  });

  /**
   * 4. Previews Dinâmicos de Imagem para os 4 Slots (URL e Arquivo)
   */
  ['add', 'edit'].forEach(prefix => {
    for (let i = 1; i <= 4; i++) {
      const urlInput = document.getElementById(`${prefix}-imagem-${i}`);
      const fileInput = document.getElementById(`${prefix}-upload-${i}`);
      const preview = document.getElementById(`${prefix}-preview-${i}`);

      if (urlInput && preview) {
        urlInput.addEventListener('input', () => {
          const val = urlInput.value.trim();
          if (val.startsWith('http://') || val.startsWith('https://') || val.startsWith('images/')) {
            preview.src = val;
            preview.style.display = 'block';
          } else if (!val && (!fileInput || !fileInput.files || !fileInput.files.length)) {
            preview.style.display = 'none';
          }
        });
      }

      if (fileInput && preview) {
        fileInput.addEventListener('change', () => {
          if (fileInput.files && fileInput.files[0]) {
            const reader = new FileReader();
            reader.onload = (e) => {
              preview.src = e.target.result;
              preview.style.display = 'block';
            };
            reader.readAsDataURL(fileInput.files[0]);
          }
        });
      }
    }
  });

  /**
   * 5. Fechamento automático de alertas após 5 segundos
   */
  const alerts = document.querySelectorAll('.admin-alert');
  alerts.forEach(alertEl => {
    setTimeout(() => {
      alertEl.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
      alertEl.style.opacity = '0';
      alertEl.style.transform = 'translateY(-10px)';
      setTimeout(() => alertEl.remove(), 500);
    }, 5000);
  });

  /**
   * 6. Filtro em tempo real de usuários cadastrados
   */
  const filtroUsuarios = document.getElementById('filtro-usuarios');
  if (filtroUsuarios) {
    filtroUsuarios.addEventListener('input', () => {
      const termo = filtroUsuarios.value.toLowerCase().trim();
      const linhas = document.querySelectorAll('#tabela-usuarios-lista tbody tr.user-row');
      
      linhas.forEach(linha => {
        const textoLinha = linha.textContent.toLowerCase();
        linha.style.display = textoLinha.includes(termo) ? '' : 'none';
      });
    });
  }

  /**
   * 7. Confirmação de Exclusão de Conta de Usuário
   */
  const deleteUserButtons = document.querySelectorAll('.btn-action-delete-user');
  deleteUserButtons.forEach(btn => {
    btn.addEventListener('click', (e) => {
      const nome = btn.getAttribute('data-nome') || 'este usuário';
      const confirmacao = confirm(`⚠️ Confirmação de Exclusão de Conta:\n\nTem certeza de que deseja remover permanentemente o cadastro de "${nome}"?\n\nEsta ação removerá a conta do usuarios.json.`);
      
      if (!confirmacao) {
        e.preventDefault();
      }
    });
  });

  /**
   * 8. Visualização Completa dos Dados do Usuário (Modal de Ficha Cadastral)
   */
  const userModalOverlay = document.getElementById('user-modal-overlay');
  const btnCloseUserModal = document.getElementById('btn-close-user-modal');
  const btnCancelUserModal = document.getElementById('btn-cancel-user-modal');

  const modalUserAvatar = document.getElementById('modal-user-avatar');
  const modalUserNome = document.getElementById('modal-user-nome');
  const modalUserBadge = document.getElementById('modal-user-badge');
  const modalUserUsername = document.getElementById('modal-user-username');
  const modalUserId = document.getElementById('modal-user-id');
  const modalUserRole = document.getElementById('modal-user-role');
  const modalUserEmailLink = document.getElementById('modal-user-email-link');
  const modalUserTelefone = document.getElementById('modal-user-telefone');
  const modalUserData = document.getElementById('modal-user-data');
  const modalBtnWhatsapp = document.getElementById('modal-btn-whatsapp');
  const modalBtnEmail = document.getElementById('modal-btn-email');
  const btnCopyEmail = document.getElementById('btn-copy-email');
  const btnCopyTel = document.getElementById('btn-copy-tel');

  let currentEmail = '';
  let currentTel = '';

  function fecharUserModal() {
    if (userModalOverlay) {
      userModalOverlay.classList.remove('active');
      document.body.style.overflow = '';
    }
  }

  if (btnCloseUserModal) btnCloseUserModal.addEventListener('click', fecharUserModal);
  if (btnCancelUserModal) btnCancelUserModal.addEventListener('click', fecharUserModal);

  if (userModalOverlay) {
    userModalOverlay.addEventListener('click', (e) => {
      if (e.target === userModalOverlay) {
        fecharUserModal();
      }
    });
  }

  // Tecla ESC fecha qualquer modal aberto
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && userModalOverlay && userModalOverlay.classList.contains('active')) {
      fecharUserModal();
    }
  });

  // Abertura do modal ao clicar em "Ver Dados"
  const viewUserButtons = document.querySelectorAll('.btn-action-view-user');
  viewUserButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      const id = btn.getAttribute('data-id') || '-';
      const nome = btn.getAttribute('data-nome') || 'Usuário';
      const usuario = btn.getAttribute('data-usuario') || '';
      const email = btn.getAttribute('data-email') || '';
      const telefone = btn.getAttribute('data-telefone') || '';
      const role = btn.getAttribute('data-role') || 'cliente';
      const data = btn.getAttribute('data-data') || 'Data não informada';
      const isAdmin = btn.getAttribute('data-is-admin') === '1' || role === 'admin';

      currentEmail = email;
      currentTel = telefone;

      // Atualiza Avatar e Inicial
      if (modalUserAvatar) {
        modalUserAvatar.textContent = (nome.trim().charAt(0) || 'U').toUpperCase();
        if (isAdmin) {
          modalUserAvatar.classList.add('admin-avatar');
        } else {
          modalUserAvatar.classList.remove('admin-avatar');
        }
      }

      // Nome e Badge
      if (modalUserNome) modalUserNome.textContent = nome;
      if (modalUserBadge) {
        if (isAdmin) {
          modalUserBadge.className = 'badge-tag highlight';
          modalUserBadge.textContent = 'Administrador';
        } else {
          modalUserBadge.className = 'badge-tag';
          modalUserBadge.style.backgroundColor = 'rgba(16, 185, 129, 0.12)';
          modalUserBadge.style.color = 'var(--admin-success)';
          modalUserBadge.style.borderColor = 'rgba(16, 185, 129, 0.25)';
          modalUserBadge.textContent = 'Cliente';
        }
      }

      // Nome de usuário (@login)
      if (modalUserUsername) {
        modalUserUsername.textContent = usuario ? `@${usuario}` : 'Conta de cliente (sem @login)';
      }

      // ID e Nível
      if (modalUserId) modalUserId.textContent = `#${id}`;
      if (modalUserRole) {
        modalUserRole.textContent = isAdmin ? 'Administrador Master' : 'Cliente da Loja';
      }

      // E-mail
      if (modalUserEmailLink) {
        modalUserEmailLink.textContent = email || 'Não informado';
        modalUserEmailLink.href = email ? `mailto:${email}` : '#';
      }

      // Telefone
      if (modalUserTelefone) {
        modalUserTelefone.textContent = telefone || 'Não informado';
      }

      // Data de cadastro
      if (modalUserData) {
        modalUserData.textContent = data;
      }

      // Botão de Enviar E-mail
      if (modalBtnEmail) {
        if (email) {
          modalBtnEmail.href = `mailto:${email}?subject=${encodeURIComponent('Contato Vicente Imports')}`;
          modalBtnEmail.style.display = 'inline-flex';
        } else {
          modalBtnEmail.style.display = 'none';
        }
      }

      // Botão de WhatsApp
      if (modalBtnWhatsapp) {
        const telNumeros = telefone.replace(/\D/g, '');
        if (telNumeros.length >= 10) {
          const saudacao = encodeURIComponent(`Olá ${nome}, tudo bem? Sou da equipe Vicente Imports.`);
          modalBtnWhatsapp.href = `https://wa.me/55${telNumeros}?text=${saudacao}`;
          modalBtnWhatsapp.style.display = 'inline-flex';
        } else {
          modalBtnWhatsapp.style.display = 'none';
        }
      }

      // Exibe modal
      if (userModalOverlay) {
        userModalOverlay.classList.add('active');
        document.body.style.overflow = 'hidden';
      }
    });
  });

  // Função auxiliar para copiar texto para área de transferência
  function copiarTexto(texto, btnElement, labelPadrao) {
    if (!texto) return;
    navigator.clipboard.writeText(texto).then(() => {
      const copySpan = btnElement.querySelector('.copy-text') || btnElement;
      const originalHtml = copySpan.innerHTML;
      copySpan.innerHTML = '✓ Copiado!';
      btnElement.style.color = 'var(--admin-success)';
      setTimeout(() => {
        copySpan.innerHTML = originalHtml;
        btnElement.style.color = '';
      }, 2000);
    }).catch(() => {
      // Fallback manual
      const tempInput = document.createElement('textarea');
      tempInput.value = texto;
      document.body.appendChild(tempInput);
      tempInput.select();
      document.execCommand('copy');
      document.body.removeChild(tempInput);
      const copySpan = btnElement.querySelector('.copy-text') || btnElement;
      copySpan.innerHTML = '✓ Copiado!';
      setTimeout(() => {
        copySpan.innerHTML = labelPadrao;
      }, 2000);
    });
  }

  if (btnCopyEmail) {
    btnCopyEmail.addEventListener('click', () => {
      copiarTexto(currentEmail, btnCopyEmail, 'Copiar');
    });
  }

  if (btnCopyTel) {
    btnCopyTel.addEventListener('click', () => {
      copiarTexto(currentTel, btnCopyTel, 'Copiar');
    });
  }

  /**
   * 9. Teste de Conexão com Mercado Pago
   */
  const btnTestarMp = document.getElementById('btn-testar-mp-token');
  const inputMpToken = document.getElementById('mp-access-token');
  const feedbackMp = document.getElementById('mp-test-feedback');

  if (btnTestarMp && inputMpToken && feedbackMp) {
    btnTestarMp.addEventListener('click', async () => {
      const token = inputMpToken.value.trim();
      if (!token) {
        feedbackMp.style.display = 'block';
        feedbackMp.style.background = 'rgba(239, 68, 68, 0.15)';
        feedbackMp.style.border = '1px solid rgba(239, 68, 68, 0.3)';
        feedbackMp.style.color = '#ef4444';
        feedbackMp.innerHTML = '⚠️ Por favor, cole o seu Access Token no campo acima antes de testar.';
        return;
      }

      btnTestarMp.disabled = true;
      btnTestarMp.innerHTML = '<span class="material-symbols-outlined" style="font-size:16px;">sync</span> Testando...';
      feedbackMp.style.display = 'none';

      try {
        const res = await fetch('index.php?api=testar_mp', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ token })
        });
        const data = await res.json();

        feedbackMp.style.display = 'block';
        if (data.success && data.user) {
          if (data.user.is_test_user) {
            feedbackMp.style.background = 'rgba(245, 158, 11, 0.15)';
            feedbackMp.style.border = '1px solid rgba(245, 158, 11, 0.3)';
            feedbackMp.style.color = '#f59e0b';
            feedbackMp.innerHTML = `
              <strong>⚠️ Atenção: Este token pertence a uma Conta de Teste gerada no Mercado Pago:</strong><br>
              &bull; Usuário: <strong>${data.user.nickname || data.user.email}</strong><br>
              &bull; Pix Disponível: <strong>${data.user.pix_disponivel ? 'Sim' : 'Não (contas de teste sem chave Pix)'}</strong><br>
              <em>Para receber pagamentos reais com Pix oficial do Banco Central, use as <strong>Credenciais de Produção</strong> da sua aplicação principal (e complete a ativação no painel do Mercado Pago).</em>
            `;
          } else {
            feedbackMp.style.background = 'rgba(16, 185, 129, 0.15)';
            feedbackMp.style.border = '1px solid rgba(16, 185, 129, 0.3)';
            feedbackMp.style.color = '#10b981';
            feedbackMp.innerHTML = `
              <strong>✅ Conexão Estabelecida com o Mercado Pago!</strong><br>
              &bull; Conta: <strong>${data.user.nickname || data.user.email}</strong><br>
              &bull; Pix Disponível: <strong>${data.user.pix_disponivel ? 'Sim (Pronto para receber dinheiro real)' : 'Aguardando chave Pix configurada na sua conta Mercado Pago'}</strong>
            `;
          }
        } else {
          feedbackMp.style.background = 'rgba(239, 68, 68, 0.15)';
          feedbackMp.style.border = '1px solid rgba(239, 68, 68, 0.3)';
          feedbackMp.style.color = '#ef4444';
          feedbackMp.innerHTML = `<strong>❌ Erro retornado pelo Mercado Pago:</strong><br>${data.message || 'Credencial não autorizada.'}`;
        }
      } catch (err) {
        feedbackMp.style.display = 'block';
        feedbackMp.style.background = 'rgba(239, 68, 68, 0.15)';
        feedbackMp.style.border = '1px solid rgba(239, 68, 68, 0.3)';
        feedbackMp.style.color = '#ef4444';
        feedbackMp.innerHTML = '❌ Erro ao tentar conectar ao servidor. Tente novamente.';
      } finally {
        btnTestarMp.disabled = false;
        btnTestarMp.innerHTML = '<span class="material-symbols-outlined" style="font-size: 16px;">bolt</span> Testar Conexão';
      }
    });
  }
});


