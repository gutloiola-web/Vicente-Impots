/**
 * ============================================================================
 * VICENT IMPORTS - FRONT-END JAVASCRIPT (CLEAN / NEXO STORE DESIGN)
 * Responsável pela vitrine dinâmica, filtros, busca, menu mobile e carrinho
 * ============================================================================
 */

document.addEventListener('DOMContentLoaded', () => {
  // Elementos do DOM
  const productsContainer = document.getElementById('products-container');
  const searchInput = document.getElementById('search-input');
  const categoryFilters = document.getElementById('category-filters');
  const productCount = document.getElementById('product-count');
  const cartBtn = document.getElementById('cart-btn');
  const cartCounter = document.getElementById('cart-counter');
  
  // Elementos do Carrinho Lateral (Drawer)
  const drawerBtnOpenCart = document.getElementById('drawer-btn-open-cart');
  const drawerCartCounter = document.getElementById('drawer-cart-counter');
  const cartDrawer = document.getElementById('cart-drawer');
  const cartDrawerOverlay = document.getElementById('cart-drawer-overlay');
  const btnCloseCart = document.getElementById('btn-close-cart');
  const cartDrawerBody = document.getElementById('cart-drawer-body');
  const cartDrawerCount = document.getElementById('cart-drawer-count');
  const cartSubtotalVal = document.getElementById('cart-subtotal-val');
  const btnCheckoutWhatsapp = document.getElementById('btn-checkout-whatsapp');
  const btnClearCart = document.getElementById('btn-clear-cart');

  // Elementos do Menu Mobile (Drawer)
  const mobileMenuBtn = document.getElementById('mobile-menu-btn');
  const drawerOverlay = document.getElementById('drawer-overlay');
  const mobileDrawer = document.getElementById('mobile-drawer');
  const drawerClose = document.getElementById('drawer-close');

  // Elementos de Favoritos (Wishlist)
  const wishlistBtn = document.getElementById('wishlist-btn');
  const wishlistCounter = document.getElementById('wishlist-counter');
  const drawerBtnOpenWishlist = document.getElementById('drawer-btn-open-wishlist');
  const drawerWishlistCounter = document.getElementById('drawer-wishlist-counter');
  const wishlistDrawer = document.getElementById('wishlist-drawer');
  const wishlistDrawerOverlay = document.getElementById('wishlist-drawer-overlay');
  const btnCloseWishlist = document.getElementById('btn-close-wishlist');
  const wishlistDrawerBody = document.getElementById('wishlist-drawer-body');
  const wishlistDrawerCount = document.getElementById('wishlist-drawer-count');
  const btnClearWishlist = document.getElementById('btn-clear-wishlist');

  // Elementos de Filtros Avançados
  const filterPrice = document.getElementById('filter-price');
  const sizeFilterPills = document.getElementById('size-filter-pills');
  const btnClearFilters = document.getElementById('btn-clear-filters');

  // Elementos do Modal Quick View (Espiada Rápida & Zoom)
  const quickviewModalOverlay = document.getElementById('quickview-modal-overlay');
  const btnCloseQuickview = document.getElementById('btn-close-quickview');
  const qvZoomContainer = document.getElementById('qv-zoom-container');
  const qvMainImg = document.getElementById('qv-main-img');
  const qvThumbnails = document.getElementById('qv-thumbnails');
  const qvCategory = document.getElementById('qv-category');
  const qvBadge = document.getElementById('qv-badge');
  const qvTitle = document.getElementById('qv-title');
  const qvPrice = document.getElementById('qv-price');
  const qvDescription = document.getElementById('qv-description');
  const qvSizePicker = document.getElementById('qv-size-picker');
  const qvBtnBuy = document.getElementById('qv-btn-buy');
  const qvBtnWishlist = document.getElementById('qv-btn-wishlist');
  const qvWishlistIcon = document.getElementById('qv-wishlist-icon');

  // Estado da Aplicação
  let allProducts = [];
  let currentCategory = 'todos';
  let searchTerm = '';
  let currentSort = 'destaques';
  let currentPrice = 'todos';
  let currentSize = 'todos';
  let currentQuickViewProduct = null;
  let currentQuickViewSelectedSize = '';

  // Chave de armazenamento exclusiva da sacola de compras para cada conta de usuário
  function getCartStorageKey() {
    const isLogged = document.body.getAttribute('data-user-logged') === 'true';
    const isAdmin = document.body.getAttribute('data-is-admin') === 'true';
    const userId = document.body.getAttribute('data-user-id');
    if (isLogged && !isAdmin && userId && userId !== '0' && userId !== 'admin') {
      return `vicente_imports_cart_user_${userId}`;
    }
    if (isLogged && isAdmin) {
      return 'vicente_imports_cart_admin';
    }
    return 'vicente_imports_cart_guest';
  }

  let cart = [];
  function carregarCarrinhoLocal() {
    try {
      // Limpeza da chave global legada compartilhada se existir
      if (localStorage.getItem('vicente_imports_cart')) {
        localStorage.removeItem('vicente_imports_cart');
      }
      const key = getCartStorageKey();
      const salvo = localStorage.getItem(key);
      cart = salvo ? JSON.parse(salvo) : [];
      if (!Array.isArray(cart)) cart = [];
    } catch (e) {
      cart = [];
    }
  }
  carregarCarrinhoLocal();

  // Sincroniza carrinho salvo no backend (usuarios.json) com a conta logada
  function sincronizarCarrinhoComServidor() {
    const isLogged = document.body.getAttribute('data-user-logged') === 'true';
    const isAdmin = document.body.getAttribute('data-is-admin') === 'true';
    if (!isLogged || isAdmin) return;

    fetch('index.php?api=carrinho')
      .then(res => res.json())
      .then(data => {
        if (data.success && Array.isArray(data.carrinho)) {
          const key = getCartStorageKey();
          if (cart.length === 0 && data.carrinho.length > 0) {
            cart = data.carrinho;
            try {
              localStorage.setItem(key, JSON.stringify(cart));
            } catch (e) {}
            atualizarContadores();
            if (cartDrawer && cartDrawer.classList.contains('active')) {
              renderizarCarrinho();
            }
          } else if (cart.length > 0 && (!data.carrinho || data.carrinho.length === 0)) {
            salvarCarrinho();
          }
        }
      })
      .catch(() => {});
  }
  sincronizarCarrinhoComServidor();


  // Chave de armazenamento exclusiva para cada conta de usuário
  function getWishlistStorageKey() {
    const isLogged = document.body.getAttribute('data-user-logged') === 'true';
    const isAdmin = document.body.getAttribute('data-is-admin') === 'true';
    const userId = document.body.getAttribute('data-user-id');
    if (isLogged && !isAdmin && userId && userId !== '0' && userId !== 'admin') {
      return `vicente_imports_wishlist_user_${userId}`;
    }
    return 'vicente_imports_wishlist_guest';
  }

  let wishlist = [];
  function carregarWishlistLocal() {
    try {
      const key = getWishlistStorageKey();
      const wSalvo = localStorage.getItem(key);
      wishlist = wSalvo ? JSON.parse(wSalvo) : [];
    } catch (e) {
      wishlist = [];
    }
  }
  carregarWishlistLocal();

  // Sincroniza favoritos salvos no backend (usuarios.json) com a conta logada
  function sincronizarFavoritosComServidor() {
    const isLogged = document.body.getAttribute('data-user-logged') === 'true';
    const isAdmin = document.body.getAttribute('data-is-admin') === 'true';
    if (!isLogged || isAdmin) return;

    fetch('index.php?api=favoritos')
      .then(res => res.json())
      .then(data => {
        if (data.success && Array.isArray(data.favoritos)) {
          if (wishlist.length === 0 && data.favoritos.length > 0) {
            wishlist = data.favoritos;
            try {
              localStorage.setItem(getWishlistStorageKey(), JSON.stringify(wishlist));
            } catch (e) {}
            atualizarWishlistUI();
          } else if (wishlist.length > 0 && (!data.favoritos || data.favoritos.length === 0)) {
            salvarWishlist();
          }
        }
      })
      .catch(() => {});
  }
  sincronizarFavoritosComServidor();

  /**
   * 1. Controle do Menu Gaveta Mobile (Drawer)
   */
  function abrirMenuMobile() {
    mobileDrawer.classList.add('active');
    drawerOverlay.classList.add('active');
    document.body.style.overflow = 'hidden';
  }

  function fecharMenuMobile() {
    mobileDrawer.classList.remove('active');
    drawerOverlay.classList.remove('active');
    document.body.style.overflow = '';
  }

  if (mobileMenuBtn) mobileMenuBtn.addEventListener('click', abrirMenuMobile);
  if (drawerClose) drawerClose.addEventListener('click', fecharMenuMobile);
  if (drawerOverlay) drawerOverlay.addEventListener('click', fecharMenuMobile);

  /**
   * 2. Consumo dos dados do backend PHP
   * O endpoint 'index.php?api=produtos' lê produtos.json e responde com JSON
   */
  async function carregarProdutos() {
    try {
      productsContainer.innerHTML = `
        <div class="loading-state">
          <div class="spinner"></div>
          <p>Buscando peças exclusivas da Vicent Imports...</p>
        </div>
      `;

      const response = await fetch('index.php?api=produtos');

      if (!response.ok) {
        throw new Error(`Erro HTTP: ${response.status}`);
      }

      const data = await response.json();
      allProducts = data;

      // Renderiza os produtos e configura abas e filtros
      renderizarVitrine();
      configurarAbasCategorias();
      configurarFiltrosAvancados();
      atualizarWishlistUI();

    } catch (error) {
      console.error('Erro ao carregar catálogo:', error);
      productsContainer.innerHTML = `
        <div class="empty-state">
          <p style="color: #dc2626; font-weight: 700; margin-bottom: 8px;">Falha na conexão com o servidor local.</p>
          <p style="font-size: 0.85rem;">Certifique-se de que o PHP está em execução (XAMPP/WAMP ou servidor embutido).</p>
        </div>
      `;
    }
  }

  /**
   * 3. Renderização Dinâmica da Vitrine de Produtos (Grid) com Filtros Avançados
   */
  function renderizarVitrine() {
    // 1. Filtragem combinada: Categoria, Busca, Faixa de Preço e Tamanho
    const filtrados = allProducts.filter(item => {
      // Categoria
      const catProd = (item.categoria || '').toLowerCase().trim();
      const catAtiva = currentCategory.toLowerCase().trim();
      const bateCategoria = (catAtiva === 'todos') || 
                            (catProd === catAtiva) ||
                            (catAtiva === 'chinelo' && catProd === 'chinelos') ||
                            (catAtiva === 'chinelos' && catProd === 'chinelo') ||
                            (catAtiva === 'cueca' && catProd === 'cuecas') ||
                            (catAtiva === 'cuecas' && catProd === 'cueca');

      // Busca por texto
      const termo = searchTerm.toLowerCase();
      const bateBusca = item.nome.toLowerCase().includes(termo) ||
                        item.categoria.toLowerCase().includes(termo) ||
                        (item.descricao && item.descricao.toLowerCase().includes(termo));

      // Faixa de Preço
      const precoNum = parseFloat(item.preco) || 0;
      let batePreco = true;
      if (currentPrice === 'ate-80') {
        batePreco = precoNum <= 80;
      } else if (currentPrice === '80-100') {
        batePreco = precoNum >= 80 && precoNum <= 100;
      } else if (currentPrice === 'acima-100') {
        batePreco = precoNum > 100;
      }

      // Tamanho disponível
      let bateTamanho = true;
      if (currentSize !== 'todos') {
        const tams = (item.tamanhos || []).map(t => String(t).toUpperCase().trim());
        bateTamanho = tams.includes(currentSize.toUpperCase().trim());
      }

      return bateCategoria && bateBusca && batePreco && bateTamanho;
    });

    // 2. Ordenação Dinâmica
    if (currentSort === 'preco-crescente') {
      filtrados.sort((a, b) => parseFloat(a.preco) - parseFloat(b.preco));
    } else if (currentSort === 'preco-decrescente') {
      filtrados.sort((a, b) => parseFloat(b.preco) - parseFloat(a.preco));
    } else if (currentSort === 'nome-az') {
      filtrados.sort((a, b) => a.nome.localeCompare(b.nome));
    } else {
      // Padrão: Destaques & Mais Vendidos primeiro
      filtrados.sort((a, b) => {
        const temDestaqueA = Boolean(a.destaque && String(a.destaque).trim() !== '');
        const temDestaqueB = Boolean(b.destaque && String(b.destaque).trim() !== '');
        if (temDestaqueA && !temDestaqueB) return -1;
        if (!temDestaqueA && temDestaqueB) return 1;
        return 0;
      });
    }

    // Atualiza o contador de itens encontrados
    if (productCount) {
      const plural = filtrados.length === 1 ? 'peça encontrada' : 'peças encontradas';
      productCount.textContent = `${filtrados.length} ${plural}`;
    }

    // Se nenhum item atender aos filtros
    if (filtrados.length === 0) {
      productsContainer.innerHTML = `
        <div class="empty-state">
          <h3 style="margin-bottom: 6px; font-weight: 800;">Nenhum produto encontrado</h3>
          <p>Tente alterar os filtros de preço, tamanho ou categoria para ver mais peças.</p>
        </div>
      `;
      return;
    }

    // Monta os cards dos produtos em Grid
    productsContainer.innerHTML = filtrados.map(produto => {
      const precoNum = parseFloat(produto.preco) || 0;
      const precoAntigoNum = produto.preco_antigo ? parseFloat(produto.preco_antigo) : 0;
      const temDesconto = precoAntigoNum > precoNum;
      const pctDesconto = temDesconto ? Math.round(((precoAntigoNum - precoNum) / precoAntigoNum) * 100) : 0;

      // Formatação monetária BRL
      const precoBRL = precoNum.toLocaleString('pt-BR', {
        style: 'currency',
        currency: 'BRL'
      });
      const precoAntigoBRL = precoAntigoNum.toLocaleString('pt-BR', {
        style: 'currency',
        currency: 'BRL'
      });

      // Tamanhos disponíveis
      const tamanhosHtml = produto.tamanhos && Array.isArray(produto.tamanhos)
        ? produto.tamanhos.map((tam, idx) => `
            <button type="button" class="size-pill ${idx === 0 ? 'selected' : ''}" data-size="${tam}">
              ${tam}
            </button>
          `).join('')
        : '';

      // Galeria e Foto Secundária (Hover Frente/Costas)
      const galeria = produto.galeria && Array.isArray(produto.galeria) && produto.galeria.length > 0
        ? produto.galeria
        : [produto.imagem];

      const secondaryImgHtml = galeria.length > 1
        ? `<img src="${galeria[1]}" alt="${produto.nome} - Costas" class="card-img-secondary" loading="lazy">`
        : '';

      const isFavorito = wishlist.some(w => String(w.id) === String(produto.id));
      const isAdmin = document.body.getAttribute('data-is-admin') === 'true';

      const wishlistBtnHtml = isAdmin ? '' : `
        <!-- Botão de Favoritar no Card -->
        <button 
          type="button" 
          class="card-wishlist-btn ${isFavorito ? 'active' : ''}" 
          data-id="${produto.id}" 
          title="${isFavorito ? 'Remover dos favoritos' : 'Favoritar este item'}"
          aria-label="Favoritar"
        >
          <span class="material-symbols-outlined" style="font-size: 20px;">favorite</span>
        </button>
      `;

      const isEsgotado = !!produto.esgotado;

      return `
        <article class="product-card ${isEsgotado ? 'esgotado' : ''}" data-id="${produto.id}">
          
          <!-- Imagem do Produto com Efeito de Hover, Favorito e Espiada Rápida -->
          <div class="card-media-wrap" data-id="${produto.id}" title="Clique para espiada rápida com zoom">
            <img src="${produto.imagem}" alt="${produto.nome}" class="card-img" loading="lazy">
            ${secondaryImgHtml}
            ${isEsgotado ? '<span class="card-badge-esgotado">ESGOTADO</span>' : (produto.destaque ? `<span class="card-badge">${produto.destaque}</span>` : '')}
            ${temDesconto ? `<span class="card-discount-badge" title="${pctDesconto}% de desconto!">-${pctDesconto}% OFF</span>` : ''}
            <span class="card-category-tag">${produto.categoria}</span>

            ${wishlistBtnHtml}

            <!-- Botão de Espiada Rápida / Quick View -->
            <button type="button" class="btn-card-quickview" data-id="${produto.id}">
              <span class="material-symbols-outlined" style="font-size: 16px;">visibility</span>
              Espiada Rápida
            </button>
          </div>

          <!-- Informações e Ações do Card -->
          <div class="card-info">
            <h3 class="card-title">${produto.nome}</h3>
            ${produto.descricao ? `<p class="card-description">${produto.descricao}</p>` : ''}

            <!-- Seleção de Tamanho -->
            <div class="size-picker" aria-label="Tamanhos disponíveis">
              ${tamanhosHtml}
            </div>

            <!-- Preço com Preço Antigo e Tag de Desconto -->
            <div class="price-block">
              ${temDesconto ? `<span class="price-old">De ${precoAntigoBRL}</span>` : ''}
              <div class="price-row">
                <span class="price-main">${temDesconto ? `Por ${precoBRL}` : precoBRL}</span>
                ${temDesconto ? `<span class="price-discount-pill">-${pctDesconto}%</span>` : ''}
              </div>
            </div>

            <!-- Botão de Comprar ou Esgotado -->
            ${isEsgotado ? `
              <button 
                type="button" 
                class="btn-buy-full btn-buy-disabled" 
                disabled
                data-id="${produto.id}"
                title="Esta peça está esgotada no momento"
              >
                <span class="material-symbols-outlined" style="font-size: 18px; margin-right: 4px;">block</span>
                Esgotado
              </button>
            ` : `
              <button 
                type="button" 
                class="btn-buy-full" 
                data-id="${produto.id}" 
                data-name="${produto.nome}" 
                data-price="${precoBRL}"
              >
                <span class="material-symbols-outlined" style="font-size: 18px; margin-right: 4px;">shopping_bag</span>
                Comprar
              </button>
            `}

          </div>

        </article>
      `;
    }).join('');

    // Reanexa eventos interativos
    vincularEventosCards();
  }

  /**
   * 4. Configuração das Abas e Links de Categoria
   */
  function configurarAbasCategorias() {
    // Abas de categorias no catálogo
    const tabButtons = document.querySelectorAll('.tab-btn');
    tabButtons.forEach(btn => {
      btn.addEventListener('click', () => {
        tabButtons.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        currentCategory = btn.getAttribute('data-category');
        renderizarVitrine();
      });
    });

    // Links de navegação do menu superior e drawer que filtram categoria
    const navCategoryLinks = document.querySelectorAll('.filter-nav');
    navCategoryLinks.forEach(link => {
      link.addEventListener('click', (e) => {
        const cat = link.getAttribute('data-category');
        if (cat) {
          currentCategory = cat;
          
          // Atualiza também a aba visual
          tabButtons.forEach(b => {
            if (b.getAttribute('data-category').toLowerCase() === cat.toLowerCase()) {
              b.classList.add('active');
            } else {
              b.classList.remove('active');
            }
          });

          renderizarVitrine();
          fecharMenuMobile();
        }
      });
    });
  }

  /**
   * 5. Eventos nos Cards: Seleção de Tamanho, Favoritar, Espiada Rápida & Compra
   */
  function vincularEventosCards() {
    // Seleção de tamanho por clique nas pílulas
    document.querySelectorAll('.product-card').forEach(card => {
      const sizePills = card.querySelectorAll('.size-pill');
      sizePills.forEach(pill => {
        pill.addEventListener('click', (e) => {
          e.stopPropagation();
          sizePills.forEach(p => p.classList.remove('selected'));
          pill.classList.add('selected');
        });
      });
    });

    // Botão de Favoritar no Card
    document.querySelectorAll('.card-wishlist-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const id = btn.getAttribute('data-id');
        toggleWishlist(id);
      });
    });

    // Espiada Rápida / Quick View ao clicar na foto ou no botão de espiada
    document.querySelectorAll('.card-media-wrap').forEach(wrap => {
      wrap.addEventListener('click', (e) => {
        // Se clicou no botão de favoritar, não abre o quickview
        if (e.target.closest('.card-wishlist-btn')) return;
        const id = wrap.getAttribute('data-id');
        abrirQuickView(id);
      });
    });

    // Botão de Comprar: Adiciona a peça ao carrinho e abre a sacola
    document.querySelectorAll('.btn-buy-full').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        if (btn.disabled || btn.classList.contains('btn-buy-disabled')) {
          return;
        }

        // 🔒 Verificação Obrigatória: Apenas usuários logados podem adicionar peças à sacola
        const isLogged = document.body.getAttribute('data-user-logged') === 'true';
        if (!isLogged) {
          abrirModalAuth('login');
          exibirAlertaModal('🔒 Você precisa entrar ou criar uma conta para adicionar peças à sua sacola!', 'error');
          return;
        }

        const id = btn.getAttribute('data-id');
        const nome = btn.getAttribute('data-name');
        
        const card = btn.closest('.product-card');
        const pillSelecionada = card ? card.querySelector('.size-pill.selected') : null;
        const tamanho = pillSelecionada ? pillSelecionada.getAttribute('data-size') : 'Padrão';
        const imgEl = card ? card.querySelector('.card-img') : null;
        const imagem = imgEl ? imgEl.getAttribute('src') : 'images/logo.png';

        // Procura produto no catálogo para pegar o preço numérico
        const prod = allProducts.find(p => String(p.id) === String(id));
        const precoNum = prod ? parseFloat(prod.preco) : 0;

        adicionarAoCarrinho(id, nome, tamanho, precoNum, imagem);
      });
    });
  }

  function adicionarAoCarrinho(id, nome, tamanho, precoNum, imagem) {
    const prod = allProducts.find(p => String(p.id) === String(id));
    if (prod && prod.esgotado) {
      alert('Desculpe, esta peça está esgotada no momento.');
      return;
    }

    const itemExistente = cart.find(item => String(item.id) === String(id) && item.tamanho === tamanho);
    if (itemExistente) {
      itemExistente.qty += 1;
    } else {
      cart.push({
        id,
        nome,
        tamanho,
        preco: precoNum,
        imagem,
        qty: 1
      });
    }

    salvarCarrinho();

    // Animação de pulsar no badge do carrinho
    if (cartCounter) {
      cartCounter.style.transform = 'scale(1.4)';
      setTimeout(() => { cartCounter.style.transform = 'scale(1)'; }, 250);
    }

    // Abre a sacola para visualização imediata
    abrirCarrinho();
  }

  /**
   * 5.1 Configuração dos Filtros Avançados & Ordenação
   */
  function configurarFiltrosAvancados() {
    // Pílulas modernas de Ordenação Rápida
    const sortPillBtns = document.querySelectorAll('.sort-pill-btn');
    sortPillBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        sortPillBtns.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        currentSort = btn.getAttribute('data-sort') || 'destaques';
        renderizarVitrine();
      });
    });

    if (filterPrice) {
      filterPrice.addEventListener('change', () => {
        currentPrice = filterPrice.value;
        renderizarVitrine();
      });
    }

    const sizeBtns = document.querySelectorAll('.size-filter-pill');
    sizeBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        sizeBtns.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        currentSize = btn.getAttribute('data-size');
        renderizarVitrine();
      });
    });

    if (btnClearFilters) {
      btnClearFilters.addEventListener('click', () => {
        currentCategory = 'todos';
        currentSort = 'destaques';
        currentPrice = 'todos';
        currentSize = 'todos';
        searchTerm = '';
        if (searchInput) searchInput.value = '';

        // Restaura pílulas de ordenação para 'destaques'
        sortPillBtns.forEach(b => {
          if (b.getAttribute('data-sort') === 'destaques') b.classList.add('active');
          else b.classList.remove('active');
        });

        if (filterPrice) filterPrice.value = 'todos';

        document.querySelectorAll('.tab-btn').forEach(b => {
          if (b.getAttribute('data-category') === 'todos') b.classList.add('active');
          else b.classList.remove('active');
        });

        sizeBtns.forEach(b => {
          if (b.getAttribute('data-size') === 'todos') b.classList.add('active');
          else b.classList.remove('active');
        });

        renderizarVitrine();
      });
    }
  }

  /**
   * 5.2 Lógica Completa da Lista de Desejos (Favoritos)
   */
  function salvarWishlist() {
    const key = getWishlistStorageKey();
    try {
      localStorage.setItem(key, JSON.stringify(wishlist));
    } catch (e) {}

    // Sincroniza em segundo plano com a conta no backend (usuarios.json)
    const isLogged = document.body.getAttribute('data-user-logged') === 'true';
    const isAdmin = document.body.getAttribute('data-is-admin') === 'true';
    if (isLogged && !isAdmin) {
      fetch('index.php?api=favoritos', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ favoritos: wishlist })
      }).catch(() => {});
    }

    atualizarWishlistUI();
  }

  function atualizarWishlistUI() {
    const isAdmin = document.body.getAttribute('data-is-admin') === 'true';
    if (isAdmin) {
      if (wishlistCounter) wishlistCounter.textContent = '0';
      if (drawerWishlistCounter) drawerWishlistCounter.textContent = '0';
      return;
    }

    const total = wishlist.length;
    if (wishlistCounter) wishlistCounter.textContent = total;
    if (drawerWishlistCounter) drawerWishlistCounter.textContent = total;
    if (wishlistDrawerCount) wishlistDrawerCount.textContent = total;

    // Atualiza botões nos cards
    document.querySelectorAll('.card-wishlist-btn').forEach(btn => {
      const id = btn.getAttribute('data-id');
      const isFav = wishlist.some(w => String(w.id) === String(id));
      if (isFav) {
        btn.classList.add('active');
        btn.setAttribute('title', 'Remover dos favoritos');
      } else {
        btn.classList.remove('active');
        btn.setAttribute('title', 'Favoritar este item');
      }
    });

    // Atualiza botão no QuickView se aberto
    if (currentQuickViewProduct && qvBtnWishlist && qvWishlistIcon) {
      const isFav = wishlist.some(w => String(w.id) === String(currentQuickViewProduct.id));
      if (isFav) {
        qvBtnWishlist.classList.add('active');
        qvWishlistIcon.textContent = 'favorite';
      } else {
        qvBtnWishlist.classList.remove('active');
        qvWishlistIcon.textContent = 'favorite_border';
      }
    }

    renderizarWishlistDrawer();
  }

  function toggleWishlist(produtoId) {
    const isAdmin = document.body.getAttribute('data-is-admin') === 'true';
    if (isAdmin) {
      // Bloqueia favoritar se for administrador
      return;
    }

    // 🔒 Cada usuário deve estar em sua conta para favoritar
    const isLogged = document.body.getAttribute('data-user-logged') === 'true';
    if (!isLogged) {
      abrirModalAuth('login');
      exibirAlertaModal('🔒 Entre na sua conta para salvar peças aos seus favoritos!', 'error');
      return;
    }

    const prod = allProducts.find(p => String(p.id) === String(produtoId));
    if (!prod) return;

    const idx = wishlist.findIndex(w => String(w.id) === String(produtoId));
    if (idx > -1) {
      wishlist.splice(idx, 1);
    } else {
      const galeria = prod.galeria && Array.isArray(prod.galeria) && prod.galeria.length > 0 ? prod.galeria : [prod.imagem];
      wishlist.push({
        id: prod.id,
        nome: prod.nome,
        categoria: prod.categoria,
        preco: prod.preco,
        preco_antigo: prod.preco_antigo || null,
        imagem: galeria[0],
        tamanhos: prod.tamanhos || ['Único']
      });

      // Animação pulse no badge
      if (wishlistCounter) {
        wishlistCounter.classList.add('pulse');
        setTimeout(() => wishlistCounter.classList.remove('pulse'), 300);
      }
    }

    salvarWishlist();
  }

  function renderizarWishlistDrawer() {
    if (!wishlistDrawerBody) return;

    if (wishlist.length === 0) {
      wishlistDrawerBody.innerHTML = `
        <div class="cart-empty-state">
          <div class="cart-empty-icon" style="background: rgba(239, 68, 68, 0.1); color: #ef4444;">
            <span class="material-symbols-outlined" style="font-size: 36px;">favorite_border</span>
          </div>
          <h4>Sua lista está vazia</h4>
          <p>Você ainda não favoritou nenhuma peça. Clique no ícone de coração nos produtos para salvá-los aqui.</p>
        </div>
      `;
      if (btnClearWishlist) btnClearWishlist.style.display = 'none';
      return;
    }

    if (btnClearWishlist) btnClearWishlist.style.display = 'block';

    wishlistDrawerBody.innerHTML = wishlist.map(item => {
      const precoBRL = Number(item.preco).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
      return `
        <div class="wishlist-item" data-id="${item.id}">
          <img src="${item.imagem}" alt="${item.nome}" class="wishlist-item-img">
          <div class="wishlist-item-info">
            <div>
              <span class="card-category-tag" style="margin-bottom: 4px;">${item.categoria || 'Moda'}</span>
              <h4 class="wishlist-item-title">${item.nome}</h4>
              <div class="wishlist-item-price">${precoBRL}</div>
            </div>
            <div class="wishlist-item-actions">
              <button type="button" class="btn-move-to-cart" data-id="${item.id}">
                <span class="material-symbols-outlined" style="font-size: 16px;">shopping_bag</span>
                Adicionar à Sacola
              </button>
              <button type="button" class="btn-remove-wishlist" data-id="${item.id}">
                Remover
              </button>
            </div>
          </div>
        </div>
      `;
    }).join('');

    // Eventos dentro do Drawer de Favoritos
    wishlistDrawerBody.querySelectorAll('.btn-move-to-cart').forEach(btn => {
      btn.addEventListener('click', () => {
        const isLogged = document.body.getAttribute('data-user-logged') === 'true';
        if (!isLogged) {
          fecharWishlistDrawer();
          abrirModalAuth('login');
          exibirAlertaModal('🔒 Entre na sua conta para adicionar peças à sua sacola!', 'error');
          return;
        }
        const id = btn.getAttribute('data-id');
        const item = wishlist.find(w => String(w.id) === String(id));
        if (item) {
          const primeiroTam = item.tamanhos && item.tamanhos.length > 0 ? item.tamanhos[0] : 'Padrão';
          adicionarAoCarrinho(item.id, item.nome, primeiroTam, parseFloat(item.preco) || 0, item.imagem);
          fecharWishlistDrawer();
        }
      });
    });

    wishlistDrawerBody.querySelectorAll('.btn-remove-wishlist').forEach(btn => {
      btn.addEventListener('click', () => {
        const id = btn.getAttribute('data-id');
        toggleWishlist(id);
      });
    });
  }

  function abrirWishlistDrawer() {
    if (wishlistDrawer && wishlistDrawerOverlay) {
      wishlistDrawer.classList.add('active');
      wishlistDrawerOverlay.classList.add('active');
      document.body.style.overflow = 'hidden';
    }
  }

  function fecharWishlistDrawer() {
    if (wishlistDrawer && wishlistDrawerOverlay) {
      wishlistDrawer.classList.remove('active');
      wishlistDrawerOverlay.classList.remove('active');
      document.body.style.overflow = '';
    }
  }

  if (wishlistBtn) wishlistBtn.addEventListener('click', abrirWishlistDrawer);
  if (btnCloseWishlist) btnCloseWishlist.addEventListener('click', fecharWishlistDrawer);
  if (wishlistDrawerOverlay) wishlistDrawerOverlay.addEventListener('click', fecharWishlistDrawer);
  if (drawerBtnOpenWishlist) {
    drawerBtnOpenWishlist.addEventListener('click', (e) => {
      e.preventDefault();
      fecharMenuMobile();
      abrirWishlistDrawer();
    });
  }
  if (btnClearWishlist) {
    btnClearWishlist.addEventListener('click', () => {
      if (confirm('Deseja limpar todos os seus favoritos?')) {
        wishlist = [];
        salvarWishlist();
      }
    });
  }



  /**
   * 5.4 Modal de Detalhes do Produto: Galeria Múltipla & Zoom Dinâmico
   */
  function abrirQuickView(produtoId) {
    const prod = allProducts.find(p => String(p.id) === String(produtoId));
    if (!prod) return;

    currentQuickViewProduct = prod;
    const galeria = prod.galeria && Array.isArray(prod.galeria) && prod.galeria.length > 0 ? prod.galeria : [prod.imagem];

    if (qvMainImg) {
      qvMainImg.src = galeria[0];
      qvMainImg.style.transformOrigin = 'center center';
      qvMainImg.style.transform = 'scale(1)';
    }
    if (qvTitle) qvTitle.textContent = prod.nome;
    if (qvCategory) qvCategory.textContent = prod.categoria;
    if (qvPrice) {
      const precoNum = parseFloat(prod.preco) || 0;
      const precoAntigoNum = prod.preco_antigo ? parseFloat(prod.preco_antigo) : 0;
      const temDesconto = precoAntigoNum > precoNum;
      const pctDesconto = temDesconto ? Math.round(((precoAntigoNum - precoNum) / precoAntigoNum) * 100) : 0;
      const precoBRL = precoNum.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
      const precoAntigoBRL = precoAntigoNum.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

      if (temDesconto) {
        qvPrice.innerHTML = `
          <span class="qv-price-old">De ${precoAntigoBRL}</span>
          <span class="qv-price-current">Por ${precoBRL}</span>
          <span class="qv-discount-badge">-${pctDesconto}% OFF</span>
        `;
      } else {
        qvPrice.innerHTML = `<span class="qv-price-current">${precoBRL}</span>`;
      }
    }
    if (qvDescription) {
      qvDescription.textContent = prod.descricao || 'Peça importada premium com tecido de alta densidade, corte contemporâneo e caimento impecável.';
    }

    if (qvBadge) {
      if (prod.esgotado) {
        qvBadge.textContent = 'ESGOTADO';
        qvBadge.style.display = 'inline-block';
        qvBadge.style.background = 'linear-gradient(135deg, #dc2626, #991b1b)';
        qvBadge.style.color = '#ffffff';
        qvBadge.style.border = 'none';
        qvBadge.style.boxShadow = '0 2px 8px rgba(220, 38, 38, 0.45)';
      } else if (prod.destaque) {
        qvBadge.textContent = prod.destaque;
        qvBadge.style.display = 'inline-block';
        qvBadge.style.background = 'linear-gradient(135deg, #111827, #1f2937)';
        qvBadge.style.color = '#fbbf24';
        qvBadge.style.border = '1px solid rgba(251, 191, 36, 0.4)';
        qvBadge.style.boxShadow = '0 2px 6px rgba(0, 0, 0, 0.3)';
      } else {
        qvBadge.style.display = 'none';
      }
    }

    // Miniaturas da Galeria
    if (qvThumbnails) {
      qvThumbnails.innerHTML = galeria.map((foto, idx) => `
        <div class="qv-thumb-item ${idx === 0 ? 'active' : ''}" data-src="${foto}">
          <img src="${foto}" alt="Miniatura ${idx + 1}">
        </div>
      `).join('');

      qvThumbnails.querySelectorAll('.qv-thumb-item').forEach(thumb => {
        thumb.addEventListener('click', () => {
          qvThumbnails.querySelectorAll('.qv-thumb-item').forEach(t => t.classList.remove('active'));
          thumb.classList.add('active');
          const novaFoto = thumb.getAttribute('data-src');
          if (qvMainImg) {
            qvMainImg.src = novaFoto;
            qvMainImg.style.transformOrigin = 'center center';
            qvMainImg.style.transform = 'scale(1)';
          }
        });
      });
    }

    // Tamanhos
    if (qvSizePicker) {
      const tams = prod.tamanhos && Array.isArray(prod.tamanhos) ? prod.tamanhos : ['Único'];
      currentQuickViewSelectedSize = tams[0] || 'Padrão';
      qvSizePicker.innerHTML = tams.map((tam, idx) => `
        <button type="button" class="size-pill ${idx === 0 ? 'selected' : ''}" data-size="${tam}">
          ${tam}
        </button>
      `).join('');

      qvSizePicker.querySelectorAll('.size-pill').forEach(pill => {
        pill.addEventListener('click', () => {
          qvSizePicker.querySelectorAll('.size-pill').forEach(p => p.classList.remove('selected'));
          pill.classList.add('selected');
          currentQuickViewSelectedSize = pill.getAttribute('data-size');
        });
      });
    }

    // Estado do botão de favoritar
    const isAdmin = document.body.getAttribute('data-is-admin') === 'true';
    if (qvBtnWishlist) {
      if (isAdmin) {
        qvBtnWishlist.style.display = 'none';
      } else {
        qvBtnWishlist.style.display = 'inline-flex';
        if (qvWishlistIcon) {
          const isFav = wishlist.some(w => String(w.id) === String(prod.id));
          if (isFav) {
            qvBtnWishlist.classList.add('active');
            qvWishlistIcon.textContent = 'favorite';
          } else {
            qvBtnWishlist.classList.remove('active');
            qvWishlistIcon.textContent = 'favorite_border';
          }
        }
      }
    }

    // Zoom dinâmico com o mouse (Lente de Ampliação)
    if (qvZoomContainer && qvMainImg) {
      qvZoomContainer.onmousemove = (e) => {
        const rect = qvZoomContainer.getBoundingClientRect();
        const x = ((e.clientX - rect.left) / rect.width) * 100;
        const y = ((e.clientY - rect.top) / rect.height) * 100;
        qvMainImg.style.transformOrigin = `${x}% ${y}%`;
        qvMainImg.style.transform = 'scale(2)';
      };

      qvZoomContainer.onmouseleave = () => {
        qvMainImg.style.transformOrigin = 'center center';
        qvMainImg.style.transform = 'scale(1)';
      };
    }

    if (qvBtnBuy) {
      if (prod.esgotado) {
        qvBtnBuy.disabled = true;
        qvBtnBuy.innerHTML = '<span class="material-symbols-outlined" style="font-size: 18px; margin-right: 6px;">block</span> Peça Esgotada';
        qvBtnBuy.classList.add('btn-buy-disabled');
      } else {
        qvBtnBuy.disabled = false;
        qvBtnBuy.innerHTML = '<span class="material-symbols-outlined" style="font-size: 20px; margin-right: 6px;">shopping_bag</span> Adicionar à Sacola de Compras';
        qvBtnBuy.classList.remove('btn-buy-disabled');
      }
    }

    if (quickviewModalOverlay) {
      quickviewModalOverlay.classList.add('active');
      document.body.style.overflow = 'hidden';
    }
  }

  function fecharQuickView() {
    if (quickviewModalOverlay) {
      quickviewModalOverlay.classList.remove('active');
      document.body.style.overflow = '';
      currentQuickViewProduct = null;
      if (qvMainImg) {
        qvMainImg.style.transformOrigin = 'center center';
        qvMainImg.style.transform = 'scale(1)';
      }
    }
  }

  if (btnCloseQuickview) btnCloseQuickview.addEventListener('click', fecharQuickView);
  if (quickviewModalOverlay) {
    quickviewModalOverlay.addEventListener('click', (e) => {
      if (e.target === quickviewModalOverlay) fecharQuickView();
    });
  }

  if (qvBtnBuy) {
    qvBtnBuy.addEventListener('click', () => {
      const isLogged = document.body.getAttribute('data-user-logged') === 'true';
      if (!isLogged) {
        fecharQuickView();
        abrirModalAuth('login');
        exibirAlertaModal('🔒 Você precisa entrar ou criar uma conta para adicionar peças à sua sacola!', 'error');
        return;
      }

      if (currentQuickViewProduct) {
        if (currentQuickViewProduct.esgotado) {
          alert('Desculpe, esta peça está esgotada no momento.');
          return;
        }
        const precoNum = parseFloat(currentQuickViewProduct.preco) || 0;
        const galeria = currentQuickViewProduct.galeria && currentQuickViewProduct.galeria.length > 0 ? currentQuickViewProduct.galeria : [currentQuickViewProduct.imagem];
        adicionarAoCarrinho(
          currentQuickViewProduct.id,
          currentQuickViewProduct.nome,
          currentQuickViewSelectedSize || 'Padrão',
          precoNum,
          galeria[0]
        );
        fecharQuickView();
      }
    });
  }

  if (qvBtnWishlist) {
    qvBtnWishlist.addEventListener('click', () => {
      if (currentQuickViewProduct) {
        toggleWishlist(currentQuickViewProduct.id);
      }
    });
  }

  /**
   * 6. Lógica Completa da Sacola / Carrinho de Compras
   */
  function atualizarContadores() {
    const isLogged = document.body.getAttribute('data-user-logged') === 'true';
    const totalItens = isLogged ? cart.reduce((acc, it) => acc + (it.qty || 1), 0) : 0;
    if (cartCounter) cartCounter.textContent = totalItens;
    if (drawerCartCounter) drawerCartCounter.textContent = totalItens;
    if (cartDrawerCount) cartDrawerCount.textContent = totalItens;
  }

  function salvarCarrinho() {
    const key = getCartStorageKey();
    try {
      localStorage.setItem(key, JSON.stringify(cart));
    } catch (e) {}

    // Sincroniza com a conta no backend (usuarios.json)
    const isLogged = document.body.getAttribute('data-user-logged') === 'true';
    const isAdmin = document.body.getAttribute('data-is-admin') === 'true';
    if (isLogged && !isAdmin) {
      fetch('index.php?api=carrinho', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ carrinho: cart })
      }).catch(() => {});
    }

    atualizarContadores();
  }

  function renderizarCarrinho() {
    if (!cartDrawerBody) return;

    // Se o visitante não estiver logado
    const isLogged = document.body.getAttribute('data-user-logged') === 'true';
    if (!isLogged) {
      cartDrawerBody.innerHTML = `
        <div class="cart-empty-state">
          <div class="cart-empty-icon" style="background-color: rgba(197, 155, 39, 0.12); color: var(--color-gold);">
            <span class="material-symbols-outlined" style="font-size: 36px;">lock</span>
          </div>
          <h4>Faça Login para Comprar</h4>
          <p>Conecte-se à sua conta para adicionar peças e finalizar seus pedidos na Vicente Imports.</p>
          <button type="button" class="btn-explore-catalog" id="btn-login-from-cart" style="background-color: var(--color-gold); color: #000000; font-weight: 800;">Entrar na Conta</button>
        </div>
      `;

      if (cartSubtotalVal) cartSubtotalVal.textContent = 'R$ 0,00';
      if (btnCheckoutWhatsapp) {
        btnCheckoutWhatsapp.style.pointerEvents = 'none';
        btnCheckoutWhatsapp.style.opacity = '0.5';
      }
      if (btnOpenCheckout) {
        btnOpenCheckout.style.pointerEvents = 'none';
        btnOpenCheckout.style.opacity = '0.5';
      }
      if (btnClearCart) btnClearCart.style.display = 'none';

      const btnLoginFromCart = document.getElementById('btn-login-from-cart');
      if (btnLoginFromCart) {
        btnLoginFromCart.addEventListener('click', () => {
          fecharCarrinho();
          abrirModalAuth('login');
          exibirAlertaModal('🔒 Entre na sua conta para liberar sua sacola de compras.', 'error');
        });
      }
      return;
    }

    if (cart.length === 0) {
      cartDrawerBody.innerHTML = `
        <div class="cart-empty-state">
          <div class="cart-empty-icon">
            <span class="material-symbols-outlined" style="font-size: 36px;">shopping_bag</span>
          </div>
          <h4>Sua sacola está vazia</h4>
          <p>Explore nosso catálogo e adicione suas peças exclusivas favoritas.</p>
          <button type="button" class="btn-explore-catalog" id="btn-explore-now">Ver Coleção</button>
        </div>
      `;

      if (cartSubtotalVal) cartSubtotalVal.textContent = 'R$ 0,00';
      if (btnCheckoutWhatsapp) {
        btnCheckoutWhatsapp.style.pointerEvents = 'none';
        btnCheckoutWhatsapp.style.opacity = '0.5';
      }
      if (btnOpenCheckout) {
        btnOpenCheckout.style.pointerEvents = 'none';
        btnOpenCheckout.style.opacity = '0.5';
      }
      if (btnClearCart) btnClearCart.style.display = 'none';

      const btnExploreNow = document.getElementById('btn-explore-now');
      if (btnExploreNow) {
        btnExploreNow.addEventListener('click', () => {
          fecharCarrinho();
          const target = document.getElementById('produtos');
          if (target) target.scrollIntoView({ behavior: 'smooth' });
        });
      }
      return;
    }

    // Calcula subtotal
    const subtotal = cart.reduce((acc, it) => acc + (Number(it.preco) * (it.qty || 1)), 0);
    const subtotalBRL = subtotal.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

    if (cartSubtotalVal) cartSubtotalVal.textContent = subtotalBRL;
    if (btnClearCart) btnClearCart.style.display = 'block';

    if (btnOpenCheckout) {
      btnOpenCheckout.style.pointerEvents = 'auto';
      btnOpenCheckout.style.opacity = '1';
    }

    if (btnCheckoutWhatsapp) {
      btnCheckoutWhatsapp.style.pointerEvents = 'auto';
      btnCheckoutWhatsapp.style.opacity = '1';

      // Monta mensagem personalizada para WhatsApp
      let msg = `👑 *PEDIDO - VICENTE IMPORTS*\n`;
      msg += `--------------------------------------------------\n`;
      cart.forEach((it, idx) => {
        const precoItem = (Number(it.preco) * it.qty).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
        msg += `${idx + 1}. *${it.nome}*\n   Tamanho: ${it.tamanho} | Qtd: ${it.qty}\n   Subtotal: ${precoItem}\n\n`;
      });
      msg += `--------------------------------------------------\n`;
      msg += `*VALOR TOTAL:* ${subtotalBRL}\n\n`;
      msg += `Gostaria de combinar o frete expresso e finalizar meu pedido!`;

      btnCheckoutWhatsapp.href = `https://wa.me/5527992856174?text=${encodeURIComponent(msg)}`;
    }

    // Monta itens HTML
    cartDrawerBody.innerHTML = cart.map((item, index) => {
      const unitVal = Number(item.preco).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
      return `
        <div class="cart-item">
          <img src="${item.imagem || 'images/logo.png'}" alt="${item.nome}" class="cart-item-img" onerror="this.src='images/logo.png';">
          <div class="cart-item-details">
            <div class="cart-item-name">${item.nome}</div>
            <div class="cart-item-size">Tamanho: <strong>${item.tamanho}</strong></div>
            <div class="cart-item-price">${unitVal}</div>
            <div class="cart-item-actions">
              <div class="cart-qty-control">
                <button type="button" class="btn-qty" data-action="minus" data-index="${index}" aria-label="Diminuir">-</button>
                <span class="cart-qty-val">${item.qty}</span>
                <button type="button" class="btn-qty" data-action="plus" data-index="${index}" aria-label="Aumentar">+</button>
              </div>
              <button type="button" class="btn-remove-item" data-action="remove" data-index="${index}">
                <span class="material-symbols-outlined" style="font-size: 15px; margin-right: 3px;">delete</span>
                Remover
              </button>
            </div>
          </div>
        </div>
      `;
    }).join('');

    // Eventos de alterar quantidade e remover
    cartDrawerBody.querySelectorAll('[data-action]').forEach(btn => {
      btn.addEventListener('click', () => {
        const action = btn.getAttribute('data-action');
        const idx = parseInt(btn.getAttribute('data-index'), 10);

        if (action === 'plus') {
          cart[idx].qty += 1;
        } else if (action === 'minus') {
          if (cart[idx].qty > 1) {
            cart[idx].qty -= 1;
          } else {
            cart.splice(idx, 1);
          }
        } else if (action === 'remove') {
          cart.splice(idx, 1);
        }

        salvarCarrinho();
        renderizarCarrinho();
      });
    });
  }

  function abrirCarrinho() {
    if (cartDrawer && cartDrawerOverlay) {
      cartDrawer.classList.add('active');
      cartDrawerOverlay.classList.add('active');
      document.body.style.overflow = 'hidden';
      renderizarCarrinho();
    }
  }

  function fecharCarrinho() {
    if (cartDrawer && cartDrawerOverlay) {
      cartDrawer.classList.remove('active');
      cartDrawerOverlay.classList.remove('active');
      document.body.style.overflow = '';
    }
  }

  if (cartBtn) {
    cartBtn.addEventListener('click', (e) => {
      e.preventDefault();
      abrirCarrinho();
    });
  }

  if (drawerBtnOpenCart) {
    drawerBtnOpenCart.addEventListener('click', (e) => {
      e.preventDefault();
      fecharMenuMobile();
      abrirCarrinho();
    });
  }

  if (btnCloseCart) btnCloseCart.addEventListener('click', fecharCarrinho);
  if (cartDrawerOverlay) cartDrawerOverlay.addEventListener('click', fecharCarrinho);

  if (btnClearCart) {
    btnClearCart.addEventListener('click', () => {
      if (confirm('Tem certeza de que deseja esvaziar sua sacola de compras?')) {
        cart = [];
        salvarCarrinho();
        renderizarCarrinho();
      }
    });
  }

  // Tecla ESC fecha o carrinho se estiver aberto
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      if (cartDrawer && cartDrawer.classList.contains('active')) {
        fecharCarrinho();
      }
    }
  });

  // Atualiza os contadores na carga inicial da página
  atualizarContadores();

  // 7. Busca em tempo real pelo campo de pesquisa
  if (searchInput) {
    searchInput.addEventListener('input', () => {
      searchTerm = searchInput.value.trim();
      renderizarVitrine();
    });
  }
  /**
   * 7. Gerenciamento do Modal de Autenticação Embutido (Entrar / Criar Conta)
   */
  const btnOpenAuthModal = document.getElementById('btn-open-auth-modal');
  const authModalOverlay = document.getElementById('auth-modal-overlay');
  const btnCloseAuthModal = document.getElementById('btn-close-auth-modal');
  const tabLoginBtn = document.getElementById('tab-login-btn');
  const tabRegisterBtn = document.getElementById('tab-register-btn');
  const formLogin = document.getElementById('form-in-site-login');
  const formRegister = document.getElementById('form-in-site-register');
  const authAlert = document.getElementById('auth-modal-alert');
  const switchToRegister = document.getElementById('switch-to-register');
  const switchToLogin = document.getElementById('switch-to-login');
  const drawerBtnOpenLogin = document.getElementById('drawer-btn-open-login');
  const drawerBtnOpenRegister = document.getElementById('drawer-btn-open-register');

  function exibirAlertaModal(mensagem, tipo = 'error') {
    if (!authAlert) return;
    authAlert.textContent = mensagem;
    authAlert.className = `auth-modal-alert ${tipo}`;
    authAlert.style.display = 'block';
  }

  function limparAlertaModal() {
    if (!authAlert) return;
    authAlert.style.display = 'none';
    authAlert.textContent = '';
  }

  function alternarAbaAuth(aba) {
    limparAlertaModal();
    if (aba === 'cadastro') {
      tabLoginBtn.classList.remove('active');
      tabRegisterBtn.classList.add('active');
      formLogin.classList.remove('active');
      formRegister.classList.add('active');
      const sub = document.getElementById('auth-modal-sub');
      if (sub) sub.textContent = 'Crie sua conta para receber novidades e fazer pedidos';
    } else {
      tabRegisterBtn.classList.remove('active');
      tabLoginBtn.classList.add('active');
      formRegister.classList.remove('active');
      formLogin.classList.add('active');
      const sub = document.getElementById('auth-modal-sub');
      if (sub) sub.textContent = 'Acesse sua conta ou crie um cadastro rápido';
    }
  }

  function abrirModalAuth(aba = 'login') {
    if (authModalOverlay) {
      alternarAbaAuth(aba);
      authModalOverlay.classList.add('active');
      document.body.style.overflow = 'hidden';
    }
  }

  function fecharModalAuth() {
    if (authModalOverlay) {
      authModalOverlay.classList.remove('active');
      document.body.style.overflow = '';
      limparAlertaModal();
    }
  }

  if (btnOpenAuthModal) btnOpenAuthModal.addEventListener('click', () => abrirModalAuth('login'));
  if (btnCloseAuthModal) btnCloseAuthModal.addEventListener('click', fecharModalAuth);
  
  if (authModalOverlay) {
    authModalOverlay.addEventListener('click', (e) => {
      if (e.target === authModalOverlay) fecharModalAuth();
    });
  }

  if (tabLoginBtn) tabLoginBtn.addEventListener('click', () => alternarAbaAuth('login'));
  if (tabRegisterBtn) tabRegisterBtn.addEventListener('click', () => alternarAbaAuth('cadastro'));
  if (switchToRegister) switchToRegister.addEventListener('click', () => alternarAbaAuth('cadastro'));
  if (switchToLogin) switchToLogin.addEventListener('click', () => alternarAbaAuth('login'));

  if (drawerBtnOpenLogin) {
    drawerBtnOpenLogin.addEventListener('click', (e) => {
      e.preventDefault();
      fecharMenuMobile();
      abrirModalAuth('login');
    });
  }

  if (drawerBtnOpenRegister) {
    drawerBtnOpenRegister.addEventListener('click', (e) => {
      e.preventDefault();
      fecharMenuMobile();
      abrirModalAuth('cadastro');
    });
  }

  // Envio do Formulário de Login via AJAX
  if (formLogin) {
    formLogin.addEventListener('submit', async (e) => {
      e.preventDefault();
      limparAlertaModal();

      const usuario = document.getElementById('modal-login-user').value.trim();
      const senha = document.getElementById('modal-login-pass').value;
      const btnSubmit = document.getElementById('btn-submit-login');

      if (!usuario || !senha) {
        exibirAlertaModal('Por favor, preencha usuário/e-mail e senha.');
        return;
      }

      try {
        btnSubmit.disabled = true;
        btnSubmit.innerHTML = '<span>Entrando...</span>';

        const res = await fetch('index.php?api=login', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ usuario, senha })
        });

        const data = await res.json();

        if (data.success) {
          exibirAlertaModal(data.message || 'Login bem-sucedido!', 'success');
          setTimeout(() => {
            if (data.redirect === 'admin.php') {
              window.location.href = 'admin.php';
            } else {
              window.location.reload();
            }
          }, 800);
        } else {
          exibirAlertaModal(data.message || 'Usuário ou senha incorretos.');
        }
      } catch (err) {
        exibirAlertaModal('Erro de conexão com o servidor. Tente novamente.');
      } finally {
        btnSubmit.disabled = false;
        btnSubmit.innerHTML = '<span>Entrar na Loja</span>';
      }
    });
  }

  // Envio do Formulário de Cadastro via AJAX
  if (formRegister) {
    formRegister.addEventListener('submit', async (e) => {
      e.preventDefault();
      limparAlertaModal();

      const nome = document.getElementById('modal-reg-nome').value.trim();
      const email = document.getElementById('modal-reg-email').value.trim();
      const telefone = document.getElementById('modal-reg-tel').value.trim();
      const senha = document.getElementById('modal-reg-pass').value;
      const btnSubmit = document.getElementById('btn-submit-register');

      if (!nome || !email || !senha) {
        exibirAlertaModal('Por favor, preencha todos os campos obrigatórios.');
        return;
      }

      if (senha.length < 6) {
        exibirAlertaModal('A senha deve ter no mínimo 6 caracteres.');
        return;
      }

      try {
        btnSubmit.disabled = true;
        btnSubmit.innerHTML = '<span>Cadastrando...</span>';

        const res = await fetch('index.php?api=cadastro', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ nome, email, telefone, senha })
        });

        const data = await res.json();

        if (data.success) {
          exibirAlertaModal(data.message || 'Conta criada com sucesso!', 'success');
          setTimeout(() => {
            window.location.reload();
          }, 900);
        } else {
          exibirAlertaModal(data.message || 'Erro ao criar conta.');
        }
      } catch (err) {
        exibirAlertaModal('Erro ao conectar ao servidor. Tente novamente.');
      } finally {
        btnSubmit.disabled = false;
        btnSubmit.innerHTML = '<span>Criar Minha Conta</span>';
      }
    });
  }

  /**
   * 8. Gerenciamento do Checkout Direto com Mercado Pago (Pix & Point)
   */
  const btnOpenCheckout = document.getElementById('btn-open-checkout');
  const checkoutModalOverlay = document.getElementById('checkout-modal-overlay');
  const btnCloseCheckout = document.getElementById('btn-close-checkout');
  const checkoutDisplayTotal = document.getElementById('checkout-display-total');
  const checkoutItemsSummary = document.getElementById('checkout-items-summary');
  const formCheckoutCustomer = document.getElementById('form-checkout-customer');

  // Elementos do Endereço Detalhado e CEP (Etapa 1)
  const inputCep = document.getElementById('checkout-input-cep');
  const inputBairro = document.getElementById('checkout-input-bairro');
  const inputRua = document.getElementById('checkout-input-rua');
  const inputNumero = document.getElementById('checkout-input-numero');
  const inputComplemento = document.getElementById('checkout-input-complemento');
  const inputCidade = document.getElementById('checkout-input-cidade');
  const inputUf = document.getElementById('checkout-input-uf');
  const cepLoadingSpinner = document.getElementById('cep-loading-spinner');
  const cepStatusMsg = document.getElementById('cep-status-msg');
  const checkRetirada = document.getElementById('checkout-check-retirada');
  const inputEnderecoHidden = document.getElementById('checkout-input-endereco');

  const btnBackToStep1 = document.getElementById('btn-back-to-step-1');
  const stepNav1 = document.getElementById('step-nav-1');
  const stepNav2 = document.getElementById('step-nav-2');
  const stepNav3 = document.getElementById('step-nav-3');
  const checkoutStep1 = document.getElementById('checkout-step-1');
  const checkoutStep2 = document.getElementById('checkout-step-2');
  const checkoutStep3 = document.getElementById('checkout-step-3');

  const methodPixCard = document.getElementById('method-pix-card');
  const methodCardCard = document.getElementById('method-card-card');
  const methodPointCard = document.getElementById('method-point-card');
  const paymentBoxPix = document.getElementById('payment-box-pix');
  const paymentBoxCard = document.getElementById('payment-box-card');
  const paymentBoxPoint = document.getElementById('payment-box-point');

  // Elementos do Cartão de Crédito e Débito Online
  const btnCardTypeCredit = document.getElementById('btn-card-type-credit');
  const btnCardTypeDebit = document.getElementById('btn-card-type-debit');
  const cardInputNumber = document.getElementById('card-input-number');
  const cardInputHolder = document.getElementById('card-input-holder');
  const cardInputExpiry = document.getElementById('card-input-expiry');
  const cardInputCvv = document.getElementById('card-input-cvv');
  const cardInputCpf = document.getElementById('card-input-cpf');
  const cardInputInstallments = document.getElementById('card-input-installments');
  const groupCardInstallments = document.getElementById('group-card-installments');
  const previewCardNum = document.getElementById('preview-card-num');
  const previewCardName = document.getElementById('preview-card-name');
  const previewCardExp = document.getElementById('preview-card-exp');
  const previewBrandBadge = document.getElementById('preview-brand-badge');
  const cardBrandDetected = document.getElementById('card-brand-detected');
  const formCheckoutCard = document.getElementById('form-checkout-card');
  const btnSubmitCardPay = document.getElementById('btn-submit-card-pay');
  const btnCardPayLabel = document.getElementById('btn-card-pay-label');
  const cardFeedbackMsg = document.getElementById('card-feedback-msg');
  const btnFillTestCard = document.getElementById('btn-fill-test-card');

  let currentCardType = 'credit_card';

  const btnGeneratePix = document.getElementById('btn-generate-pix');
  const checkoutPixQrcode = document.getElementById('checkout-pix-qrcode');
  const pixQrPlaceholder = document.getElementById('pix-qr-placeholder');
  const checkoutPixInput = document.getElementById('checkout-pix-input');
  const btnCopyPix = document.getElementById('btn-copy-pix');
  const pixListeningBadge = document.getElementById('pix-listening-badge');
  const btnSimulatePixApproval = document.getElementById('btn-simulate-pix-approval');

  const btnTriggerPoint = document.getElementById('btn-trigger-point');
  const pointStatusBadge = document.getElementById('point-status-badge');
  const btnSimulatePointApproval = document.getElementById('btn-simulate-point-approval');

  const successOrderId = document.getElementById('success-order-id');
  const successEmailDest = document.getElementById('success-email-dest');
  const btnFinishShopping = document.getElementById('btn-finish-shopping');

  let currentCheckoutOrder = null;
  let checkoutPollingInterval = null;

  function detectarBandeiraCartao(numero) {
    const limpo = (numero || '').replace(/\D/g, '');
    if (/^4/.test(limpo)) return { nome: 'Visa', cor: '#1a1f71', badge: 'VISA' };
    if (/^(5[1-5]|2[2-7])/.test(limpo)) return { nome: 'Mastercard', cor: '#eb001b', badge: 'MASTERCARD' };
    if (/^(4011|4389|4514|4576|5041|5066|5090|6277|6362|6363)/.test(limpo)) return { nome: 'Elo', cor: '#00a4e8', badge: 'ELO' };
    if (/^3[47]/.test(limpo)) return { nome: 'Amex', cor: '#006fcf', badge: 'AMEX' };
    if (/^(606282|3841)/.test(limpo)) return { nome: 'Hipercard', cor: '#b31010', badge: 'HIPERCARD' };
    return { nome: '', cor: '#ffffff', badge: 'CARTÃO' };
  }

  function atualizarOpcoesParcelamento(totalVal) {
    if (!cardInputInstallments) return;
    cardInputInstallments.innerHTML = '';

    if (currentCardType === 'debit_card') {
      const opt = document.createElement('option');
      opt.value = '1';
      opt.textContent = `1x de ${totalVal.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })} no Débito (à vista)`;
      cardInputInstallments.appendChild(opt);
      return;
    }

    // Cartão de Crédito: 1x a 12x
    for (let i = 1; i <= 12; i++) {
      const valorParcela = totalVal / i;
      const opt = document.createElement('option');
      opt.value = String(i);
      const jurosTexto = (i <= 6) ? 'sem juros' : 'sem acréscimo';
      opt.textContent = `${i}x de ${valorParcela.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })} (${jurosTexto})`;
      cardInputInstallments.appendChild(opt);
    }
  }

  function mudarEtapaCheckout(etapa) {
    [checkoutStep1, checkoutStep2, checkoutStep3].forEach(el => el && el.classList.remove('active'));
    [stepNav1, stepNav2, stepNav3].forEach(el => el && el.classList.remove('active'));

    if (etapa === 1) {
      if (checkoutStep1) checkoutStep1.classList.add('active');
      if (stepNav1) stepNav1.classList.add('active');
    } else if (etapa === 2) {
      if (checkoutStep2) checkoutStep2.classList.add('active');
      if (stepNav1) stepNav1.classList.add('active');
      if (stepNav2) stepNav2.classList.add('active');
    } else if (etapa === 3) {
      if (checkoutStep3) checkoutStep3.classList.add('active');
      if (stepNav1) stepNav1.classList.add('active');
      if (stepNav2) stepNav2.classList.add('active');
      if (stepNav3) stepNav3.classList.add('active');
    }
  }

  function abrirCheckoutModal() {
    try {
      const isLogged = document.body.getAttribute('data-user-logged') === 'true';
      if (!isLogged) {
        fecharCarrinho();
        abrirModalAuth('login');
        exibirAlertaModal('🔒 Faça login ou crie sua conta para prosseguir com o pagamento seguro.', 'error');
        return;
      }

      if (!cart || cart.length === 0) {
        alert('Sua sacola de compras está vazia. Adicione peças à sua sacola para continuar!');
        return;
      }

      // Fecha a gaveta lateral do carrinho com segurança
      fecharCarrinho();

      // Calcula total
      const totalVal = cart.reduce((acc, it) => acc + (Number(it.preco) * (it.qty || 1)), 0);
      const totalBRL = totalVal.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

      if (checkoutDisplayTotal) checkoutDisplayTotal.textContent = totalBRL;

      // Renderiza itens no resumo da etapa 1
      if (checkoutItemsSummary) {
        checkoutItemsSummary.innerHTML = cart.map(it => {
          const precoItem = (Number(it.preco) * (it.qty || 1)).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
          return `
            <div class="checkout-mini-item">
              <div style="display: flex; align-items: center; gap: 8px;">
                <img src="${it.imagem || 'images/logo.png'}" style="width: 36px; height: 36px; object-fit: cover; border-radius: 4px;" onerror="this.src='images/logo.png';">
                <div>
                  <strong>${it.nome}</strong>
                  <div style="font-size: 0.72rem; color: #6b7280;">Tam: ${it.tamanho} &bull; Qtd: ${it.qty}</div>
                </div>
              </div>
              <strong>${precoItem}</strong>
            </div>
          `;
        }).join('');
      }

      // Pré-preenche dados da conta se houver
      const userName = document.body.getAttribute('data-user-name');
      const userEmail = document.body.getAttribute('data-user-email');
      const userTel = document.body.getAttribute('data-user-tel');

      const inputNome = document.getElementById('checkout-input-nome');
      if (inputNome && !inputNome.value && userName) {
        inputNome.value = userName;
      }

      const inputEmail = document.getElementById('checkout-input-email');
      if (inputEmail && !inputEmail.value && userEmail) {
        inputEmail.value = userEmail;
      }

      const inputTel = document.getElementById('checkout-input-tel');
      if (inputTel && !inputTel.value && userTel) {
        inputTel.value = userTel;
      }

      // Atualiza valores para o checkout com Cartão
      if (btnCardPayLabel) {
        btnCardPayLabel.textContent = `Pagar ${totalBRL} no Cartão Agora`;
      }
      atualizarOpcoesParcelamento(totalVal);

      // Pré-preenche titular do cartão se disponível
      if (cardInputHolder && !cardInputHolder.value && userName) {
        cardInputHolder.value = userName.toUpperCase();
        if (previewCardName) previewCardName.textContent = userName.toUpperCase();
      }

      mudarEtapaCheckout(1);
      if (checkoutModalOverlay) {
        checkoutModalOverlay.classList.add('active');
        document.body.style.overflow = 'hidden';
      }
    } catch (err) {
      console.error('Erro ao abrir checkout:', err);
      document.body.style.overflow = '';
    }
  }

  function fecharCheckoutModal() {
    if (checkoutPollingInterval) {
      clearInterval(checkoutPollingInterval);
      checkoutPollingInterval = null;
    }
    if (checkoutModalOverlay) {
      checkoutModalOverlay.classList.remove('active');
      document.body.style.overflow = '';
    }
  }

  if (btnOpenCheckout) {
    btnOpenCheckout.addEventListener('click', (e) => {
      e.preventDefault();
      abrirCheckoutModal();
    });
  }

  if (btnCloseCheckout) btnCloseCheckout.addEventListener('click', fecharCheckoutModal);
  if (checkoutModalOverlay) {
    checkoutModalOverlay.addEventListener('click', (e) => {
      if (e.target === checkoutModalOverlay) fecharCheckoutModal();
    });
  }

  // Fecha checkout ao pressionar ESC
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && checkoutModalOverlay && checkoutModalOverlay.classList.contains('active')) {
      fecharCheckoutModal();
    }
  });

  if (btnBackToStep1) {
    btnBackToStep1.addEventListener('click', () => mudarEtapaCheckout(1));
  }

  // Funções de Montagem de Endereço e Consulta de CEP (ViaCEP)
  function obterEnderecoCompleto() {
    if (checkRetirada && checkRetirada.checked) {
      const endRetirada = 'Retirada na Loja Física (Colatina - ES)';
      if (inputEnderecoHidden) inputEnderecoHidden.value = endRetirada;
      return endRetirada;
    }

    const rua = inputRua ? inputRua.value.trim() : '';
    const num = inputNumero ? inputNumero.value.trim() : '';
    const comp = inputComplemento ? inputComplemento.value.trim() : '';
    const bairro = inputBairro ? inputBairro.value.trim() : '';
    const cidade = inputCidade ? inputCidade.value.trim() : '';
    const uf = inputUf ? inputUf.value.trim().toUpperCase() : '';
    const cep = inputCep ? inputCep.value.trim() : '';

    let partes = [];
    if (rua) partes.push(rua + (num ? ', ' + num : ''));
    if (comp) partes.push(comp);
    if (bairro) partes.push(bairro);
    if (cidade) partes.push(cidade + (uf ? ' - ' + uf : ''));
    if (cep) partes.push('CEP: ' + cep);

    const formatado = partes.join(', ');
    if (inputEnderecoHidden) {
      inputEnderecoHidden.value = formatado;
    }
    return formatado;
  }

  function obterDetalhesEndereco() {
    return {
      cep: inputCep ? inputCep.value.trim() : '',
      rua: inputRua ? inputRua.value.trim() : '',
      numero: inputNumero ? inputNumero.value.trim() : '',
      complemento: inputComplemento ? inputComplemento.value.trim() : '',
      bairro: inputBairro ? inputBairro.value.trim() : '',
      cidade: inputCidade ? inputCidade.value.trim() : '',
      uf: inputUf ? inputUf.value.trim().toUpperCase() : '',
      retirada_loja: !!(checkRetirada && checkRetirada.checked)
    };
  }

  let ultimoCepConsultado = '';

  async function consultarCep(cepRaw) {
    const cepLimpo = (cepRaw || '').replace(/\D/g, '');
    if (cepLimpo.length !== 8) return;
    if (cepLimpo === ultimoCepConsultado) return;

    ultimoCepConsultado = cepLimpo;

    if (cepLoadingSpinner) cepLoadingSpinner.style.display = 'inline-block';
    if (cepStatusMsg) {
      cepStatusMsg.style.display = 'block';
      cepStatusMsg.style.color = '#6b7280';
      cepStatusMsg.textContent = 'Buscando endereço pelo CEP...';
    }

    try {
      const resp = await fetch(`https://viacep.com.br/ws/${cepLimpo}/json/`);
      const data = await resp.json();

      if (data.erro) {
        if (cepStatusMsg) {
          cepStatusMsg.style.display = 'block';
          cepStatusMsg.style.color = '#dc2626';
          cepStatusMsg.textContent = 'CEP não encontrado. Digite o endereço manualmente.';
        }
      } else {
        if (inputRua && data.logradouro) inputRua.value = data.logradouro;
        if (inputBairro && data.bairro) inputBairro.value = data.bairro;
        if (inputCidade && data.localidade) inputCidade.value = data.localidade;
        if (inputUf && data.uf) inputUf.value = data.uf;

        if (cepStatusMsg) {
          cepStatusMsg.style.display = 'block';
          cepStatusMsg.style.color = '#059669';
          cepStatusMsg.textContent = `✓ ${data.localidade} - ${data.uf} localizado!`;
        }

        // Foca automaticamente no campo de número
        if (inputNumero && !inputNumero.value) {
          inputNumero.focus();
        }

        obterEnderecoCompleto();
      }
    } catch (err) {
      console.warn('Erro ao consultar ViaCEP:', err);
      if (cepStatusMsg) {
        cepStatusMsg.style.display = 'block';
        cepStatusMsg.style.color = '#d97706';
        cepStatusMsg.textContent = 'Não foi possível consultar automaticamente. Digite o endereço.';
      }
    } finally {
      if (cepLoadingSpinner) cepLoadingSpinner.style.display = 'none';
    }
  }

  // Eventos do campo CEP
  if (inputCep) {
    inputCep.addEventListener('input', (e) => {
      let val = e.target.value.replace(/\D/g, '').slice(0, 8);
      if (val.length > 5) {
        val = val.substring(0, 5) + '-' + val.substring(5);
      }
      e.target.value = val;

      const digits = val.replace(/\D/g, '');
      if (digits.length === 8) {
        consultarCep(digits);
      } else {
        ultimoCepConsultado = '';
        if (cepStatusMsg) cepStatusMsg.style.display = 'none';
      }
      obterEnderecoCompleto();
    });

    inputCep.addEventListener('blur', (e) => {
      const digits = e.target.value.replace(/\D/g, '');
      if (digits.length === 8) {
        consultarCep(digits);
      } else if (digits.length > 0 && digits.length < 8) {
        if (cepStatusMsg) {
          cepStatusMsg.style.display = 'block';
          cepStatusMsg.style.color = '#dc2626';
          cepStatusMsg.textContent = 'CEP incompleto (deve ter 8 dígitos).';
        }
      }
    });
  }

  [inputRua, inputNumero, inputComplemento, inputBairro, inputCidade, inputUf].forEach(el => {
    if (el) {
      el.addEventListener('input', obterEnderecoCompleto);
      el.addEventListener('change', obterEnderecoCompleto);
    }
  });

  if (checkRetirada) {
    checkRetirada.addEventListener('change', () => {
      const isRetirada = checkRetirada.checked;
      if (isRetirada) {
        if (inputCep) inputCep.value = '29700-000';
        if (inputRua) inputRua.value = 'Retirada no Balcão da Loja Vicent Imports';
        if (inputNumero) inputNumero.value = 'S/N';
        if (inputComplemento) inputComplemento.value = '';
        if (inputBairro) inputBairro.value = 'Centro';
        if (inputCidade) inputCidade.value = 'Colatina';
        if (inputUf) inputUf.value = 'ES';
        if (cepStatusMsg) {
          cepStatusMsg.style.display = 'block';
          cepStatusMsg.style.color = '#00b495';
          cepStatusMsg.textContent = 'Opção selecionada: Retirar pessoalmente na loja em Colatina.';
        }
      } else {
        if (inputCep) inputCep.value = '';
        if (inputRua) inputRua.value = '';
        if (inputNumero) inputNumero.value = '';
        if (inputComplemento) inputComplemento.value = '';
        if (inputBairro) inputBairro.value = '';
        if (inputCidade) inputCidade.value = '';
        if (inputUf) inputUf.value = '';
        if (cepStatusMsg) cepStatusMsg.style.display = 'none';
        ultimoCepConsultado = '';
      }
      obterEnderecoCompleto();
    });
  }

  // Submissão da Etapa 1 (Dados do Cliente e Entrega)
  if (formCheckoutCustomer) {
    formCheckoutCustomer.addEventListener('submit', (e) => {
      e.preventDefault();
      obterEnderecoCompleto();
      mudarEtapaCheckout(2);
    });
  }

  // Alternância entre Métodos de Pagamento (Pix vs Cartão Online vs Point)
  function selecionarMetodoPagamento(metodo) {
    [methodPixCard, methodCardCard, methodPointCard].forEach(el => el && el.classList.remove('active'));
    [paymentBoxPix, paymentBoxCard, paymentBoxPoint].forEach(el => el && (el.style.display = 'none'));

    if (metodo === 'pix') {
      if (methodPixCard) methodPixCard.classList.add('active');
      if (paymentBoxPix) paymentBoxPix.style.display = 'block';
    } else if (metodo === 'card') {
      if (methodCardCard) methodCardCard.classList.add('active');
      if (paymentBoxCard) paymentBoxCard.style.display = 'block';
      const totalVal = cart.reduce((acc, it) => acc + (Number(it.preco) * (it.qty || 1)), 0);
      atualizarOpcoesParcelamento(totalVal);
    } else if (metodo === 'point') {
      if (methodPointCard) methodPointCard.classList.add('active');
      if (paymentBoxPoint) paymentBoxPoint.style.display = 'block';
    }
  }

  if (methodPixCard) methodPixCard.addEventListener('click', () => selecionarMetodoPagamento('pix'));
  if (methodCardCard) methodCardCard.addEventListener('click', () => selecionarMetodoPagamento('card'));
  if (methodPointCard) methodPointCard.addEventListener('click', () => selecionarMetodoPagamento('point'));

  // Geração do Pix no Mercado Pago
  if (btnGeneratePix) {
    btnGeneratePix.addEventListener('click', async () => {
      const nome = document.getElementById('checkout-input-nome').value.trim();
      const email = document.getElementById('checkout-input-email').value.trim();
      const tel = document.getElementById('checkout-input-tel').value.trim();
      const endereco = obterEnderecoCompleto();
      const enderecoDetalhes = obterDetalhesEndereco();

      const totalVal = cart.reduce((acc, it) => acc + (Number(it.preco) * (it.qty || 1)), 0);

      btnGeneratePix.disabled = true;
      btnGeneratePix.innerHTML = '<span class="spinner-gold" style="width:16px;height:16px;margin-right:8px;border-width:2px;display:inline-block;vertical-align:middle;"></span> Gerando Pix...';

      try {
        const res = await fetch('index.php?api=checkout_pix', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            itens: cart,
            cliente: { nome, email, telefone: tel, endereco, endereco_detalhes: enderecoDetalhes },
            total: totalVal
          })
        });

        const data = await res.json();
        if (data.success && data.pix) {
          currentCheckoutOrder = data;

          if (data.pix.qr_code_base64) {
            checkoutPixQrcode.src = `data:image/png;base64,${data.pix.qr_code_base64}`;
            checkoutPixQrcode.style.display = 'block';
            if (pixQrPlaceholder) pixQrPlaceholder.style.display = 'none';
          } else if (data.pix.qr_code_url) {
            checkoutPixQrcode.src = data.pix.qr_code_url;
            checkoutPixQrcode.style.display = 'block';
            if (pixQrPlaceholder) pixQrPlaceholder.style.display = 'none';
          }

          if (checkoutPixInput) {
            checkoutPixInput.value = data.pix.copia_e_cola || '';
          }

          if (data.mp_aviso && paymentBoxPix) {
            let avisoEl = document.getElementById('checkout-mp-aviso');
            if (!avisoEl) {
              avisoEl = document.createElement('div');
              avisoEl.id = 'checkout-mp-aviso';
              avisoEl.style.cssText = 'background: #fef3c7; border: 1px solid #fde68a; color: #92400e; padding: 10px 14px; border-radius: 8px; font-size: 0.78rem; font-weight: 600; margin-bottom: 12px; line-height: 1.4;';
              paymentBoxPix.prepend(avisoEl);
            }
            avisoEl.textContent = data.mp_aviso;
            avisoEl.style.display = 'block';
          }

          if (pixListeningBadge) pixListeningBadge.style.display = 'flex';
          if (btnSimulatePixApproval) btnSimulatePixApproval.style.display = 'block';

          btnGeneratePix.innerHTML = '<span class="material-symbols-outlined">sync</span> Pix Gerado com Sucesso!';

          // Inicia verificação automática em tempo real a cada 3s
          iniciarPollingPagamento(data.pedido_id);
        } else {
          alert(data.message || 'Erro ao gerar cobrança Pix.');
          btnGeneratePix.disabled = false;
          btnGeneratePix.innerHTML = '<span class="material-symbols-outlined">bolt</span> Gerar QR Code Pix';
        }
      } catch (err) {
        alert('Erro ao conectar ao servidor. Tente novamente.');
        btnGeneratePix.disabled = false;
        btnGeneratePix.innerHTML = '<span class="material-symbols-outlined">bolt</span> Gerar QR Code Pix';
      }
    });
  }

  // Copiar Código Pix
  if (btnCopyPix) {
    btnCopyPix.addEventListener('click', () => {
      if (checkoutPixInput && checkoutPixInput.value) {
        navigator.clipboard.writeText(checkoutPixInput.value).then(() => {
          btnCopyPix.innerHTML = '<span class="material-symbols-outlined" style="font-size: 18px;">done</span> Copiado!';
          setTimeout(() => {
            btnCopyPix.innerHTML = '<span class="material-symbols-outlined" style="font-size: 18px;">content_copy</span> Copiar';
          }, 2000);
        });
      }
    });
  }

  // Disparo para Maquininha Point
  if (btnTriggerPoint) {
    btnTriggerPoint.addEventListener('click', async () => {
      const nome = document.getElementById('checkout-input-nome').value.trim();
      const email = document.getElementById('checkout-input-email').value.trim();
      const tel = document.getElementById('checkout-input-tel').value.trim();
      const endereco = obterEnderecoCompleto();
      const enderecoDetalhes = obterDetalhesEndereco();

      const totalVal = cart.reduce((acc, it) => acc + (Number(it.preco) * (it.qty || 1)), 0);

      btnTriggerPoint.disabled = true;
      btnTriggerPoint.innerHTML = '<span>Enviando para o terminal...</span>';

      try {
        const res = await fetch('index.php?api=checkout_point', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            itens: cart,
            cliente: { nome, email, telefone: tel, endereco, endereco_detalhes: enderecoDetalhes },
            total: totalVal
          })
        });

        const data = await res.json();
        if (data.success) {
          currentCheckoutOrder = data;
          if (pointStatusBadge) pointStatusBadge.style.display = 'block';
          if (btnSimulatePointApproval) btnSimulatePointApproval.style.display = 'block';
          iniciarPollingPagamento(data.pedido_id);
        } else {
          alert(data.message || 'Erro ao enviar para a maquininha.');
          btnTriggerPoint.disabled = false;
          btnTriggerPoint.innerHTML = '<span>Enviar Cobrança para a Maquininha</span>';
        }
      } catch (err) {
        alert('Erro ao se comunicar com a maquininha.');
        btnTriggerPoint.disabled = false;
        btnTriggerPoint.innerHTML = '<span>Enviar Cobrança para a Maquininha</span>';
      }
    });
  }

  // Alternador de Tipo de Cartão (Crédito vs Débito)
  if (btnCardTypeCredit && btnCardTypeDebit) {
    btnCardTypeCredit.addEventListener('click', () => {
      btnCardTypeCredit.classList.add('active');
      btnCardTypeDebit.classList.remove('active');
      currentCardType = 'credit_card';
      if (groupCardInstallments) groupCardInstallments.style.display = 'block';
      const totalVal = cart.reduce((acc, it) => acc + (Number(it.preco) * (it.qty || 1)), 0);
      atualizarOpcoesParcelamento(totalVal);
    });

    btnCardTypeDebit.addEventListener('click', () => {
      btnCardTypeDebit.classList.add('active');
      btnCardTypeCredit.classList.remove('active');
      currentCardType = 'debit_card';
      const totalVal = cart.reduce((acc, it) => acc + (Number(it.preco) * (it.qty || 1)), 0);
      atualizarOpcoesParcelamento(totalVal);
    });
  }

  // Máscaras de Digitação e Espelhamento em Tempo Real no Cartão
  if (cardInputNumber) {
    cardInputNumber.addEventListener('input', (e) => {
      const val = e.target.value.replace(/\D/g, '').slice(0, 16);
      const formatado = val.replace(/(\d{4})(?=\d)/g, '$1 ');
      e.target.value = formatado;

      // Espelhamento no Cartão Visual
      if (previewCardNum) {
        if (formatado.length > 0) {
          let preview = formatado;
          const lenLimpo = val.length;
          if (lenLimpo < 16) {
            const mascaraCheia = '•••• •••• •••• ••••';
            preview += mascaraCheia.slice(formatado.length);
          }
          previewCardNum.textContent = preview;
        } else {
          previewCardNum.innerHTML = '&bull;&bull;&bull;&bull; &bull;&bull;&bull;&bull; &bull;&bull;&bull;&bull; &bull;&bull;&bull;&bull;';
        }
      }

      // Detecção de Bandeira
      const band = detectarBandeiraCartao(val);
      if (previewBrandBadge) {
        previewBrandBadge.textContent = band.badge;
        if (band.nome) {
          previewBrandBadge.style.background = 'rgba(255, 255, 255, 0.95)';
          previewBrandBadge.style.color = band.cor;
        } else {
          previewBrandBadge.style.background = 'rgba(255, 255, 255, 0.15)';
          previewBrandBadge.style.color = '#ffffff';
        }
      }
      if (cardBrandDetected) {
        cardBrandDetected.textContent = band.nome;
        cardBrandDetected.style.color = band.cor;
      }
    });
  }

  if (cardInputHolder) {
    cardInputHolder.addEventListener('input', (e) => {
      const val = e.target.value.toUpperCase();
      if (previewCardName) {
        previewCardName.textContent = val || 'NOME COMPLETO';
      }
    });
  }

  if (cardInputExpiry) {
    cardInputExpiry.addEventListener('input', (e) => {
      let val = e.target.value.replace(/\D/g, '').slice(0, 4);
      if (val.length >= 3) {
        val = val.slice(0, 2) + '/' + val.slice(2);
      }
      e.target.value = val;
      if (previewCardExp) {
        previewCardExp.textContent = val || 'MM/AA';
      }
    });
  }

  if (cardInputCvv) {
    cardInputCvv.addEventListener('input', (e) => {
      e.target.value = e.target.value.replace(/\D/g, '').slice(0, 4);
    });
  }

  if (cardInputCpf) {
    cardInputCpf.addEventListener('input', (e) => {
      let val = e.target.value.replace(/\D/g, '').slice(0, 11);
      if (val.length > 9) {
        val = val.replace(/(\d{3})(\d{3})(\d{3})(\d{1,2})/, '$1.$2.$3-$4');
      } else if (val.length > 6) {
        val = val.replace(/(\d{3})(\d{3})(\d{1,3})/, '$1.$2.$3');
      } else if (val.length > 3) {
        val = val.replace(/(\d{3})(\d{1,3})/, '$1.$2');
      }
      e.target.value = val;
    });
  }

  // Preenchimento com Cartão de Teste (1-Click)
  if (btnFillTestCard) {
    btnFillTestCard.addEventListener('click', () => {
      if (cardInputNumber) {
        cardInputNumber.value = '5031 7500 0000 0001';
        cardInputNumber.dispatchEvent(new Event('input'));
      }
      if (cardInputHolder) {
        cardInputHolder.value = 'JOAO DA SILVA';
        cardInputHolder.dispatchEvent(new Event('input'));
      }
      if (cardInputExpiry) {
        cardInputExpiry.value = '11/29';
        cardInputExpiry.dispatchEvent(new Event('input'));
      }
      if (cardInputCvv) {
        cardInputCvv.value = '123';
        cardInputCvv.dispatchEvent(new Event('input'));
      }
      if (cardInputCpf) {
        cardInputCpf.value = '111.222.333-44';
        cardInputCpf.dispatchEvent(new Event('input'));
      }
      if (cardFeedbackMsg) {
        cardFeedbackMsg.style.display = 'block';
        cardFeedbackMsg.style.background = '#eff6ff';
        cardFeedbackMsg.style.border = '1px solid #bfdbfe';
        cardFeedbackMsg.style.color = '#1d4ed8';
        cardFeedbackMsg.innerHTML = '🧪 <strong>Cartão de Teste Preenchido!</strong> Clique em "Pagar com Cartão Agora" para testar a verificação e autorização imediata da venda.';
      }
    });
  }

  // Submissão do Pagamento com Cartão Online
  if (formCheckoutCard) {
    formCheckoutCard.addEventListener('submit', async (e) => {
      e.preventDefault();

      const numVal = cardInputNumber ? cardInputNumber.value.trim() : '';
      const holderVal = cardInputHolder ? cardInputHolder.value.trim() : '';
      const expVal = cardInputExpiry ? cardInputExpiry.value.trim() : '';
      const cvvVal = cardInputCvv ? cardInputCvv.value.trim() : '';
      const cpfVal = cardInputCpf ? cardInputCpf.value.trim() : '';
      const parcelasVal = cardInputInstallments ? parseInt(cardInputInstallments.value || '1', 10) : 1;

      const expParts = expVal.split('/');
      const mes = parseInt(expParts[0] || '0', 10);
      let ano = parseInt(expParts[1] || '0', 10);
      if (ano < 100) ano += 2000;

      if (!numVal || numVal.replace(/\D/g, '').length < 13) {
        alert('Por favor, informe o número completo do seu cartão.');
        return;
      }
      if (!holderVal) {
        alert('Por favor, informe o nome impresso no cartão.');
        return;
      }
      if (!mes || mes < 1 || mes > 12 || !ano || ano < 2024) {
        alert('Data de validade do cartão incorreta. Utilize o formato MM/AA.');
        return;
      }
      if (!cvvVal || cvvVal.length < 3) {
        alert('Código CVV de segurança inválido.');
        return;
      }
      if (!cpfVal || cpfVal.replace(/\D/g, '').length < 11) {
        alert('O CPF do titular é obrigatório para autorização bancária.');
        return;
      }

      const nome = document.getElementById('checkout-input-nome').value.trim();
      const email = document.getElementById('checkout-input-email').value.trim();
      const tel = document.getElementById('checkout-input-tel').value.trim();
      const endereco = obterEnderecoCompleto();
      const enderecoDetalhes = obterDetalhesEndereco();

      const totalVal = cart.reduce((acc, it) => acc + (Number(it.preco) * (it.qty || 1)), 0);

      btnSubmitCardPay.disabled = true;
      if (btnCardPayLabel) btnCardPayLabel.textContent = 'Verificando e Processando Cartão...';
      if (cardFeedbackMsg) cardFeedbackMsg.style.display = 'none';

      try {
        const res = await fetch('index.php?api=checkout_cartao', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            itens: cart,
            cliente: { nome, email, telefone: tel, endereco, endereco_detalhes: enderecoDetalhes, cpf: cpfVal },
            cartao: {
              numero: numVal,
              nome_titular: holderVal,
              mes_expiracao: mes,
              ano_expiracao: ano,
              cvv: cvvVal,
              cpf: cpfVal,
              parcelas: parcelasVal,
              tipo: currentCardType
            },
            total: totalVal
          })
        });

        const data = await res.json();

        if (data.success && data.status === 'approved') {
          // Autorização imediata da venda!
          concluirPagamentoComSucesso(data.pedido_id);
        } else {
          btnSubmitCardPay.disabled = false;
          if (btnCardPayLabel) {
            const totalBRL = totalVal.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
            btnCardPayLabel.textContent = `Pagar ${totalBRL} no Cartão Agora`;
          }
          if (cardFeedbackMsg) {
            cardFeedbackMsg.style.display = 'block';
            cardFeedbackMsg.style.background = '#fef2f2';
            cardFeedbackMsg.style.border = '1px solid #fecaca';
            cardFeedbackMsg.style.color = '#b91c1c';
            cardFeedbackMsg.innerHTML = `⚠️ <strong>Não foi possível autorizar o cartão:</strong> ${data.message || 'Verifique os dados informados e tente novamente.'}`;
          }
        }
      } catch (err) {
        console.error('Erro ao processar cartão:', err);
        btnSubmitCardPay.disabled = false;
        if (btnCardPayLabel) {
          const totalBRL = totalVal.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
          btnCardPayLabel.textContent = `Pagar ${totalBRL} no Cartão Agora`;
        }
        if (cardFeedbackMsg) {
          cardFeedbackMsg.style.display = 'block';
          cardFeedbackMsg.style.background = '#fef2f2';
          cardFeedbackMsg.style.border = '1px solid #fecaca';
          cardFeedbackMsg.style.color = '#b91c1c';
          cardFeedbackMsg.innerHTML = '⚠️ Erro de conexão ao processar o cartão. Por favor, tente novamente.';
        }
      }
    });
  }

  // Polling para checar aprovação em tempo real
  function iniciarPollingPagamento(pedidoId) {
    if (checkoutPollingInterval) clearInterval(checkoutPollingInterval);

    checkoutPollingInterval = setInterval(async () => {
      try {
        const res = await fetch(`index.php?api=status_pedido&pedido_id=${encodeURIComponent(pedidoId)}`);
        const data = await res.json();

        if (data.success && data.status === 'aprovado') {
          concluirPagamentoComSucesso(pedidoId);
        }
      } catch (e) {}
    }, 3000);
  }

  // Simular aprovação instantânea para ambiente de teste
  async function simularAprovacao(pedidoId) {
    try {
      const res = await fetch('index.php?api=aprovar_pedido', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pedido_id: pedidoId })
      });
      const data = await res.json();
      if (data.success) {
        concluirPagamentoComSucesso(pedidoId);
      }
    } catch (e) {
      alert('Erro ao simular aprovação.');
    }
  }

  if (btnSimulatePixApproval) {
    btnSimulatePixApproval.addEventListener('click', () => {
      if (currentCheckoutOrder && currentCheckoutOrder.pedido_id) {
        simularAprovacao(currentCheckoutOrder.pedido_id);
      }
    });
  }

  if (btnSimulatePointApproval) {
    btnSimulatePointApproval.addEventListener('click', () => {
      if (currentCheckoutOrder && currentCheckoutOrder.pedido_id) {
        simularAprovacao(currentCheckoutOrder.pedido_id);
      }
    });
  }

  function concluirPagamentoComSucesso(pedidoId) {
    if (checkoutPollingInterval) {
      clearInterval(checkoutPollingInterval);
      checkoutPollingInterval = null;
    }

    // Esvazia carrinho local
    cart = [];
    salvarCarrinho();
    renderizarCarrinho();

    // Atualiza dados na tela de sucesso
    const emailVal = document.getElementById('checkout-input-email').value.trim();
    if (successOrderId) successOrderId.textContent = `#${pedidoId}`;
    if (successEmailDest) successEmailDest.textContent = emailVal || 'seu e-mail';

    mudarEtapaCheckout(3);
  }

  if (btnFinishShopping) {
    btnFinishShopping.addEventListener('click', () => {
      fecharCheckoutModal();
      const target = document.getElementById('produtos');
      if (target) target.scrollIntoView({ behavior: 'smooth' });
    });
  }

  // Se a URL contiver ?checkout=abrir, abre o modal diretamente
  if (window.location.search.includes('checkout=abrir')) {
    setTimeout(abrirCheckoutModal, 600);
  }

  // Inicializa o carregamento dos produtos
  carregarProdutos();
});

