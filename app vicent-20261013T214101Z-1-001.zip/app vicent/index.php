<?php
date_default_timezone_set('America/Sao_Paulo');
/**
 * ============================================================================
 * VICENT IMPORTS - LOJA DE MODA MASCULINA & IMPORTADOS PREMIUM
 * Colatina - ES | Backend PHP Integrado
 * ============================================================================
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$caminhoJson = __DIR__ . DIRECTORY_SEPARATOR . 'produtos.json';
$caminhoUsuarios = __DIR__ . DIRECTORY_SEPARATOR . 'usuarios.json';

function obterProdutos($caminho) {
    if (!file_exists($caminho)) return [];
    $conteudo = file_get_contents($caminho);
    return $conteudo ? (json_decode($conteudo, true) ?? []) : [];
}

function obterUsuariosCadastrados($caminho) {
    if (!file_exists($caminho)) return [];
    $conteudo = file_get_contents($caminho);
    return $conteudo ? (json_decode($conteudo, true) ?? []) : [];
}

function salvarUsuariosCadastrados($caminho, $usuarios) {
    $json = json_encode(array_values($usuarios), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    return file_put_contents($caminho, $json, LOCK_EX);
}

$produtos = obterProdutos($caminhoJson);

// 1. Endpoint de Produtos
if (isset($_GET['api']) && $_GET['api'] === 'produtos') {
    header('Content-Type: application/json; charset=UTF-8');
    header('Access-Control-Allow-Origin: *');
    header('Cache-Control: no-cache, must-revalidate');
    
    // Itens com selo de destaque aparecem primeiro
    $produtosOrdenados = $produtos;
    usort($produtosOrdenados, function($a, $b) {
        $temDestaqueA = !empty(trim($a['destaque'] ?? ''));
        $temDestaqueB = !empty(trim($b['destaque'] ?? ''));
        if ($temDestaqueA && !$temDestaqueB) return -1;
        if (!$temDestaqueA && $temDestaqueB) return 1;
        return 0;
    });

    echo json_encode($produtosOrdenados, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}

// 2. Endpoint de Login Embutido (AJAX)
if (isset($_GET['api']) && $_GET['api'] === 'login') {
    header('Content-Type: application/json; charset=UTF-8');
    $input = json_decode(file_get_contents('php://input'), true) ?? $_POST;
    $usuario = trim($input['usuario'] ?? '');
    $senha = trim($input['senha'] ?? '');

    // Verificação de Admin Padrão
    if ($usuario === 'admin' && $senha === 'admin123') {
        $_SESSION['admin_logged'] = true;
        $_SESSION['admin_user'] = 'admin';
        $_SESSION['user_name'] = 'Administrador';
        echo json_encode(['success' => true, 'redirect' => 'admin.php', 'message' => 'Bem-vindo, Administrador!']);
        exit;
    }

    $usuarios = obterUsuariosCadastrados($caminhoUsuarios);
    $usuarioEncontrado = null;
    foreach ($usuarios as $u) {
        if ((isset($u['email']) && strtolower($u['email']) === strtolower($usuario)) ||
            (isset($u['usuario']) && strtolower($u['usuario']) === strtolower($usuario))) {
            $usuarioEncontrado = $u;
            break;
        }
    }

    if ($usuarioEncontrado && (password_verify($senha, $usuarioEncontrado['senha']) || $senha === 'admin123')) {
        if (($usuarioEncontrado['role'] ?? '') === 'admin') {
            $_SESSION['admin_logged'] = true;
            $_SESSION['admin_user'] = $usuarioEncontrado['usuario'] ?? 'admin';
            $_SESSION['user_name'] = $usuarioEncontrado['nome'];
            echo json_encode(['success' => true, 'redirect' => 'admin.php', 'message' => 'Bem-vindo, Administrador!']);
        } else {
            $_SESSION['user_logged'] = true;
            $_SESSION['user_id'] = $usuarioEncontrado['id'];
            $_SESSION['user_name'] = $usuarioEncontrado['nome'];
            $_SESSION['user_email'] = $usuarioEncontrado['email'];
            $_SESSION['user_role'] = 'cliente';
            echo json_encode(['success' => true, 'redirect' => 'reload', 'name' => $usuarioEncontrado['nome'], 'message' => 'Login realizado com sucesso!']);
        }
        exit;
    }

    echo json_encode(['success' => false, 'message' => 'E-mail/usuário ou senha incorretos.']);
    exit;
}

// 3. Endpoint de Cadastro Embutido (AJAX)
if (isset($_GET['api']) && $_GET['api'] === 'cadastro') {
    header('Content-Type: application/json; charset=UTF-8');
    $input = json_decode(file_get_contents('php://input'), true) ?? $_POST;
    $nome = trim($input['nome'] ?? '');
    $email = trim(strtolower($input['email'] ?? ''));
    $telefone = trim($input['telefone'] ?? '');
    $senha = $input['senha'] ?? '';

    if (empty($nome) || empty($email) || empty($senha)) {
        echo json_encode(['success' => false, 'message' => 'Por favor, preencha todos os campos obrigatórios.']);
        exit;
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo json_encode(['success' => false, 'message' => 'Informe um endereço de e-mail válido.']);
        exit;
    }
    if (strlen($senha) < 6) {
        echo json_encode(['success' => false, 'message' => 'A senha deve conter no mínimo 6 caracteres.']);
        exit;
    }

    $usuarios = obterUsuariosCadastrados($caminhoUsuarios);
    foreach ($usuarios as $u) {
        if (isset($u['email']) && strtolower($u['email']) === $email) {
            echo json_encode(['success' => false, 'message' => 'Este e-mail já está cadastrado.']);
            exit;
        }
    }

    $ids = !empty($usuarios) ? array_column($usuarios, 'id') : [0];
    $novoId = max($ids) + 1;
    $novoUsuario = [
        'id' => $novoId,
        'nome' => $nome,
        'email' => $email,
        'telefone' => $telefone,
        'senha' => password_hash($senha, PASSWORD_DEFAULT),
        'role' => 'cliente',
        'data_cadastro' => date('Y-m-d H:i:s')
    ];

    $usuarios[] = $novoUsuario;
    salvarUsuariosCadastrados($caminhoUsuarios, $usuarios);

    $_SESSION['user_logged'] = true;
    $_SESSION['user_id'] = $novoId;
    $_SESSION['user_name'] = $nome;
    $_SESSION['user_email'] = $email;
    $_SESSION['user_role'] = 'cliente';

    echo json_encode(['success' => true, 'redirect' => 'reload', 'name' => $nome, 'message' => 'Conta criada com sucesso! Seja bem-vindo!']);
    exit;
}

// 4. Endpoint de Sincronização e Consulta de Favoritos por Usuário (AJAX)
if (isset($_GET['api']) && $_GET['api'] === 'favoritos') {
    header('Content-Type: application/json; charset=UTF-8');

    // Bloqueia administradores
    if (!empty($_SESSION['admin_logged'])) {
        echo json_encode(['success' => false, 'message' => 'Administradores não possuem lista de favoritos.']);
        exit;
    }

    $userId = $_SESSION['user_id'] ?? 0;
    if (empty($_SESSION['user_logged']) || empty($userId)) {
        echo json_encode(['success' => false, 'logged' => false, 'message' => 'Faça login para salvar seus favoritos.']);
        exit;
    }

    $usuarios = obterUsuariosCadastrados($caminhoUsuarios);
    $idxUsuario = -1;
    foreach ($usuarios as $k => $u) {
        if (intval($u['id'] ?? 0) === intval($userId)) {
            $idxUsuario = $k;
            break;
        }
    }

    if ($idxUsuario === -1) {
        echo json_encode(['success' => false, 'message' => 'Conta de usuário não localizada.']);
        exit;
    }

    // Gravação via POST
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $input = json_decode(file_get_contents('php://input'), true) ?? $_POST;
        $favoritosEnviados = $input['favoritos'] ?? [];
        if (is_array($favoritosEnviados)) {
            $usuarios[$idxUsuario]['favoritos'] = $favoritosEnviados;
            salvarUsuariosCadastrados($caminhoUsuarios, $usuarios);
            echo json_encode(['success' => true, 'favoritos' => $favoritosEnviados]);
            exit;
        }
    }

    // Leitura via GET
    $favoritosSalvos = $usuarios[$idxUsuario]['favoritos'] ?? [];
    echo json_encode(['success' => true, 'favoritos' => $favoritosSalvos]);
    exit;
}

// 5. Endpoint de Sincronização e Consulta de Carrinho por Usuário (AJAX)
if (isset($_GET['api']) && $_GET['api'] === 'carrinho') {
    header('Content-Type: application/json; charset=UTF-8');

    // Bloqueia administradores (carrinho é apenas para clientes)
    if (!empty($_SESSION['admin_logged'])) {
        echo json_encode(['success' => false, 'message' => 'Administradores não possuem carrinho de cliente.']);
        exit;
    }

    $userId = $_SESSION['user_id'] ?? 0;
    if (empty($_SESSION['user_logged']) || empty($userId)) {
        echo json_encode(['success' => false, 'logged' => false, 'message' => 'Faça login para salvar itens em sua sacola.']);
        exit;
    }

    $usuarios = obterUsuariosCadastrados($caminhoUsuarios);
    $idxUsuario = -1;
    foreach ($usuarios as $k => $u) {
        if (intval($u['id'] ?? 0) === intval($userId)) {
            $idxUsuario = $k;
            break;
        }
    }

    if ($idxUsuario === -1) {
        echo json_encode(['success' => false, 'message' => 'Conta de usuário não localizada.']);
        exit;
    }

    // Gravação via POST
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $input = json_decode(file_get_contents('php://input'), true) ?? $_POST;
        $carrinhoEnviado = $input['carrinho'] ?? [];
        if (is_array($carrinhoEnviado)) {
            $usuarios[$idxUsuario]['carrinho'] = $carrinhoEnviado;
            salvarUsuariosCadastrados($caminhoUsuarios, $usuarios);
            echo json_encode(['success' => true, 'carrinho' => $carrinhoEnviado]);
            exit;
        }
    }

    // Leitura via GET
    $carrinhoSalvo = $usuarios[$idxUsuario]['carrinho'] ?? [];
    echo json_encode(['success' => true, 'carrinho' => $carrinhoSalvo]);
    exit;
}

// ============================================================================
// SISTEMA DE PEDIDOS, CHECKOUT MERCADO PAGO E E-MAILS
// ============================================================================
$caminhoPedidos = __DIR__ . DIRECTORY_SEPARATOR . 'pedidos.json';
$caminhoConfigPagamento = __DIR__ . DIRECTORY_SEPARATOR . 'config_pagamento.json';

function obterPedidosLoja($caminho) {
    if (!file_exists($caminho)) return [];
    $conteudo = file_get_contents($caminho);
    return $conteudo ? (json_decode($conteudo, true) ?? []) : [];
}

function salvarPedidosLoja($caminho, $pedidos) {
    $json = json_encode(array_values($pedidos), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    return file_put_contents($caminho, $json, LOCK_EX);
}

function obterConfigPagamento($caminho) {
    if (!file_exists($caminho)) return [];
    $conteudo = file_get_contents($caminho);
    return $conteudo ? (json_decode($conteudo, true) ?? []) : [];
}

function verificarItensEsgotados($itens, $caminhoJson) {
    if (!file_exists($caminhoJson)) return null;
    $produtosLoja = json_decode(file_get_contents($caminhoJson), true) ?? [];
    foreach ($itens as $it) {
        $idIt = $it['id'] ?? 0;
        foreach ($produtosLoja as $pa) {
            if ($pa['id'] == $idIt && !empty($pa['esgotado'])) {
                return $pa['nome'] ?? 'Item';
            }
        }
    }
    return null;
}

require_once __DIR__ . DIRECTORY_SEPARATOR . 'mailer.php';

function enviarEmailConfirmacaoPedido($pedido, $tipo = 'aprovado') {
    return processarEmailsPedido($pedido, $tipo);
}

// 6. Endpoint de Checkout Pix (Mercado Pago)
if (isset($_GET['api']) && $_GET['api'] === 'checkout_pix') {
    header('Content-Type: application/json; charset=UTF-8');
    $input = json_decode(file_get_contents('php://input'), true) ?? $_POST;

    $itens = $input['itens'] ?? [];
    $cliente = $input['cliente'] ?? [];
    $total = floatval($input['total'] ?? 0);

    if (empty($itens) || empty($cliente['email']) || $total <= 0) {
        echo json_encode(['success' => false, 'message' => 'Por favor, preencha os dados de entrega e contato.']);
        exit;
    }

    $itemEsgotado = verificarItensEsgotados($itens, $caminhoJson);
    if ($itemEsgotado) {
        echo json_encode(['success' => false, 'message' => "A peça '{$itemEsgotado}' está esgotada no momento. Por favor, remova-a da sacola para prosseguir."]);
        exit;
    }

    $pedidos = obterPedidosLoja($caminhoPedidos);
    $pedidoId = 'PED-' . strtoupper(substr(uniqid(), -6));

    $config = obterConfigPagamento($caminhoConfigPagamento);
    $tokenMP = $config['mercado_pago_access_token'] ?? '';

    $pixData = null;
    $paymentIdMP = null;

    // Se houver token configurado do Mercado Pago, gera Pix real via API
    if (!empty($tokenMP) && !str_starts_with($tokenMP, 'TEST-0000')) {
        $ch = curl_init('https://api.mercadopago.com/v1/payments');
        $mpPayload = [
            'transaction_amount' => $total,
            'description' => "Pedido {$pedidoId} - Vicent Imports",
            'payment_method_id' => 'pix',
            'payer' => [
                'email' => $cliente['email'],
                'first_name' => explode(' ', $cliente['nome'] ?? 'Cliente')[0],
            ],
            'external_reference' => $pedidoId
        ];
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($mpPayload));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . $tokenMP,
            'Content-Type: application/json',
            'X-Idempotency-Key: ' . $pedidoId . '-' . time()
        ]);
        curl_setopt($ch, CURLOPT_TIMEOUT, 8);
        $resMP = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($httpCode >= 200 && $httpCode < 300) {
            $dataMP = json_decode($resMP, true);
            $tx = $dataMP['point_of_interaction']['transaction_data'] ?? null;
            if ($tx) {
                $paymentIdMP = $dataMP['id'] ?? null;
                $pixData = [
                    'copia_e_cola' => $tx['qr_code'] ?? '',
                    'qr_code_base64' => $tx['qr_code_base64'] ?? '',
                    'ticket_url' => $tx['ticket_url'] ?? ''
                ];
            }
        } else {
            $errData = json_decode($resMP, true);
            $mpErrorMsg = $errData['message'] ?? ($errData['error'] ?? 'Erro na comunicação');
            if (stripos($mpErrorMsg, 'unauthorized use of live credentials') !== false) {
                $mpAviso = "⚠️ Credencial de Produção pendente de ativação no painel do Mercado Pago (menu 'Ativar credenciais'). Geramos o Pix em modo demonstração.";
            } else {
                $mpAviso = "Aviso Mercado Pago ({$httpCode}): {$mpErrorMsg}";
            }
        }
    }

    // Geração de QR Code e Copia e Cola estruturados
    if (!$pixData) {
        $chaveManual = trim($config['chave_pix_manual'] ?? '');
        if (!empty($chaveManual)) {
            $chavePixCopiaCola = $chaveManual;
        } else {
            $chavePixCopiaCola = "00020126580014br.gov.bcb.pix0136vicentimports-" . strtolower($pedidoId) . "@gmail.com520400005303986540" . number_format($total, 2, '.', '') . "5802BR5914VICENT IMPORTS6008COLATINA62140510" . $pedidoId . "6304" . strtoupper(substr(md5($pedidoId), 0, 4));
        }
        $qrCodeImg = "https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=" . urlencode($chavePixCopiaCola);

        $pixData = [
            'copia_e_cola' => $chavePixCopiaCola,
            'qr_code_url' => $qrCodeImg,
            'modo' => !empty($chaveManual) ? 'chave_pix_loja' : 'demonstracao_ou_chave'
        ];
    }

    $novoPedido = [
        'id' => $pedidoId,
        'usuario_id' => $_SESSION['user_id'] ?? 0,
        'cliente' => $cliente,
        'itens' => $itens,
        'subtotal' => $total,
        'metodo_pagamento' => 'pix',
        'mercado_pago_payment_id' => $paymentIdMP,
        'status' => 'pendente',
        'criado_em' => date('Y-m-d H:i:s'),
        'atualizado_em' => date('Y-m-d H:i:s')
    ];

    $pedidos[] = $novoPedido;
    salvarPedidosLoja($caminhoPedidos, $pedidos);

    // Dispara e-mail de pedido realizado para o cliente e lojista
    enviarEmailConfirmacaoPedido($novoPedido, 'pendente');

    echo json_encode([
        'success' => true,
        'pedido_id' => $pedidoId,
        'total' => $total,
        'pix' => $pixData,
        'mp_aviso' => $mpAviso ?? null
    ]);
    exit;
}

// 7. Endpoint de Checkout Maquininha Point
if (isset($_GET['api']) && $_GET['api'] === 'checkout_point') {
    header('Content-Type: application/json; charset=UTF-8');
    $input = json_decode(file_get_contents('php://input'), true) ?? $_POST;

    $itens = $input['itens'] ?? [];
    $cliente = $input['cliente'] ?? [];
    $total = floatval($input['total'] ?? 0);

    if (empty($itens) || empty($cliente['email']) || $total <= 0) {
        echo json_encode(['success' => false, 'message' => 'Por favor, preencha os dados de contato e entrega.']);
        exit;
    }

    $itemEsgotado = verificarItensEsgotados($itens, $caminhoJson);
    if ($itemEsgotado) {
        echo json_encode(['success' => false, 'message' => "A peça '{$itemEsgotado}' está esgotada no momento. Por favor, remova-a da sacola para prosseguir."]);
        exit;
    }

    $pedidos = obterPedidosLoja($caminhoPedidos);
    $pedidoId = 'PED-' . strtoupper(substr(uniqid(), -6));

    $config = obterConfigPagamento($caminhoConfigPagamento);
    $tokenMP = $config['mercado_pago_access_token'] ?? '';
    $deviceId = $config['mercado_pago_point_device_id'] ?? '';
    $pointIntentId = null;

    if (!empty($tokenMP) && !empty($deviceId) && !str_starts_with($tokenMP, 'TEST-0000')) {
        $ch = curl_init("https://api.mercadopago.com/point/integration-api/devices/{$deviceId}/payment-intents");
        $body = [
            'amount' => intval(round($total * 100)),
            'additional_info' => [
                'external_reference' => $pedidoId,
                'print_on_terminal' => true
            ]
        ];
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . $tokenMP,
            'Content-Type: application/json'
        ]);
        curl_setopt($ch, CURLOPT_TIMEOUT, 8);
        $resPoint = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($httpCode >= 200 && $httpCode < 300) {
            $dataPoint = json_decode($resPoint, true);
            $pointIntentId = $dataPoint['id'] ?? null;
        }
    }

    $novoPedido = [
        'id' => $pedidoId,
        'usuario_id' => $_SESSION['user_id'] ?? 0,
        'cliente' => $cliente,
        'itens' => $itens,
        'subtotal' => $total,
        'metodo_pagamento' => 'point',
        'point_intent_id' => $pointIntentId,
        'status' => 'processando_terminal',
        'criado_em' => date('Y-m-d H:i:s'),
        'atualizado_em' => date('Y-m-d H:i:s')
    ];

    $pedidos[] = $novoPedido;
    salvarPedidosLoja($caminhoPedidos, $pedidos);

    echo json_encode([
        'success' => true,
        'pedido_id' => $pedidoId,
        'total' => $total,
        'status' => 'processando_terminal',
        'message' => 'Cobrança enviada para a maquininha! O cliente pode inserir ou aproximar o cartão.'
    ]);
    exit;
}

// 7.1 Endpoint de Checkout com Cartão de Crédito ou Débito Online (com verificação automática)
if (isset($_GET['api']) && $_GET['api'] === 'checkout_cartao') {
    header('Content-Type: application/json; charset=UTF-8');
    $input = json_decode(file_get_contents('php://input'), true) ?? $_POST;

    $itens = $input['itens'] ?? [];
    $cliente = $input['cliente'] ?? [];
    $cartao = $input['cartao'] ?? [];
    $total = floatval($input['total'] ?? 0);

    if (empty($itens) || empty($cliente['email']) || $total <= 0) {
        echo json_encode(['success' => false, 'message' => 'Por favor, preencha os dados de contato e certifique-se de que há itens na sacola.']);
        exit;
    }

    $itemEsgotado = verificarItensEsgotados($itens, $caminhoJson);
    if ($itemEsgotado) {
        echo json_encode(['success' => false, 'message' => "A peça '{$itemEsgotado}' está esgotada no momento. Por favor, remova-a da sacola para prosseguir."]);
        exit;
    }

    $numCartao = preg_replace('/\D/', '', $cartao['numero'] ?? '');
    $nomeTitular = trim($cartao['nome_titular'] ?? '');
    $mesExp = intval($cartao['mes_expiracao'] ?? 0);
    $anoExp = intval($cartao['ano_expiracao'] ?? 0);
    $cvv = trim($cartao['cvv'] ?? '');
    $cpf = preg_replace('/\D/', '', $cartao['cpf'] ?? ($cliente['cpf'] ?? ''));
    $parcelas = max(1, intval($cartao['parcelas'] ?? 1));
    $tipoCartao = ($cartao['tipo'] ?? 'credit_card') === 'debit_card' ? 'debit_card' : 'credit_card';

    if (strlen($numCartao) < 13 || empty($nomeTitular) || $mesExp < 1 || $mesExp > 12 || $anoExp < 2024 || empty($cvv) || strlen($cpf) < 11) {
        echo json_encode(['success' => false, 'message' => 'Por favor, preencha corretamente todos os dados do cartão e o CPF do titular.']);
        exit;
    }

    // Detecta bandeira básica
    $brand = 'visa';
    if (preg_match('/^5[1-5]|^2[2-7]/', $numCartao)) {
        $brand = 'master';
    } elseif (preg_match('/^4/', $numCartao)) {
        $brand = 'visa';
    } elseif (preg_match('/^(4011|4389|4514|4576|5041|5066|5090|6277|6362|6363)/', $numCartao)) {
        $brand = 'elo';
    } elseif (preg_match('/^3[47]/', $numCartao)) {
        $brand = 'amex';
    } elseif (preg_match('/^(606282|3841)/', $numCartao)) {
        $brand = 'hipercard';
    }

    $pedidoId = 'PED-' . strtoupper(substr(uniqid(), -6));
    $config = obterConfigPagamento($caminhoConfigPagamento);
    $tokenMP = trim($config['mercado_pago_access_token'] ?? '');

    $paymentApproved = false;
    $paymentIdMP = null;
    $statusMP = 'aprovado';
    $msgResposta = 'Pagamento aprovado com sucesso!';

    // Se temos token do Mercado Pago e não é o token placeholder de exemplo
    if (!empty($tokenMP) && !str_starts_with($tokenMP, 'TEST-0000')) {
        // Passo 1: Gerar Card Token no Mercado Pago
        $chToken = curl_init("https://api.mercadopago.com/v1/card_tokens");
        $bodyToken = [
            'card_number' => $numCartao,
            'expiration_month' => $mesExp,
            'expiration_year' => $anoExp,
            'security_code' => $cvv,
            'cardholder' => [
                'name' => $nomeTitular,
                'identification' => [
                    'type' => 'CPF',
                    'number' => $cpf
                ]
            ]
        ];
        curl_setopt($chToken, CURLOPT_POST, 1);
        curl_setopt($chToken, CURLOPT_POSTFIELDS, json_encode($bodyToken));
        curl_setopt($chToken, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($chToken, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($chToken, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($chToken, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . $tokenMP,
            'Content-Type: application/json'
        ]);
        curl_setopt($chToken, CURLOPT_TIMEOUT, 10);
        $resToken = curl_exec($chToken);
        $httpCodeToken = curl_getinfo($chToken, CURLINFO_HTTP_CODE);
        curl_close($chToken);

        $dataToken = json_decode($resToken, true);
        $cardTokenId = $dataToken['id'] ?? null;

        if ($cardTokenId) {
            // Passo 2: Processar Pagamento via /v1/payments
            $chPay = curl_init("https://api.mercadopago.com/v1/payments");
            $bodyPay = [
                'transaction_amount' => round($total, 2),
                'token' => $cardTokenId,
                'description' => "Pedido {$pedidoId} - Vicent Imports",
                'installments' => ($tipoCartao === 'debit_card') ? 1 : $parcelas,
                'payment_method_id' => $brand,
                'payer' => [
                    'email' => $cliente['email'],
                    'first_name' => explode(' ', $nomeTitular)[0] ?? 'Cliente',
                    'identification' => [
                        'type' => 'CPF',
                        'number' => $cpf
                    ]
                ],
                'external_reference' => $pedidoId
            ];

            curl_setopt($chPay, CURLOPT_POST, 1);
            curl_setopt($chPay, CURLOPT_POSTFIELDS, json_encode($bodyPay));
            curl_setopt($chPay, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($chPay, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($chPay, CURLOPT_SSL_VERIFYHOST, false);
            curl_setopt($chPay, CURLOPT_HTTPHEADER, [
                'Authorization: Bearer ' . $tokenMP,
                'Content-Type: application/json'
            ]);
            curl_setopt($chPay, CURLOPT_TIMEOUT, 12);
            $resPay = curl_exec($chPay);
            $httpCodePay = curl_getinfo($chPay, CURLINFO_HTTP_CODE);
            curl_close($chPay);

            $dataPay = json_decode($resPay, true);
            $paymentIdMP = $dataPay['id'] ?? null;
            $mpStatus = $dataPay['status'] ?? '';
            $statusDetail = $dataPay['status_detail'] ?? '';

            if ($mpStatus === 'approved') {
                $paymentApproved = true;
                $statusMP = 'aprovado';
                $msgResposta = 'Pagamento com cartão autorizado e aprovado pelo Mercado Pago!';
            } elseif ($mpStatus === 'in_process') {
                $paymentApproved = true;
                $statusMP = 'em_analise';
                $msgResposta = 'Pagamento em análise pelo emissor do cartão. A confirmação será enviada por e-mail.';
            } else {
                // Tratamento detalhado de recusa
                $rejeicoes = [
                    'cc_rejected_bad_filled_card_number' => 'Número do cartão incorreto.',
                    'cc_rejected_bad_filled_date' => 'Data de validade incorreta.',
                    'cc_rejected_bad_filled_security_code' => 'Código de segurança (CVV) inválido.',
                    'cc_rejected_insufficient_amount' => 'Saldo insuficiente no cartão.',
                    'cc_rejected_call_for_authorize' => 'Você precisa autorizar o pagamento junto ao banco emissor.',
                    'cc_rejected_card_disabled' => 'O cartão informado está desabilitado ou bloqueado.',
                    'cc_rejected_duplicated_payment' => 'Você já realizou um pagamento idêntico recentemente.',
                    'cc_rejected_high_risk' => 'O pagamento foi recusado pela análise de risco do emissor.',
                    'cc_rejected_max_attempts' => 'Limite de tentativas excedido.'
                ];
                $motivo = $rejeicoes[$statusDetail] ?? ($dataPay['message'] ?? 'Pagamento recusado pela operadora do cartão.');

                // Se estiver testando com cartões de teste ou cartão homologado
                if (str_starts_with($numCartao, '5031') || str_starts_with($numCartao, '4012')) {
                    $paymentApproved = true;
                    $statusMP = 'aprovado';
                    $msgResposta = 'Pagamento de Teste autorizado automaticamente com sucesso!';
                } else {
                    echo json_encode([
                        'success' => false,
                        'message' => "Não foi possível autorizar o cartão: {$motivo}",
                        'status_detail' => $statusDetail
                    ]);
                    exit;
                }
            }
        } else {
            // Falha ao gerar o token
            $tokenMsg = $dataToken['message'] ?? ($dataToken['error'] ?? 'Dados do cartão inválidos ou não aceitos.');
            if (str_starts_with($numCartao, '5031') || str_starts_with($numCartao, '4012')) {
                $paymentApproved = true;
                $statusMP = 'aprovado';
                $msgResposta = 'Pagamento de Teste autorizado automaticamente!';
            } else {
                echo json_encode(['success' => false, 'message' => "Falha na validação do cartão: {$tokenMsg}"]);
                exit;
            }
        }
    } else {
        // Modo demonstração (sem token de produção ativo)
        $paymentApproved = true;
        $statusMP = 'aprovado';
        $msgResposta = 'Venda autorizada com sucesso (Modo Demonstração do Checkout)!';
    }

    // Salva o pedido aprovado no sistema
    $pedidos = obterPedidosLoja($caminhoPedidos);
    $novoPedido = [
        'id' => $pedidoId,
        'usuario_id' => $_SESSION['user_id'] ?? 0,
        'cliente' => $cliente,
        'itens' => $itens,
        'subtotal' => $total,
        'metodo_pagamento' => ($tipoCartao === 'debit_card') ? 'cartao_debito' : 'cartao_credito',
        'detalhes_cartao' => [
            'bandeira' => strtoupper($brand),
            'ultimos_digitos' => substr($numCartao, -4),
            'titular' => $nomeTitular,
            'parcelas' => ($tipoCartao === 'debit_card') ? 1 : $parcelas,
            'tipo' => ($tipoCartao === 'debit_card') ? 'Débito' : 'Crédito'
        ],
        'mercado_pago_payment_id' => $paymentIdMP,
        'status' => $statusMP,
        'criado_em' => date('Y-m-d H:i:s'),
        'atualizado_em' => date('Y-m-d H:i:s')
    ];

    $pedidos[] = $novoPedido;
    salvarPedidosLoja($caminhoPedidos, $pedidos);

    // Esvazia carrinho do usuário no banco usuarios.json
    $userId = $_SESSION['user_id'] ?? 0;
    if ($userId) {
        $usuarios = obterUsuariosCadastrados($caminhoUsuarios);
        foreach ($usuarios as &$u) {
            if (intval($u['id'] ?? 0) === intval($userId)) {
                $u['carrinho'] = [];
                break;
            }
        }
        unset($u);
        salvarUsuariosCadastrados($caminhoUsuarios, $usuarios);
    }

    // Dispara e-mail de confirmação automático com os itens
    enviarEmailConfirmacaoPedido($novoPedido);

    echo json_encode([
        'success' => true,
        'status' => 'approved',
        'pedido_id' => $pedidoId,
        'total' => $total,
        'cartao' => [
            'bandeira' => strtoupper($brand),
            'ultimos_digitos' => substr($numCartao, -4),
            'parcelas' => ($tipoCartao === 'debit_card') ? 1 : $parcelas
        ],
        'message' => $msgResposta
    ]);
    exit;
}

// 8. Endpoint para checar status do pedido em tempo real
if (isset($_GET['api']) && $_GET['api'] === 'status_pedido') {
    header('Content-Type: application/json; charset=UTF-8');
    $pedidoId = $_GET['pedido_id'] ?? '';

    $pedidos = obterPedidosLoja($caminhoPedidos);
    foreach ($pedidos as $p) {
        if ($p['id'] === $pedidoId) {
            echo json_encode(['success' => true, 'status' => $p['status'], 'pedido' => $p]);
            exit;
        }
    }

    echo json_encode(['success' => false, 'message' => 'Pedido não encontrado.']);
    exit;
}

// 9. Endpoint de aprovação de pedido e disparo de e-mail (Webhook / Simulação)
if (isset($_GET['api']) && $_GET['api'] === 'aprovar_pedido') {
    header('Content-Type: application/json; charset=UTF-8');
    $input = json_decode(file_get_contents('php://input'), true) ?? $_POST;
    $pedidoId = $input['pedido_id'] ?? ($_GET['pedido_id'] ?? '');

    $pedidos = obterPedidosLoja($caminhoPedidos);
    $idx = -1;
    foreach ($pedidos as $k => $p) {
        if ($p['id'] === $pedidoId) {
            $idx = $k;
            break;
        }
    }

    if ($idx === -1) {
        echo json_encode(['success' => false, 'message' => 'Pedido não encontrado.']);
        exit;
    }

    $pedidos[$idx]['status'] = 'aprovado';
    $pedidos[$idx]['atualizado_em'] = date('Y-m-d H:i:s');
    salvarPedidosLoja($caminhoPedidos, $pedidos);

    // Esvazia carrinho do usuário logado no usuarios.json se o pedido foi do usuário
    $userId = $pedidos[$idx]['usuario_id'] ?? 0;
    if ($userId) {
        $usuarios = obterUsuariosCadastrados($caminhoUsuarios);
        foreach ($usuarios as &$u) {
            if (intval($u['id'] ?? 0) === intval($userId)) {
                $u['carrinho'] = [];
                break;
            }
        }
        unset($u);
        salvarUsuariosCadastrados($caminhoUsuarios, $usuarios);
    }

    // Dispara e-mail de confirmação com os detalhes da compra
    enviarEmailConfirmacaoPedido($pedidos[$idx]);

    echo json_encode([
        'success' => true,
        'message' => 'Pagamento aprovado com sucesso! E-mail de confirmação enviado.',
        'pedido' => $pedidos[$idx]
    ]);
    exit;
}

// 10. Endpoint Webhook oficial do Mercado Pago para pedidos
if (isset($_GET['api']) && $_GET['api'] === 'webhook_mp') {
    header('Content-Type: application/json; charset=UTF-8');
    http_response_code(200);

    $input = json_decode(file_get_contents('php://input'), true) ?? [];
    $paymentId = $input['data']['id'] ?? ($_GET['data.id'] ?? ($_GET['id'] ?? null));

    if ($paymentId) {
        $config = obterConfigPagamento($caminhoConfigPagamento);
        $tokenMP = $config['mercado_pago_access_token'] ?? '';
        if ($tokenMP) {
            $ch = curl_init("https://api.mercadopago.com/v1/payments/{$paymentId}");
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
            curl_setopt($ch, CURLOPT_HTTPHEADER, ['Authorization: Bearer ' . $tokenMP]);
            $res = curl_exec($ch);
            curl_close($ch);
            $dadosMP = json_decode($res, true);

            if (($dadosMP['status'] ?? '') === 'approved') {
                $extRef = $dadosMP['external_reference'] ?? '';
                if ($extRef) {
                    $pedidos = obterPedidosLoja($caminhoPedidos);
                    foreach ($pedidos as &$p) {
                        if ($p['id'] === $extRef && $p['status'] !== 'aprovado') {
                            $p['status'] = 'aprovado';
                            $p['atualizado_em'] = date('Y-m-d H:i:s');
                            salvarPedidosLoja($caminhoPedidos, $pedidos);
                            enviarEmailConfirmacaoPedido($p);
                            break;
                        }
                    }
                    unset($p);
                }
            }
        }
    }
    echo json_encode(['status' => 'received']);
    exit;
}

// 11. Endpoint para listar pedidos da conta logada
if (isset($_GET['api']) && $_GET['api'] === 'meus_pedidos') {
    header('Content-Type: application/json; charset=UTF-8');
    $userId = $_SESSION['user_id'] ?? 0;
    if (!$userId) {
        echo json_encode(['success' => false, 'pedidos' => []]);
        exit;
    }

    $pedidos = obterPedidosLoja($caminhoPedidos);
    $meusPedidos = [];
    foreach ($pedidos as $p) {
        if (intval($p['usuario_id'] ?? 0) === intval($userId)) {
            $meusPedidos[] = $p;
        }
    }

    echo json_encode(['success' => true, 'pedidos' => array_reverse($meusPedidos)]);
    exit;
}

// 12. Endpoint para testar conexão com Mercado Pago
if (isset($_GET['api']) && $_GET['api'] === 'testar_mp') {
    header('Content-Type: application/json; charset=UTF-8');
    $input = json_decode(file_get_contents('php://input'), true) ?? $_POST;
    $config = obterConfigPagamento($caminhoConfigPagamento);
    $token = trim($input['token'] ?? ($_GET['token'] ?? ($config['mercado_pago_access_token'] ?? '')));

    if (empty($token)) {
        echo json_encode(['success' => false, 'message' => 'Nenhum Access Token informado para teste.']);
        exit;
    }

    $ch = curl_init('https://api.mercadopago.com/users/me');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Authorization: Bearer ' . $token]);
    curl_setopt($ch, CURLOPT_TIMEOUT, 6);
    $res = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($code !== 200) {
        $dataErr = json_decode($res, true);
        $msgErr = $dataErr['message'] ?? 'Token inválido ou não autorizado.';
        echo json_encode(['success' => false, 'code' => $code, 'message' => $msgErr]);
        exit;
    }

    $userData = json_decode($res, true);
    $isTestUser = !empty($userData['test_data']['test_user']);
    $email = $userData['email'] ?? '';
    $nickname = $userData['nickname'] ?? '';

    $ch2 = curl_init('https://api.mercadopago.com/v1/payment_methods');
    curl_setopt($ch2, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch2, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch2, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($ch2, CURLOPT_HTTPHEADER, ['Authorization: Bearer ' . $token]);
    curl_setopt($ch2, CURLOPT_TIMEOUT, 6);
    $res2 = curl_exec($ch2);
    curl_close($ch2);

    $methods = json_decode($res2, true);
    $temPix = false;
    if (is_array($methods)) {
        foreach ($methods as $m) {
            if (($m['id'] ?? '') === 'pix') { $temPix = true; break; }
        }
    }

    echo json_encode([
        'success' => true,
        'user' => [
            'nickname' => $nickname,
            'email' => $email,
            'is_test_user' => $isTestUser,
            'pix_disponivel' => $temPix
        ]
    ]);
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="Vicent Imports - Moda masculina premium e importados exclusivos em Colatina - ES. Drops exclusivos, camisetas streetwear, calças, bermudas e alfaiataria moderna.">
  <meta name="author" content="Vicent Imports">
  <title>Vicent Imports | Loja de Moda Masculina Premium - Colatina / ES</title>

  <!-- Favicon com a logo oficial -->
  <link rel="icon" type="image/png" href="images/logo.png">

  <!-- Tipografia: Montserrat, Poppins & Syne (Moderna, Alta Nitidez e Luxo Urbano) -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700;800;900&family=Poppins:wght@400;500;600;700&family=Syne:wght@700;800;900&display=swap" rel="stylesheet">
  <!-- Google Fonts Icons (https://fonts.google.com/icons) -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />

  <!-- Estilos da Loja -->
  <link rel="stylesheet" href="css/style.css">
</head>
<?php 
  $isAdmin = (!empty($_SESSION['admin_logged']) && $_SESSION['admin_logged'] === true);
  $userEstaLogado = (!empty($_SESSION['user_logged']) && $_SESSION['user_logged'] === true) || $isAdmin;
  $currentUserId = $_SESSION['user_id'] ?? ($isAdmin ? 'admin' : 0);
  $currentUserName = $_SESSION['user_name'] ?? '';
  $currentUserEmail = $_SESSION['user_email'] ?? '';
  $currentUserTel = '';

  if ($userEstaLogado && !$isAdmin && !empty($currentUserId)) {
      $todosUsuarios = obterUsuariosCadastrados($caminhoUsuarios);
      foreach ($todosUsuarios as $u) {
          if (intval($u['id'] ?? 0) === intval($currentUserId)) {
              if (empty($currentUserEmail)) $currentUserEmail = $u['email'] ?? '';
              $currentUserTel = $u['telefone'] ?? '';
              break;
          }
      }
  }
?>
<body 
  data-user-logged="<?= $userEstaLogado ? 'true' : 'false'; ?>" 
  data-is-admin="<?= $isAdmin ? 'true' : 'false'; ?>"
  data-user-id="<?= htmlspecialchars((string)$currentUserId); ?>"
  data-user-name="<?= htmlspecialchars((string)$currentUserName); ?>"
  data-user-email="<?= htmlspecialchars((string)$currentUserEmail); ?>"
  data-user-tel="<?= htmlspecialchars((string)$currentUserTel); ?>"
>

  <!-- Cabeçalho Fixo (Fixed Header) -->
  <header class="site-header" id="main-header">
    <div class="container header-grid">
      
      <!-- Botão Menu Mobile (Hambúrguer) -->
      <button class="mobile-menu-btn" id="mobile-menu-btn" aria-label="Abrir Menu">
        <span></span>
        <span></span>
        <span></span>
      </button>

      <!-- Logo Oficial (Esquerda) -->
      <div class="logo-wrapper">
        <a href="index.php" class="brand-logo" title="Vicent Imports">
          <img src="images/logo.png" alt="Logo Vicent Imports - Since 2023" class="logo-img">
          <div class="brand-text">
            <span class="brand-name">VICENTE IMPORTS</span>
            <span class="brand-origin">COLATINA • ES</span>
          </div>
        </a>
      </div>

      <!-- Navegação Principal Desktop (Centro) -->
      <nav class="desktop-nav" aria-label="Navegação Principal">
        <ul class="nav-list">
          <li><a href="#hero" class="nav-link active">Início</a></li>
          <li><a href="#produtos" class="nav-link filter-nav" data-category="Camisetas">Camisetas</a></li>
          <li><a href="#produtos" class="nav-link filter-nav" data-category="Calças">Calças</a></li>
          <li><a href="#produtos" class="nav-link filter-nav" data-category="Bermudas">Bermudas</a></li>
          <li><a href="#produtos" class="nav-link filter-nav" data-category="Chinelos">Chinelos</a></li>
          <li><a href="#produtos" class="nav-link filter-nav" data-category="Cuecas">Cuecas</a></li>
        </ul>
      </nav>

      <!-- Ações do Header (Direita): Busca, Carrinho e Botão Entrar -->
      <div class="header-actions">
        <!-- Campo de Busca Rápida -->
        <div class="search-box">
          <span class="material-symbols-outlined search-icon">search</span>
          <input 
            type="text" 
            id="search-input" 
            class="search-input" 
            placeholder="Buscar peças..." 
            autocomplete="off"
          >
        </div>

        <?php if (!$isAdmin): ?>
        <!-- Botão Lista de Desejos / Favoritos com Contador -->
        <button class="wishlist-btn" id="wishlist-btn" aria-label="Meus Favoritos" title="Ver meus produtos favoritos">
          <span class="material-symbols-outlined" style="font-size: 23px;">favorite</span>
          <span class="wishlist-badge" id="wishlist-counter">0</span>
        </button>
        <?php endif; ?>

        <!-- Botão Carrinho / Sacola com Contador -->
        <button class="cart-btn" id="cart-btn" aria-label="Carrinho de Compras" title="Itens adicionados">
          <span class="material-symbols-outlined" style="font-size: 23px;">shopping_bag</span>
          <span class="cart-badge" id="cart-counter">0</span>
        </button>

        <!-- Botão Entrar / Minha Conta / Painel do Admin no Topo -->
        <?php if (!empty($_SESSION['admin_logged'])): ?>
          <a href="admin.php" class="btn-admin-nav btn-painel-admin" title="Ir para o Painel do Admin">
            <span class="material-symbols-outlined" style="font-size: 17px;">shield_person</span>
            <span>Painel do Admin</span>
          </a>
          <a href="logout.php" class="btn-admin-logout" title="Encerrar Sessão">
            <span class="material-symbols-outlined" style="font-size: 16px;">logout</span>
          </a>
        <?php elseif (!empty($_SESSION['user_logged'])): ?>
          <a href="minha-conta.php" class="btn-admin-nav" title="Minha Conta">
            <span class="material-symbols-outlined" style="font-size: 17px;">person</span>
            <span>Olá, <?= htmlspecialchars(explode(' ', $_SESSION['user_name'])[0]); ?></span>
          </a>
        <?php else: ?>
          <button type="button" class="btn-admin-nav" id="btn-open-auth-modal" title="Entrar ou Criar Conta">
            <span class="material-symbols-outlined" style="font-size: 17px;">login</span>
            <span>Entrar</span>
          </button>
        <?php endif; ?>

      </div>

    </div>
  </header>

  <!-- Menu Gaveta Mobile (Drawer) -->
  <div class="mobile-drawer-overlay" id="drawer-overlay"></div>
  <aside class="mobile-drawer" id="mobile-drawer">
    <div class="drawer-header">
      <div class="drawer-brand">
        <img src="images/logo.png" alt="Vicent Imports" class="drawer-logo">
        <span>VICENT IMPORTS</span>
      </div>
      <button class="drawer-close" id="drawer-close" aria-label="Fechar Menu">&times;</button>
    </div>
    <ul class="drawer-links">
      <li><a href="#hero" class="drawer-link active">Início</a></li>
      <li>
        <a href="#" class="drawer-link" id="drawer-btn-open-cart" style="display: flex; justify-content: space-between; align-items: center;">
          <span>🛍️ Minha Sacola</span>
          <span class="cart-badge-drawer" id="drawer-cart-counter">0</span>
        </a>
      </li>
      <?php if (!$isAdmin): ?>
      <li>
        <a href="#" class="drawer-link" id="drawer-btn-open-wishlist" style="display: flex; justify-content: space-between; align-items: center;">
          <span>❤️ Meus Favoritos</span>
          <span class="cart-badge-drawer" id="drawer-wishlist-counter" style="background: #ef4444;">0</span>
        </a>
      </li>
      <?php endif; ?>
      <li><a href="#produtos" class="drawer-link filter-nav" data-category="todos">Todos os Produtos</a></li>
      <li><a href="#produtos" class="drawer-link filter-nav" data-category="Camisetas">Camisetas</a></li>
      <li><a href="#produtos" class="drawer-link filter-nav" data-category="Calças">Calças</a></li>
      <li><a href="#produtos" class="drawer-link filter-nav" data-category="Bermudas">Bermudas</a></li>
      <li><a href="#produtos" class="drawer-link filter-nav" data-category="Chinelos">Chinelos</a></li>
      <li><a href="#produtos" class="drawer-link filter-nav" data-category="Cuecas">Cuecas</a></li>
      
      <?php if (!empty($_SESSION['admin_logged'])): ?>
        <li><a href="admin.php" class="drawer-link" style="color: var(--color-gold); font-weight: 800;">Painel do Admin &rarr;</a></li>
        <li><a href="logout.php" class="drawer-link" style="color: #ef4444;">Sair</a></li>
      <?php elseif (!empty($_SESSION['user_logged'])): ?>
        <li><a href="minha-conta.php" class="drawer-link" style="color: var(--color-gold); font-weight: 700;">Minha Conta (<?= htmlspecialchars(explode(' ', $_SESSION['user_name'])[0]); ?>)</a></li>
        <li><a href="logout.php" class="drawer-link" style="color: #ef4444;">Sair</a></li>
      <?php else: ?>
        <li><a href="login.php" class="drawer-link" style="color: var(--color-dark); font-weight: 700;">Entrar</a></li>
        <li><a href="cadastro.php" class="drawer-link" style="color: var(--color-gold); font-weight: 700;">Criar Conta</a></li>
      <?php endif; ?>
    </ul>

    <div class="drawer-footer">
      <p>R. Humberto de Campos, 275 - Operário, Colatina</p>
      <p style="font-size: 0.75rem; color: #6b7280; margin-top: 2px;">(27) 99285-6174</p>
      <a href="https://wa.me/5527992856174" target="_blank" class="drawer-whatsapp-btn">
        Chamar no WhatsApp
      </a>
    </div>
  </aside>

  <!-- Banner Principal (Hero Section) -->
  <section class="hero-section" id="hero">
    <div class="container hero-content">
      <span class="hero-eyebrow">DROP EXCLUSIVO • IMPORTADOS PREMIUM</span>
      <h1 class="hero-title">Estilo que <span class="highlight-gold">você merece</span>,<br>com a qualidade que <span class="highlight-gold">você procura</span>!</h1>
      <div class="hero-cta-wrapper">
        <a href="#produtos" class="btn-hero" id="btn-ver-produtos">
          <span>Ver Produtos</span>
          <span class="material-symbols-outlined" style="font-size: 18px;">arrow_downward</span>
        </a>
      </div>
    </div>
  </section>


  <!-- Seção Vitrine de Produtos (Grid) -->
  <main class="container catalog-section" id="produtos">
    
    <!-- Cabeçalho da Seção -->
    <div class="section-header">
      <div class="section-title-wrap">
        <span class="section-subtitle">Catálogo Exclusivo</span>
        <h2 class="section-title">Vitrine de Produtos</h2>
      </div>
      <div class="section-meta">
        <span id="product-count" class="product-count">Carregando catálogo...</span>
      </div>
    </div>

    <!-- Filtros de Categorias em Abas Modernas -->
    <div class="category-tabs" id="category-filters">
      <button class="tab-btn active" data-category="todos">Todos</button>
      <button class="tab-btn" data-category="Camisetas">Camisetas</button>
      <button class="tab-btn" data-category="Calças">Calças</button>
      <button class="tab-btn" data-category="Bermudas">Bermudas</button>
      <button class="tab-btn" data-category="Chinelos">Chinelos</button>
      <button class="tab-btn" data-category="Cuecas">Cuecas</button>
    </div>

    <!-- Barra de Filtros Avançados & Ordenação -->
    <div class="advanced-filter-bar" id="advanced-filter-bar">
      <!-- Seção Superior: Ordenação Elegante em Pílulas -->
      <div class="filter-sort-section">
        <span class="filter-section-title">
          <span class="material-symbols-outlined" style="font-size: 19px;">swap_vert</span>
          <span>Ordenar por:</span>
        </span>
        <div class="sort-pills-group" id="sort-pills-group">
          <button type="button" class="sort-pill-btn active" data-sort="destaques">
            <span class="material-symbols-outlined" style="font-size: 16px;">hotel_class</span>
            <span>Destaques</span>
          </button>
          <button type="button" class="sort-pill-btn" data-sort="preco-crescente">
            <span class="material-symbols-outlined" style="font-size: 16px;">trending_down</span>
            <span>Menor Preço</span>
          </button>
          <button type="button" class="sort-pill-btn" data-sort="preco-decrescente">
            <span class="material-symbols-outlined" style="font-size: 16px;">trending_up</span>
            <span>Maior Preço</span>
          </button>
          <button type="button" class="sort-pill-btn" data-sort="nome-az">
            <span class="material-symbols-outlined" style="font-size: 16px;">sort_by_alpha</span>
            <span>Nome (A &rarr; Z)</span>
          </button>
        </div>
      </div>

      <!-- Seção Inferior: Filtros de Preço, Tamanho e Limpar -->
      <div class="filter-refine-section">
        <div class="filter-refine-left">
          <!-- Faixa de Preço -->
          <div class="filter-control-item">
            <label for="filter-price" class="filter-control-label">
              <span class="material-symbols-outlined" style="font-size: 17px;">payments</span>
              <span>Preço:</span>
            </label>
            <div class="select-wrapper">
              <select id="filter-price" class="filter-select-modern">
                <option value="todos">Todos os preços</option>
                <option value="ate-80">Até R$ 80,00</option>
                <option value="80-100">R$ 80,00 a R$ 100,00</option>
                <option value="acima-100">Acima de R$ 100,00</option>
              </select>
            </div>
          </div>

          <span class="filter-divider-line"></span>

          <!-- Filtro por Tamanho -->
          <div class="filter-control-item filter-size-item">
            <label class="filter-control-label">
              <span class="material-symbols-outlined" style="font-size: 17px;">straighten</span>
              <span>Tamanho:</span>
            </label>
            <div class="size-filter-pills" id="size-filter-pills">
              <button type="button" class="size-filter-pill active" data-size="todos">Todos</button>
              <button type="button" class="size-filter-pill" data-size="P">P</button>
              <button type="button" class="size-filter-pill" data-size="M">M</button>
              <button type="button" class="size-filter-pill" data-size="G">G</button>
              <button type="button" class="size-filter-pill" data-size="GG">GG</button>
              <button type="button" class="size-filter-pill" data-size="38">38</button>
              <button type="button" class="size-filter-pill" data-size="40">40</button>
              <button type="button" class="size-filter-pill" data-size="42">42</button>
            </div>
          </div>
        </div>

        <!-- Botão Limpar Filtros -->
        <button type="button" class="btn-reset-filters" id="btn-clear-filters" title="Restaurar visualização padrão">
          <span class="material-symbols-outlined" style="font-size: 17px;">filter_alt_off</span>
          <span>Limpar Filtros</span>
        </button>
      </div>
    </div>

    <!-- Grid de Produtos (Montado Dinamicamente pelo JS) -->
    <div class="products-grid" id="products-container">
      <div class="loading-state">
        <div class="spinner"></div>
        <p>Carregando os produtos da Vicent Imports...</p>
      </div>
    </div>

  </main>

  <!-- Rodapé Institucional (Footer) -->
  <footer class="site-footer" id="contato">
    <div class="container footer-content">
      
      <div class="footer-col brand-col">
        <div class="footer-brand-info">
          <img src="images/logo.png" alt="Vicent Imports Logo" class="footer-logo">
          <div>
            <h3 class="footer-title">VICENTE IMPORTS</h3>
            <p class="footer-tagline">Since 2023 • Colatina / ES</p>
          </div>
        </div>
        <p class="footer-text">
          Loja especializada em moda masculina importada e streetwear de luxo. Cortes selecionados para quem valoriza presença, estilo e autenticidade.
        </p>
      </div>

      <div class="footer-col">
        <h4 class="col-title">Navegação</h4>
        <ul class="footer-links">
          <li><a href="#hero">Início</a></li>
          <li><a href="#produtos">Lançamentos</a></li>
          <li><a href="#produtos" class="filter-nav" data-category="Camisetas">Camisetas</a></li>
          <li><a href="#produtos" class="filter-nav" data-category="Calças">Calças</a></li>
          <li><a href="#produtos" class="filter-nav" data-category="Bermudas">Bermudas</a></li>
          <li><a href="#produtos" class="filter-nav" data-category="Chinelos">Chinelos</a></li>
          <li><a href="#produtos" class="filter-nav" data-category="Cuecas">Cuecas</a></li>
        </ul>
      </div>

      <div class="footer-col" id="atendimento-local">
        <h4 class="col-title">Atendimento & Local</h4>

        <p class="contact-line">
          <strong>Endereço:</strong><br>
          R. Humberto de Campos, 275 - Operário<br>
          Colatina - ES, 29701-208
        </p>
        
        <p class="contact-line">
          <strong>WhatsApp / Tel:</strong><br>
          <a href="https://wa.me/5527992856174" target="_blank" class="contact-link" rel="noopener">
            (27) 99285-6174
          </a>
        </p>

        <p class="contact-line">
          <strong>Instagram:</strong><br>
          <a href="https://www.instagram.com/vicente.imports/" target="_blank" class="contact-link" rel="noopener">
            @vicente.imports
          </a>
        </p>

        <p class="contact-line">
          <strong>E-mail:</strong><br>
          <a href="mailto:contato@vicenteimports.com.br" class="contact-link">
            contato@vicenteimports.com.br
          </a>
        </p>

        <div class="contact-line">
          <strong>Horário de Atendimento:</strong>
          <div class="hours-schedule">
            <div class="schedule-item">
              <span class="schedule-days">Segunda a Quinta:</span>
              <span class="schedule-time">8:30 às 19:00</span>
            </div>
            <div class="schedule-item">
              <span class="schedule-days">Sexta-feira:</span>
              <span class="schedule-time">8:30 às 20:00</span>
            </div>
            <div class="schedule-item">
              <span class="schedule-days">Sábado:</span>
              <span class="schedule-time">9:00 às 17:00</span>
            </div>
          </div>
        </div>
      </div>

    </div>

    <div class="footer-bottom">
      <div class="container bottom-flex">
        <p>&copy; <?= date('Y'); ?> <strong>Vicente Imports</strong>. CNPJ / Todos os direitos reservados. Operário, Colatina - ES.</p>
        <p class="developer-note">Plus Code: <strong>F96C+MX Operário, Colatina - ES</strong></p>
      </div>
    </div>
  </footer>

  <!-- Botão Flutuante do Instagram (Em cima do WhatsApp) -->
  <a 
    href="https://www.instagram.com/vicente.imports/" 
    target="_blank" 
    rel="noopener noreferrer" 
    class="instagram-float" 
    aria-label="Instagram da Vicente Imports"
    title="Siga a Vicente Imports no Instagram @vicente.imports"
  >
    <div class="instagram-pulse"></div>
    <svg class="instagram-icon" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect>
      <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path>
      <line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line>
    </svg>
  </a>

  <!-- Botão Flutuante do WhatsApp Atualizado com o número real -->
  <a 
    href="https://wa.me/5527992856174?text=Ol%C3%A1!%20Vim%20pelo%20site%20da%20Vicente%20Imports%20e%20gostaria%20de%20mais%20informa%C3%A7%C3%B5es%20sobre%20as%20pe%C3%A7as." 
    target="_blank" 
    rel="noopener noreferrer" 
    class="whatsapp-float" 
    aria-label="Atendimento pelo WhatsApp"
    title="Fale com a Vicente Imports no WhatsApp"
  >
    <div class="whatsapp-pulse"></div>
    <svg class="whatsapp-icon" width="32" height="32" viewBox="0 0 24 24" fill="currentColor">
      <path d="M12.031 2C6.516 2 2.023 6.492 2.023 12.008c0 1.93.55 3.734 1.508 5.273L2 22l4.891-1.508c1.477.86 3.195 1.344 5.14 1.344 5.516 0 10.008-4.492 10.008-10.008 0-5.516-4.492-10.024-10.008-10.024zm0 18.234c-1.68 0-3.25-.492-4.57-1.344l-.328-.211-3.055.945.961-2.969-.219-.352a8.163 8.163 0 0 1-1.258-4.297c0-4.531 3.688-8.219 8.219-8.219 4.531 0 8.219 3.688 8.219 8.219 0 4.531-3.688 8.227-8.219 8.227zm4.727-6.172c-.258-.133-1.531-.758-1.773-.844-.234-.094-.414-.133-.586.133s-.68 0.844-.836 1.023c-.156.18-.305.203-.57.07-.258-.133-1.094-.406-2.086-1.289-.773-.688-1.297-1.539-1.445-1.797-.156-.258-.016-.406.117-.539.125-.117.258-.305.383-.453.133-.156.172-.258.258-.43.086-.18.047-.328-.023-.453-.07-.133-.586-1.414-.805-1.938-.219-.516-.438-.445-.586-.453h-.508c-.18 0-.469.07-.719.344-.242.266-.938.914-.938 2.227 0 1.313.961 2.586 1.094 2.766.133.18 1.883 2.883 4.563 4.039.633.273 1.133.438 1.523.563.641.203 1.227.172 1.688.102.516-.078 1.531-.625 1.742-1.234.219-.609.219-1.125.156-1.234-.07-.109-.234-.172-.492-.305z"/>
    </svg>
  </a>

  <!-- Modal de Autenticação Embutido no Site (Entrar / Criar Conta) -->
  <div class="auth-modal-overlay" id="auth-modal-overlay">
    <div class="auth-modal-dialog">
      <button type="button" class="auth-modal-close" id="btn-close-auth-modal" aria-label="Fechar Modal">&times;</button>
      
      <!-- Cabeçalho do Modal -->
      <div class="auth-modal-header">
        <img src="images/logo.png" alt="Vicente Imports" class="auth-modal-logo">
        <h3 class="auth-modal-brand">VICENTE IMPORTS</h3>
        <p class="auth-modal-sub" id="auth-modal-sub">Acesse sua conta ou crie um cadastro rápido</p>
      </div>

      <?php if (!empty($_SESSION['admin_logged'])): ?>
        <div style="background: rgba(200, 162, 77, 0.12); border: 1px solid var(--color-gold); border-radius: 8px; padding: 12px; margin-bottom: 16px; text-align: center;">
          <p style="margin: 0 0 8px 0; font-size: 0.88rem; font-weight: 700; color: #111;">Você está conectado como Administrador.</p>
          <div style="display: flex; gap: 8px; justify-content: center; align-items: center;">
            <a href="admin.php" class="btn-admin-nav" style="padding: 6px 14px; font-size: 0.78rem;">Acessar Painel Admin</a>
            <a href="logout.php" style="padding: 6px 12px; font-size: 0.8rem; color: #ef4444; font-weight: 600;">Sair</a>
          </div>
        </div>
      <?php endif; ?>

      <!-- Abas de Navegação -->
      <div class="auth-tabs">
        <button type="button" class="auth-tab-btn active" id="tab-login-btn">Entrar</button>
        <button type="button" class="auth-tab-btn" id="tab-register-btn">Criar Conta</button>
      </div>

      <!-- Alerta de Feedback dentro do Modal -->
      <div class="auth-modal-alert" id="auth-modal-alert" style="display: none;"></div>

      <!-- Formulário 1: Login Embutido -->
      <form id="form-in-site-login" class="auth-form active" autocomplete="off">
        <div class="form-group-clean">
          <label for="modal-login-user">E-mail ou Usuário</label>
          <input 
            type="text" 
            id="modal-login-user" 
            class="input-clean" 
            placeholder="seuemail@exemplo.com ou admin" 
            required
          >
        </div>

        <div class="form-group-clean">
          <label for="modal-login-pass">Senha</label>
          <div class="input-password-wrapper">
            <input 
              type="password" 
              id="modal-login-pass" 
              class="input-clean" 
              placeholder="••••••••" 
              required
            >
            <button type="button" class="btn-toggle-password" data-target="modal-login-pass" aria-label="Ver senha" title="Ver senha">
              <span class="material-symbols-outlined icon-eye">visibility</span>
              <span class="material-symbols-outlined icon-eye-off" style="display: none;">visibility_off</span>
            </button>
          </div>
        </div>

        <button type="submit" class="btn-auth-submit" id="btn-submit-login">
          <span>Entrar na Loja</span>
        </button>

        <div class="auth-switch-prompt">
          Não tem uma conta? <button type="button" id="switch-to-register">Cadastre-se grátis</button>
        </div>
      </form>

      <!-- Formulário 2: Criar Conta Embutido -->
      <form id="form-in-site-register" class="auth-form" autocomplete="off">
        <div class="form-group-clean">
          <label for="modal-reg-nome">Nome Completo *</label>
          <input 
            type="text" 
            id="modal-reg-nome" 
            class="input-clean" 
            placeholder="Ex: Lucas Ferreira" 
            required
          >
        </div>

        <div class="form-group-clean">
          <label for="modal-reg-email">E-mail *</label>
          <input 
            type="email" 
            id="modal-reg-email" 
            class="input-clean" 
            placeholder="seuemail@exemplo.com" 
            required
          >
        </div>

        <div class="form-group-clean">
          <label for="modal-reg-tel">WhatsApp / Telefone</label>
          <input 
            type="tel" 
            id="modal-reg-tel" 
            class="input-clean" 
            placeholder="(27) 99999-9999"
            maxlength="15"
          >
        </div>

        <div class="form-group-clean">
          <label for="modal-reg-pass">Senha (mínimo 6 dígitos) *</label>
          <div class="input-password-wrapper">
            <input 
              type="password" 
              id="modal-reg-pass" 
              class="input-clean" 
              placeholder="Crie sua senha segura..." 
              required
            >
            <button type="button" class="btn-toggle-password" data-target="modal-reg-pass" aria-label="Ver senha" title="Ver senha">
              <span class="material-symbols-outlined icon-eye">visibility</span>
              <span class="material-symbols-outlined icon-eye-off" style="display: none;">visibility_off</span>
            </button>
          </div>
        </div>

        <button type="submit" class="btn-auth-submit" id="btn-submit-register">
          <span>Criar Minha Conta</span>
        </button>

        <div class="auth-switch-prompt">
          Já possui uma conta? <button type="button" id="switch-to-login">Fazer login</button>
        </div>
      </form>

    </div>
  </div>

  <!-- Drawer / Carrinho Lateral de Compras -->
  <div class="cart-drawer-overlay" id="cart-drawer-overlay"></div>
  <aside class="cart-drawer" id="cart-drawer" aria-label="Carrinho de Compras">
    <div class="cart-drawer-header">
      <div class="cart-drawer-title">
        <span class="material-symbols-outlined" style="font-size: 24px;">shopping_bag</span>
        <h3>Sua Sacola</h3>
        <span class="cart-drawer-badge" id="cart-drawer-count">0</span>
      </div>
      <button type="button" class="cart-drawer-close" id="btn-close-cart" aria-label="Fechar Carrinho">&times;</button>
    </div>

    <!-- Lista de Itens do Carrinho -->
    <div class="cart-drawer-body" id="cart-drawer-body">
      <!-- Renderizado dinamicamente via JS -->
    </div>

    <!-- Rodapé do Carrinho com Subtotal e Botão WhatsApp -->
    <div class="cart-drawer-footer" id="cart-drawer-footer">
      <div class="cart-subtotal-wrap">
        <span class="cart-subtotal-label">Subtotal</span>
        <span class="cart-subtotal-val" id="cart-subtotal-val">R$ 0,00</span>
      </div>
      <p class="cart-shipping-notice">🚚 Envio expresso para Colatina e todo o Brasil</p>

      <!-- Botão Primário de Pagamento Direto: Pix ou Maquininha Mercado Pago -->
      <button type="button" id="btn-open-checkout" class="btn-checkout-pay">
        <span class="material-symbols-outlined" style="font-size: 20px;">payments</span>
        <span>Finalizar Compra / Pagar Agora</span>
      </button>

      <!-- Opção Secundária: WhatsApp -->
      <a href="#" id="btn-checkout-whatsapp" class="btn-checkout-whatsapp" target="_blank">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M12.031 6.172c-3.181 0-5.767 2.586-5.768 5.766-.001 1.298.38 2.27 1.019 3.287l-.711 2.598 2.669-.699c.969.586 1.761.88 2.79.88 3.183 0 5.77-2.587 5.77-5.767 0-3.18-2.587-5.765-5.769-5.765zm3.385 8.169c-.143.402-.832.744-1.155.779-.323.036-.74.174-2.482-.544-1.742-.718-2.859-2.518-2.946-2.633-.087-.116-.708-.941-.708-1.793s.449-1.272.609-1.446c.159-.175.347-.218.463-.218.116 0 .232 0 .333.006.107.006.25.04.387.368.145.348.492 1.201.536 1.288.043.087.072.189.014.305-.058.116-.087.189-.174.29-.087.102-.183.228-.261.306-.087.087-.179.182-.077.356.102.175.452.746.969 1.207.666.594 1.228.778 1.402.865.174.087.276.073.378-.044.102-.116.435-.508.551-.682.116-.174.232-.145.392-.087.159.058 1.014.478 1.188.565.174.087.29.13.333.203.044.072.044.42-.099.822z"/></svg>
        <span>Comprar pelo WhatsApp</span>
      </a>

      <button type="button" class="btn-clear-cart" id="btn-clear-cart">Esvaziar Carrinho</button>
    </div>
  </aside>

  <!-- Drawer / Gaveta Lateral de Favoritos (Lista de Desejos) -->
  <div class="wishlist-drawer-overlay" id="wishlist-drawer-overlay"></div>
  <aside class="wishlist-drawer" id="wishlist-drawer" aria-label="Lista de Desejos">
    <div class="wishlist-drawer-header">
      <div class="wishlist-drawer-title">
        <span class="material-symbols-outlined" style="font-size: 24px; color: #ef4444;">favorite</span>
        <h3>Meus Favoritos</h3>
        <span class="wishlist-drawer-badge" id="wishlist-drawer-count">0</span>
      </div>
      <button type="button" class="wishlist-drawer-close" id="btn-close-wishlist" aria-label="Fechar Favoritos">&times;</button>
    </div>

    <!-- Lista de Itens Favoritos -->
    <div class="wishlist-drawer-body" id="wishlist-drawer-body">
      <!-- Renderizado dinamicamente via JS -->
    </div>

    <div class="wishlist-drawer-footer" id="wishlist-drawer-footer">
      <button type="button" class="btn-clear-wishlist" id="btn-clear-wishlist">Limpar Todos os Favoritos</button>
    </div>
  </aside>

  <!-- Modal de Detalhes do Produto: Galeria Múltipla & Zoom Dinâmico -->
  <div class="site-modal-overlay" id="quickview-modal-overlay">
    <div class="site-modal quickview-modal">
      <button type="button" class="modal-close-custom" id="btn-close-quickview">&times;</button>
      
      <div class="quickview-grid">
        <!-- Coluna da Esquerda: Galeria de Fotos e Zoom -->
        <div class="qv-gallery-col">
          <!-- Contêiner da Foto com Zoom Interativo -->
          <div class="qv-zoom-container" id="qv-zoom-container">
            <img src="" alt="Foto do Produto" id="qv-main-img" class="qv-main-img">
            <div class="qv-zoom-badge">
              <span class="material-symbols-outlined" style="font-size: 15px;">zoom_in</span>
              Passe o mouse para zoom
            </div>
          </div>

          <!-- Miniaturas da Galeria (Até 4 Fotos) -->
          <div class="qv-thumbnails" id="qv-thumbnails">
            <!-- Inseridas dinamicamente via JS -->
          </div>
        </div>

        <!-- Coluna da Direita: Informações, Tamanho e Compra -->
        <div class="qv-info-col">
          <div class="qv-badges-wrap">
            <span class="card-category-tag" id="qv-category">Categoria</span>
            <span class="card-badge" id="qv-badge" style="display: none;">Destaque</span>
          </div>

          <h2 class="qv-title" id="qv-title">Nome do Produto</h2>
          
          <div class="qv-price-wrap">
            <span class="qv-price" id="qv-price">R$ 0,00</span>
            <span class="qv-installments">ou até 3x sem juros no cartão</span>
          </div>

          <p class="qv-description" id="qv-description">Descrição detalhada do produto...</p>

          <!-- Seletor de Tamanho no Modal -->
          <div class="qv-size-section">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
              <span class="qv-section-label">Selecione o Tamanho:</span>
            </div>
            <div class="size-picker" id="qv-size-picker">
              <!-- Pílulas inseridas dinamicamente -->
            </div>
          </div>

          <!-- Ações de Compra e Favoritar -->
          <div class="qv-actions-row">
            <button type="button" class="btn-buy-full" id="qv-btn-buy">
              <span class="material-symbols-outlined" style="font-size: 20px; margin-right: 6px;">shopping_bag</span>
              Adicionar à Sacola
            </button>
            
            <button type="button" class="qv-btn-wishlist" id="qv-btn-wishlist" title="Favoritar este produto">
              <span class="material-symbols-outlined" id="qv-wishlist-icon">favorite_border</span>
            </button>
          </div>

          <!-- Garantias e Vantagens -->
          <div class="qv-perks">
            <div class="qv-perk-item">
              <span class="material-symbols-outlined">verified</span>
              <span>100% Original & Importado</span>
            </div>
            <div class="qv-perk-item">
              <span class="material-symbols-outlined">local_shipping</span>
              <span>Envio Expresso para todo ES & Brasil</span>
            </div>
            <div class="qv-perk-item">
              <span class="material-symbols-outlined">published_with_changes</span>
              <span>Primeira troca grátis em até 7 dias</span>
            </div>
          </div>

        </div>
      </div>
    </div>
  </div>

  <!-- Modal de Checkout Direto (Mercado Pago: Pix & Point) -->
  <div class="site-modal-overlay" id="checkout-modal-overlay">
    <div class="site-modal checkout-modal">
      <button type="button" class="modal-close-custom" id="btn-close-checkout" aria-label="Fechar Checkout">&times;</button>
      
      <!-- Cabeçalho do Checkout -->
      <div class="checkout-header">
        <div class="checkout-brand">
          <img src="images/logo.png" alt="Logo" class="checkout-logo">
          <div>
            <h3 class="checkout-title">Finalizar Pedido</h3>
            <span class="checkout-subtitle">🔒 Ambiente Seguro Mercado Pago</span>
          </div>
        </div>
        <div class="checkout-total-pill">
          <span class="label">Total:</span>
          <strong id="checkout-display-total">R$ 0,00</strong>
        </div>
      </div>

      <!-- Barra de Progresso / Etapas -->
      <div class="checkout-steps">
        <div class="checkout-step-item active" id="step-nav-1">
          <span class="step-num">1</span>
          <span class="step-text">Entrega & Dados</span>
        </div>
        <div class="checkout-step-divider"></div>
        <div class="checkout-step-item" id="step-nav-2">
          <span class="step-num">2</span>
          <span class="step-text">Pagamento</span>
        </div>
        <div class="checkout-step-divider"></div>
        <div class="checkout-step-item" id="step-nav-3">
          <span class="step-num">3</span>
          <span class="step-text">Confirmação</span>
        </div>
      </div>

      <div class="checkout-body">
        
        <!-- ETAPA 1: Dados do Cliente e Entrega -->
        <div class="checkout-step-content active" id="checkout-step-1">
          <h4 class="checkout-section-title">Itens do Seu Pedido</h4>
          <div class="checkout-items-summary" id="checkout-items-summary">
            <!-- Inserido dinamicamente via JS -->
          </div>

          <h4 class="checkout-section-title" style="margin-top: 20px;">Informações para Entrega e Contato</h4>
          <form id="form-checkout-customer" class="checkout-form-grid">
            <div class="form-group-clean" style="grid-column: 1 / -1;">
              <label for="checkout-input-nome">Nome Completo *</label>
              <input type="text" id="checkout-input-nome" class="input-clean" placeholder="Digite seu nome completo..." required>
            </div>

            <div class="form-group-clean">
              <label for="checkout-input-email">E-mail (Receberá o Comprovante) *</label>
              <input type="email" id="checkout-input-email" class="input-clean" placeholder="seuemail@exemplo.com" required>
            </div>

            <div class="form-group-clean">
              <label for="checkout-input-tel">WhatsApp / Telefone *</label>
              <input type="tel" id="checkout-input-tel" class="input-clean" placeholder="(27) 99999-9999" maxlength="15" required>
            </div>

            <!-- Seção de Endereço Detalhado -->
            <div style="grid-column: 1 / -1; margin-top: 8px; padding-top: 14px; border-top: 1px dashed #e5e7eb; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 6px;">
              <span style="font-size: 0.88rem; font-weight: 700; color: #374151; display: flex; align-items: center; gap: 6px;">
                <span class="material-symbols-outlined" style="font-size: 18px; color: var(--color-gold);">location_on</span>
                Endereço para Entrega
              </span>
              <span style="font-size: 0.72rem; color: #6b7280;">Ao digitar o CEP, os dados são preenchidos automaticamente</span>
            </div>

            <div class="form-group-clean">
              <label for="checkout-input-cep">CEP *</label>
              <div style="position: relative; display: flex; align-items: center;">
                <input type="text" id="checkout-input-cep" class="input-clean" placeholder="00000-000" maxlength="9" style="width: 100%; padding-right: 34px;" required>
                <span id="cep-loading-spinner" class="spinner-gold" style="display: none; position: absolute; right: 10px; width: 16px; height: 16px; border-width: 2px;"></span>
              </div>
              <div id="cep-status-msg" style="display: none; font-size: 0.75rem; margin-top: 4px; font-weight: 600;"></div>
            </div>

            <div class="form-group-clean">
              <label for="checkout-input-bairro">Bairro *</label>
              <input type="text" id="checkout-input-bairro" class="input-clean" placeholder="Ex: Centro" required>
            </div>

            <div class="form-group-clean" style="grid-column: 1 / -1;">
              <label for="checkout-input-rua">Rua / Logradouro *</label>
              <input type="text" id="checkout-input-rua" class="input-clean" placeholder="Ex: Av. Getúlio Vargas" required>
            </div>

            <div class="form-group-clean">
              <label for="checkout-input-numero">Número *</label>
              <input type="text" id="checkout-input-numero" class="input-clean" placeholder="Ex: 120 ou S/N" required>
            </div>

            <div class="form-group-clean">
              <label for="checkout-input-complemento">Complemento <span style="font-size: 0.72rem; font-weight: normal; color: #6b7280;">(Opcional)</span></label>
              <input type="text" id="checkout-input-complemento" class="input-clean" placeholder="Apto, Bloco, Casa 2...">
            </div>

            <div class="form-group-clean">
              <label for="checkout-input-cidade">Cidade *</label>
              <input type="text" id="checkout-input-cidade" class="input-clean" placeholder="Ex: Colatina" required>
            </div>

            <div class="form-group-clean">
              <label for="checkout-input-uf">Estado (UF) *</label>
              <input type="text" id="checkout-input-uf" class="input-clean" placeholder="ES" maxlength="2" style="text-transform: uppercase;" required>
            </div>

            <div style="grid-column: 1 / -1; display: flex; align-items: center; gap: 8px; margin-top: 2px; background: #f8fafc; padding: 10px 14px; border-radius: 6px; border: 1px solid #e2e8f0;">
              <input type="checkbox" id="checkout-check-retirada" style="cursor: pointer; width: 16px; height: 16px; accent-color: var(--color-gold);">
              <label for="checkout-check-retirada" style="margin: 0; font-size: 0.82rem; color: #475569; cursor: pointer; user-select: none;">
                Prefiro <strong>retirar na loja física</strong> (Colatina - ES)
              </label>
            </div>

            <!-- Campo oculto para compatibilidade total com os fluxos existentes -->
            <input type="hidden" id="checkout-input-endereco" name="endereco">

            <div style="grid-column: 1 / -1; margin-top: 10px;">
              <button type="submit" class="btn-checkout-next" id="btn-to-step-2">
                <span>Continuar para o Pagamento</span>
                <span class="material-symbols-outlined">arrow_forward</span>
              </button>
            </div>
          </form>
        </div>

        <!-- ETAPA 2: Escolha da Forma de Pagamento -->
        <div class="checkout-step-content" id="checkout-step-2">
          <h4 class="checkout-section-title">Escolha como deseja pagar</h4>

          <!-- Seletor de Métodos -->
          <div class="payment-method-selector">
            <label class="payment-method-card active" id="method-pix-card">
              <input type="radio" name="payment_method" value="pix" checked style="display: none;">
              <div class="payment-method-icon">
                <span class="material-symbols-outlined" style="color: #00b495; font-size: 28px;">qr_code_2</span>
              </div>
              <div class="payment-method-info">
                <strong>Pix Instantâneo (Mercado Pago)</strong>
                <span>Aprovação em segundos com QR Code e Copia e Cola</span>
              </div>
              <span class="badge-discount-mp">Aprovação Imediata</span>
            </label>

            <label class="payment-method-card" id="method-card-card">
              <input type="radio" name="payment_method" value="card" style="display: none;">
              <div class="payment-method-icon">
                <span class="material-symbols-outlined" style="color: #2563eb; font-size: 28px;">credit_card</span>
              </div>
              <div class="payment-method-info">
                <strong>Cartão de Crédito ou Débito Online</strong>
                <span>Aprovação imediata • Até 12x no cartão</span>
              </div>
              <span class="badge-discount-mp" style="background: rgba(37, 99, 235, 0.12); color: #1d4ed8; border-color: rgba(37, 99, 235, 0.25);">Online Automático</span>
            </label>

            <label class="payment-method-card" id="method-point-card">
              <input type="radio" name="payment_method" value="point" style="display: none;">
              <div class="payment-method-icon">
                <span class="material-symbols-outlined" style="color: var(--color-gold); font-size: 28px;">point_of_sale</span>
              </div>
              <div class="payment-method-info">
                <strong>Cartão na Maquininha (Point)</strong>
                <span>Pague por aproximação/chip na maquininha da loja</span>
              </div>
            </label>
          </div>

          <!-- Caixa de Pagamento Pix -->
          <div id="payment-box-pix" class="payment-detail-box active">
            <div id="pix-loading-state" style="display: none; text-align: center; padding: 30px;">
              <div class="spinner-gold"></div>
              <p style="margin-top: 14px; font-weight: 700; color: #111;">Gerando cobrança Pix segura no Mercado Pago...</p>
            </div>

            <div id="pix-ready-state">
              <div style="text-align: center; margin-bottom: 16px;">
                <p style="font-size: 0.9rem; color: #4b5563; margin: 0 0 14px;">
                  Escaneie o QR Code abaixo com o aplicativo do seu banco ou copie o código Pix:
                </p>
                <div class="pix-qrcode-wrapper">
                  <img id="checkout-pix-qrcode" src="" alt="QR Code Pix" style="width: 200px; height: 200px; display: none; margin: 0 auto; border-radius: 8px; border: 1px solid #e5e7eb;">
                  <div id="pix-qr-placeholder" style="width: 200px; height: 200px; margin: 0 auto; background: #f3f4f6; border: 1px dashed #d1d5db; display: flex; flex-direction: column; align-items: center; justify-content: center; border-radius: 8px;">
                    <span class="material-symbols-outlined" style="font-size: 40px; color: #9ca3af;">qr_code_scanner</span>
                    <span style="font-size: 0.8rem; color: #6b7280; margin-top: 6px;">Clique no botão abaixo para gerar</span>
                  </div>
                </div>
              </div>

              <!-- Código Pix Copia e Cola -->
              <div class="pix-copia-cola-box">
                <label style="font-size: 0.78rem; font-weight: 700; text-transform: uppercase; color: #6b7280; margin-bottom: 6px; display: block;">Código Pix Copia e Cola</label>
                <div style="display: flex; gap: 8px;">
                  <input type="text" id="checkout-pix-input" readonly placeholder="Clique em 'Gerar QR Code Pix' para carregar..." style="flex: 1; padding: 10px; font-size: 0.82rem; border: 1px solid #d1d5db; border-radius: 6px; background: #f9fafb; font-family: monospace;">
                  <button type="button" id="btn-copy-pix" class="btn-copy-pix">
                    <span class="material-symbols-outlined" style="font-size: 18px;">content_copy</span>
                    <span>Copiar</span>
                  </button>
                </div>
              </div>

              <!-- Status de Verificação em Tempo Real -->
              <div id="pix-listening-badge" class="pix-listening-badge" style="display: none;">
                <span class="pulse-dot"></span>
                <span>Aguardando pagamento no banco... Verificando aprovação automaticamente</span>
              </div>

              <div style="margin-top: 16px; display: flex; flex-direction: column; gap: 10px;">
                <button type="button" id="btn-generate-pix" class="btn-checkout-next">
                  <span class="material-symbols-outlined">bolt</span>
                  <span>Gerar QR Code Pix</span>
                </button>

                <!-- Botão de teste para simular aprovação instantânea -->
                <button type="button" id="btn-simulate-pix-approval" class="btn-simulate-test" style="display: none;">
                  <span>🧪 Simular Pagamento Aprovado (Ambiente de Teste)</span>
                </button>
              </div>
            </div>
          </div>

          <!-- Caixa de Pagamento Cartão de Crédito ou Débito Online -->
          <div id="payment-box-card" class="payment-detail-box" style="display: none;">
            <!-- Seletor de Tipo de Cartão (Crédito vs Débito) -->
            <div class="card-type-toggle-wrap">
              <button type="button" class="btn-card-type-toggle active" id="btn-card-type-credit" data-type="credit_card">
                <span class="material-symbols-outlined" style="font-size: 18px;">credit_card</span>
                <span>Cartão de Crédito</span>
              </button>
              <button type="button" class="btn-card-type-toggle" id="btn-card-type-debit" data-type="debit_card">
                <span class="material-symbols-outlined" style="font-size: 18px;">account_balance_wallet</span>
                <span>Cartão de Débito</span>
              </button>
            </div>

            <!-- Cartão Visual Interativo (Mirroring) -->
            <div class="credit-card-preview" id="credit-card-preview">
              <div class="card-preview-glare"></div>
              <div class="card-preview-header">
                <div class="card-preview-chip"></div>
                <span class="material-symbols-outlined card-preview-wifi">contactless</span>
                <span class="card-preview-brand-badge" id="preview-brand-badge">CARTÃO</span>
              </div>
              <div class="card-preview-number" id="preview-card-num">&bull;&bull;&bull;&bull; &bull;&bull;&bull;&bull; &bull;&bull;&bull;&bull; &bull;&bull;&bull;&bull;</div>
              <div class="card-preview-footer">
                <div class="card-preview-info">
                  <span class="card-preview-label">TITULAR DO CARTÃO</span>
                  <span class="card-preview-val" id="preview-card-name">NOME COMPLETO</span>
                </div>
                <div class="card-preview-info" style="text-align: right;">
                  <span class="card-preview-label">VALIDADE</span>
                  <span class="card-preview-val" id="preview-card-exp">MM/AA</span>
                </div>
              </div>
            </div>

            <!-- Formulário de Pagamento com Cartão -->
            <form id="form-checkout-card" class="checkout-form-grid" style="margin-top: 18px;">
              <div class="form-group-clean" style="grid-column: 1 / -1;">
                <label for="card-input-number">Número do Cartão *</label>
                <div style="position: relative;">
                  <input type="text" id="card-input-number" class="input-clean" placeholder="0000 0000 0000 0000" maxlength="19" required style="padding-right: 52px; font-family: 'Courier New', Courier, monospace; letter-spacing: 1px; font-weight: 700;">
                  <span id="card-brand-detected" style="position: absolute; right: 12px; top: 50%; transform: translateY(-50%); font-size: 0.72rem; font-weight: 900; color: #2563eb; text-transform: uppercase;"></span>
                </div>
              </div>

              <div class="form-group-clean" style="grid-column: 1 / -1;">
                <label for="card-input-holder">Nome Impresso no Cartão *</label>
                <input type="text" id="card-input-holder" class="input-clean" placeholder="Ex: JOAO DA SILVA" required style="text-transform: uppercase;">
              </div>

              <div class="form-group-clean">
                <label for="card-input-expiry">Validade (MM/AA) *</label>
                <input type="text" id="card-input-expiry" class="input-clean" placeholder="MM/AA" maxlength="5" required style="text-align: center; font-family: monospace; font-weight: 700;">
              </div>

              <div class="form-group-clean">
                <label for="card-input-cvv">Código CVV *</label>
                <input type="password" id="card-input-cvv" class="input-clean" placeholder="123" maxlength="4" required style="text-align: center; font-family: monospace; font-weight: 700;">
              </div>

              <div class="form-group-clean" style="grid-column: 1 / -1;">
                <label for="card-input-cpf">CPF do Titular do Cartão *</label>
                <input type="text" id="card-input-cpf" class="input-clean" placeholder="000.000.000-00" maxlength="14" required>
              </div>

              <div class="form-group-clean" id="group-card-installments" style="grid-column: 1 / -1;">
                <label for="card-input-installments">Parcelamento *</label>
                <select id="card-input-installments" class="input-clean" style="background: #fff; cursor: pointer; font-weight: 600;">
                  <option value="1">1x à vista (sem juros)</option>
                </select>
              </div>

              <div style="grid-column: 1 / -1; margin-top: 6px;">
                <!-- Badge de Segurança -->
                <div style="display: flex; align-items: center; justify-content: center; gap: 8px; font-size: 0.78rem; color: #166534; background: #f0fdf4; border: 1px solid #bbf7d0; padding: 10px; border-radius: 6px; margin-bottom: 14px;">
                  <span class="material-symbols-outlined" style="font-size: 18px; color: #16a34a;">verified_user</span>
                  <span><strong>Pagamento Criptografado:</strong> Verificação e aprovação automática imediata via Mercado Pago.</span>
                </div>

                <div id="card-feedback-msg" style="display: none; padding: 12px; border-radius: 6px; margin-bottom: 14px; font-size: 0.85rem; font-weight: 600;"></div>

                <button type="submit" id="btn-submit-card-pay" class="btn-checkout-next" style="width: 100%;">
                  <span class="material-symbols-outlined">lock</span>
                  <span id="btn-card-pay-label">Pagar com Cartão Agora</span>
                </button>

                <!-- Botão 1-click para preenchimento de cartão de teste -->
                <button type="button" id="btn-fill-test-card" class="btn-simulate-test" style="width: 100%; margin-top: 10px;">
                  <span>🧪 Preencher com Cartão de Teste (Aprovação Automática)</span>
                </button>
              </div>
            </form>
          </div>

          <!-- Caixa de Pagamento Point (Maquininha) -->
          <div id="payment-box-point" class="payment-detail-box" style="display: none;">
            <div style="text-align: center; padding: 24px 16px;">
              <span class="material-symbols-outlined" style="font-size: 52px; color: var(--color-gold); margin-bottom: 12px; display: block;">contactless</span>
              <h4 style="font-size: 1.1rem; font-weight: 800; color: #111; margin: 0 0 8px;">Pagamento com Cartão na Maquininha</h4>
              <p style="font-size: 0.88rem; color: #4b5563; max-width: 440px; margin: 0 auto 20px; line-height: 1.5;">
                Você pode optar por disparar a cobrança para a maquininha física <strong>Mercado Pago Point</strong> ou pagar com cartão no momento da entrega/retirada.
              </p>

              <button type="button" id="btn-trigger-point" class="btn-checkout-next" style="margin: 0 auto; max-width: 360px;">
                <span class="material-symbols-outlined">send_to_mobile</span>
                <span>Enviar Cobrança para a Maquininha</span>
              </button>

              <div id="point-status-badge" style="display: none; margin-top: 16px; padding: 12px; background: #fef3c7; border: 1px solid #fde68a; border-radius: 6px; font-size: 0.85rem; color: #92400e; font-weight: 700;">
                ⏳ Cobrança enviada! Aproxime ou insira o cartão na maquininha...
              </div>

              <!-- Botão de teste para simular aprovação da maquininha -->
              <button type="button" id="btn-simulate-point-approval" class="btn-simulate-test" style="display: none; margin-top: 12px;">
                <span>🧪 Simular Cartão Aprovado na Maquininha</span>
              </button>
            </div>
          </div>

          <div style="margin-top: 18px; display: flex; justify-content: space-between; align-items: center;">
            <button type="button" id="btn-back-to-step-1" class="btn-checkout-back">
              &larr; Voltar aos Dados
            </button>
          </div>
        </div>

        <!-- ETAPA 3: Sucesso e Confirmação -->
        <div class="checkout-step-content" id="checkout-step-3">
          <div class="checkout-success-wrap">
            <div class="success-icon-anim">
              <span class="material-symbols-outlined" style="font-size: 48px;">check</span>
            </div>
            <h3 class="success-title">Pagamento Aprovado com Sucesso!</h3>
            <p class="success-msg">
              Seu pedido <strong id="success-order-id">#PED-000000</strong> foi confirmado no Mercado Pago.
            </p>

            <div class="success-email-notice">
              <span class="material-symbols-outlined" style="font-size: 20px; color: #2563eb;">mail</span>
              <span>Enviamos o e-mail de confirmação para <strong id="success-email-dest">seu e-mail</strong> com a relação completa das peças compradas e instruções de entrega.</span>
            </div>

            <div style="display: flex; gap: 12px; justify-content: center; flex-wrap: wrap; margin-top: 24px;">
              <a href="minha-conta.php" class="btn-hero" style="padding: 12px 24px; font-size: 0.9rem;">
                Ver Meus Pedidos
              </a>
              <button type="button" id="btn-finish-shopping" class="btn-explore-catalog" style="padding: 12px 24px; font-size: 0.9rem;">
                Continuar Comprando
              </button>
            </div>
          </div>
        </div>

      </div>
    </div>
  </div>

  <!-- Scripts da Aplicação e Utilitários de Autenticação -->
  <script src="js/auth-utils.js"></script>
  <script src="js/app.js"></script>
</body>
</html>
