<?php
/**
 * ============================================================================
 * VICENT IMPORTS - MOTOR DE ENVIO DE E-MAILS (GMAIL SMTP / TLS NATIVO)
 * Envio real de e-mails via conexão direta com o servidor do Gmail
 * ============================================================================
 */

class VicentMailer {
    private $host;
    private $port;
    private $user;
    private $pass;
    private $from;
    private $timeout;
    private $lastError = '';

    public function __construct(array $config = []) {
        $this->host = !empty($config['smtp_host']) ? trim($config['smtp_host']) : 'smtp.gmail.com';
        $this->port = !empty($config['smtp_port']) ? intval($config['smtp_port']) : 587;
        $this->user = !empty($config['smtp_user']) ? trim($config['smtp_user']) : '';
        $this->pass = !empty($config['smtp_pass']) ? trim($config['smtp_pass']) : '';
        $this->from = !empty($config['smtp_from']) ? trim($config['smtp_from']) : 'Vicent Imports <contato@vicentimports.com.br>';
        $this->timeout = 15;
    }

    public function getLastError() {
        return $this->lastError;
    }

    public function isConfigured() {
        return !empty($this->user) && !empty($this->pass);
    }

    /**
     * Envia um e-mail HTML formatado
     */
    public function send($to, $subject, $htmlBody, $replyTo = null) {
        $this->lastError = '';

        if (empty($to)) {
            $this->lastError = 'Destinatário não informado.';
            return false;
        }

        // Se não houver credenciais do Gmail configuradas
        if (!$this->isConfigured()) {
            $this->lastError = 'E-mail ou Senha de Aplicativo do Gmail não configurados no Painel Admin (Configurações de Pagamento & SMTP).';
            return false;
        }

        // Limpa espaços da senha caso o usuário tenha copiado com espaços do Google (ex: abcd efgh ijkl mnop)
        $cleanPass = str_replace(' ', '', $this->pass);

        $socket = @stream_socket_client("tcp://{$this->host}:{$this->port}", $errno, $errstr, $this->timeout);
        if (!$socket) {
            $this->lastError = "Falha ao conectar no servidor SMTP ({$this->host}:{$this->port}): [{$errno}] {$errstr}";
            return false;
        }

        stream_set_timeout($socket, $this->timeout);

        $read = function() use ($socket) {
            $data = '';
            while (!feof($socket)) {
                $line = fgets($socket, 512);
                if ($line === false) break;
                $data .= $line;
                if (isset($line[3]) && $line[3] === ' ') break;
            }
            return $data;
        };

        $sendCmd = function($cmd) use ($socket) {
            fputs($socket, $cmd . "\r\n");
        };

        // 1. Saudação do Servidor
        $greeting = $read();
        if (substr($greeting, 0, 3) !== '220') {
            $this->lastError = "Resposta inválida do servidor: " . trim($greeting);
            fclose($socket);
            return false;
        }

        // 2. EHLO Inicial
        $sendCmd("EHLO " . gethostname());
        $ehlo1 = $read();

        // 3. Negociação STARTTLS
        $sendCmd("STARTTLS");
        $tlsRes = $read();
        if (substr($tlsRes, 0, 3) !== '220') {
            $this->lastError = "Servidor rejeitou STARTTLS: " . trim($tlsRes);
            fclose($socket);
            return false;
        }

        // Ativa criptografia TLS no socket
        $cryptoMethod = STREAM_CRYPTO_METHOD_TLS_CLIENT;
        if (defined('STREAM_CRYPTO_METHOD_TLSv1_2_CLIENT')) {
            $cryptoMethod |= STREAM_CRYPTO_METHOD_TLSv1_2_CLIENT;
        }
        if (defined('STREAM_CRYPTO_METHOD_TLSv1_3_CLIENT')) {
            $cryptoMethod |= STREAM_CRYPTO_METHOD_TLSv1_3_CLIENT;
        }

        $cryptoOk = stream_socket_enable_crypto($socket, true, $cryptoMethod);
        if (!$cryptoOk) {
            $this->lastError = "Falha na negociação segura de criptografia TLS com o Gmail.";
            fclose($socket);
            return false;
        }

        // 4. EHLO pós-TLS
        $sendCmd("EHLO " . gethostname());
        $ehlo2 = $read();

        // 5. Autenticação AUTH LOGIN
        $sendCmd("AUTH LOGIN");
        $authRes = $read();
        if (substr($authRes, 0, 3) !== '334') {
            $this->lastError = "Falha ao iniciar autenticação SMTP: " . trim($authRes);
            fclose($socket);
            return false;
        }

        // Envia Usuário Base64
        $sendCmd(base64_encode($this->user));
        $userRes = $read();
        if (substr($userRes, 0, 3) !== '334') {
            $this->lastError = "Usuário do Gmail não aceito: " . trim($userRes);
            fclose($socket);
            return false;
        }

        // Envia Senha Base64
        $sendCmd(base64_encode($cleanPass));
        $passRes = $read();
        if (substr($passRes, 0, 3) !== '235') {
            $this->lastError = "Falha de autenticação no Gmail. Verifique se digitou seu e-mail corretamente e se usou uma 'Senha de Aplicativo' (16 letras) gerada na sua Conta Google. Resposta do Google: " . trim($passRes);
            fclose($socket);
            return false;
        }

        // 6. MAIL FROM
        $fromEmail = $this->user;
        if (preg_match('/<([^>]+)>/', $this->from, $matches)) {
            $fromEmail = $matches[1];
        }
        $sendCmd("MAIL FROM:<{$this->user}>");
        $mailFromRes = $read();
        if (substr($mailFromRes, 0, 3) !== '250') {
            $this->lastError = "Erro no comando MAIL FROM: " . trim($mailFromRes);
            fclose($socket);
            return false;
        }

        // 7. RCPT TO
        $sendCmd("RCPT TO:<{$to}>");
        $rcptRes = $read();
        if (substr($rcptRes, 0, 3) !== '250') {
            $this->lastError = "E-mail de destino ({$to}) rejeitado pelo Gmail: " . trim($rcptRes);
            fclose($socket);
            return false;
        }

        // 8. DATA
        $sendCmd("DATA");
        $dataRes = $read();
        if (substr($dataRes, 0, 3) !== '354') {
            $this->lastError = "Erro ao iniciar envio de dados DATA: " . trim($dataRes);
            fclose($socket);
            return false;
        }

        // 9. Montagem dos Cabeçalhos e Corpo em Base64
        $subjectEncoded = "=?UTF-8?B?" . base64_encode($subject) . "?=";
        $fromName = "Vicent Imports";
        if (preg_match('/^(.*?)\s*<.*?>$/', $this->from, $mName)) {
            $fromName = trim($mName[1]);
        }
        $fromEncoded = "=?UTF-8?B?" . base64_encode($fromName) . "?= <{$this->user}>";

        $headers = [];
        $headers[] = "Date: " . date('r');
        $headers[] = "From: {$fromEncoded}";
        $headers[] = "To: <{$to}>";
        if (!empty($replyTo)) {
            $headers[] = "Reply-To: <{$replyTo}>";
        }
        $headers[] = "Subject: {$subjectEncoded}";
        $headers[] = "MIME-Version: 1.0";
        $headers[] = "Content-Type: text/html; charset=UTF-8";
        $headers[] = "Content-Transfer-Encoding: base64";
        $headers[] = "X-Mailer: VicentImports-Mailer/1.0";

        $bodyEncoded = chunk_split(base64_encode($htmlBody));

        $emailContent = implode("\r\n", $headers) . "\r\n\r\n" . $bodyEncoded . "\r\n.";

        $sendCmd($emailContent);
        $finalRes = $read();

        // 10. QUIT
        $sendCmd("QUIT");
        fclose($socket);

        if (substr($finalRes, 0, 3) === '250') {
            return true;
        } else {
            $this->lastError = "Gmail recusou a entrega final: " . trim($finalRes);
            return false;
        }
    }
}

/**
 * Função global para disparar e-mail HTML
 */
function dispararEmailVicent($destinatario, $assunto, $corpoHtml, $replyTo = null) {
    $caminhoConfig = __DIR__ . DIRECTORY_SEPARATOR . 'config_pagamento.json';
    $config = [];
    if (file_exists($caminhoConfig)) {
        $config = json_decode(file_get_contents($caminhoConfig), true) ?? [];
    }

    $mailer = new VicentMailer($config);
    $enviou = false;
    $erroSmtp = '';

    if ($mailer->isConfigured()) {
        $enviou = $mailer->send($destinatario, $assunto, $corpoHtml, $replyTo);
        if (!$enviou) {
            $erroSmtp = $mailer->getLastError();
        }
    } else {
        $erroSmtp = 'Gmail SMTP ainda não configurado no painel admin.';
        // Fallback nativo do servidor caso configurado
        @mail($destinatario, $assunto, $corpoHtml, "MIME-Version: 1.0\r\nContent-type: text/html; charset=UTF-8\r\nFrom: Vicent Imports <contato@vicentimports.com.br>\r\n");
    }

    // Salva cópia em logs_emails para histórico e auditoria
    $logDir = __DIR__ . DIRECTORY_SEPARATOR . 'logs_emails';
    if (!is_dir($logDir)) @mkdir($logDir, 0777, true);
    $dataLog = date('Y-m-d_H-i-s');
    $safeSubject = preg_replace('/[^a-zA-Z0-9_\-]/', '_', substr($assunto, 0, 30));
    $statusTxt = $enviou ? "ENVIADO_GMAIL" : "SALVO_LOCAL";
    $metaInfo = "<!-- STATUS: {$statusTxt} | DATA: " . date('d/m/Y H:i:s') . " | DESTINO: {$destinatario} | ERRO: {$erroSmtp} -->\n";
    @file_put_contents("{$logDir}/email_{$statusTxt}_{$safeSubject}_{$dataLog}.html", $metaInfo . $corpoHtml);

    return [
        'enviado' => $enviou,
        'erro' => $erroSmtp
    ];
}

/**
 * Gera e dispara e-mail de compra para o cliente e notificação para a loja
 */
function processarEmailsPedido($pedido, $tipo = 'aprovado') {
    $cliente = $pedido['cliente'] ?? [];
    $destinatario = trim($cliente['email'] ?? '');
    $nome = htmlspecialchars($cliente['nome'] ?? 'Cliente');
    $pedidoId = htmlspecialchars($pedido['id'] ?? 'PED-XXXX');
    $valorTotal = number_format($pedido['subtotal'] ?? 0, 2, ',', '.');
    $metodo = ($pedido['metodo_pagamento'] ?? '') === 'pix' ? 'Pix Instantâneo' : 'Cartão';

    $rua = htmlspecialchars($cliente['rua'] ?? '');
    $numero = htmlspecialchars($cliente['numero'] ?? 'S/N');
    $bairro = htmlspecialchars($cliente['bairro'] ?? '');
    $cidade = htmlspecialchars($cliente['cidade'] ?? 'Colatina');
    $estado = htmlspecialchars($cliente['estado'] ?? 'ES');
    $cep = htmlspecialchars($cliente['cep'] ?? '');
    $telefone = htmlspecialchars($cliente['telefone'] ?? '');

    $enderecoCompleto = trim("{$rua}, {$numero}" . ($bairro ? " - {$bairro}" : "") . " - {$cidade}/{$estado}" . ($cep ? " - CEP: {$cep}" : ""));
    if (empty($enderecoCompleto) || $enderecoCompleto === ', S/N - Colatina/ES') {
        $enderecoCompleto = 'Entrega a combinar / Retirada na loja';
    }

    $itensHtml = '';
    foreach (($pedido['itens'] ?? []) as $it) {
        $precoItem = number_format(($it['preco'] ?? 0) * ($it['qty'] ?? 1), 2, ',', '.');
        $tam = htmlspecialchars($it['tamanho'] ?? 'Padrão');
        $nomeItem = htmlspecialchars($it['nome'] ?? 'Produto');
        $qtd = intval($it['qty'] ?? 1);
        $itensHtml .= "<tr>
            <td style='padding: 12px 10px; border-bottom: 1px solid #f1f5f9;'>
                <strong style='color: #1e293b; font-size: 14px;'>{$nomeItem}</strong><br>
                <span style='display: inline-block; margin-top: 4px; background: #f3f4f6; color: #475569; font-size: 11px; font-weight: bold; padding: 2px 8px; border-radius: 4px;'>Tamanho: {$tam}</span>
            </td>
            <td style='padding: 12px 10px; border-bottom: 1px solid #f1f5f9; text-align: center; color: #475569; font-weight: 600;'>{$qtd}x</td>
            <td style='padding: 12px 10px; border-bottom: 1px solid #f1f5f9; text-align: right; font-weight: 800; color: #059669;'>R$ {$precoItem}</td>
        </tr>";
    }

    $isAprovado = ($tipo === 'aprovado' || ($pedido['status'] ?? '') === 'aprovado');
    $badgeCor = $isAprovado ? '#059669' : '#d97706';
    $badgeTexto = $isAprovado ? 'Pagamento Aprovado' : 'Pedido Realizado (Aguardando)';
    $tituloMensagem = $isAprovado ? 'Pagamento Aprovado com Sucesso!' : 'Recebemos o seu Pedido!';
    $textoExplicativo = $isAprovado 
        ? "Excelente notícia! Seu pagamento foi <strong>confirmado</strong> e suas peças exclusivas já estão sendo separadas para envio."
        : "Recebemos sua solicitação de compra. Assim que a transação for concluída, daremos início à separação e envio imediato.";

    $assuntoCliente = $isAprovado 
        ? "🎉 Compra Aprovada! Pedido #{$pedidoId} - Vicent Imports"
        : "🛍️ Pedido Recebido! #{$pedidoId} - Vicent Imports";

    $corpoCliente = "
    <!DOCTYPE html>
    <html lang='pt-BR'>
    <head><meta charset='UTF-8'><meta name='viewport' content='width=device-width, initial-scale=1.0'></head>
    <body style='font-family: -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, Helvetica, Arial, sans-serif; background-color: #0f172a; padding: 30px 15px; margin: 0; color: #1e293b;'>
      <div style='max-width: 600px; margin: 0 auto; background: #ffffff; border-radius: 14px; overflow: hidden; box-shadow: 0 10px 25px rgba(0,0,0,0.3);'>
        
        <!-- Header com Logo e Estilo Vicent Imports -->
        <div style='background: linear-gradient(135deg, #0b0f19 0%, #1e293b 100%); padding: 32px 24px; text-align: center; border-bottom: 3px solid #c59b27;'>
          <h1 style='margin: 0; font-size: 26px; font-weight: 900; letter-spacing: 2px; color: #f59e0b;'>VICENT IMPORTS</h1>
          <p style='margin: 4px 0 0; font-size: 11px; letter-spacing: 1.5px; text-transform: uppercase; color: #94a3b8;'>Moda Masculina & Peças Importadas Selecionadas</p>
          <div style='margin-top: 14px;'>
            <span style='display: inline-block; background: {$badgeCor}; color: #ffffff; font-size: 11px; font-weight: 800; text-transform: uppercase; letter-spacing: 0.5px; padding: 5px 14px; border-radius: 20px;'>
              {$badgeTexto}
            </span>
          </div>
        </div>

        <!-- Conteúdo do Pedido -->
        <div style='padding: 28px 24px;'>
          <h2 style='font-size: 18px; margin-top: 0; color: #0f172a;'>Olá, <strong>{$nome}</strong>!</h2>
          <p style='color: #475569; font-size: 14px; line-height: 1.6; margin-bottom: 20px;'>
            {$textoExplicativo}
          </p>

          <!-- Dados do Pedido -->
          <div style='background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 10px; padding: 16px; margin-bottom: 24px;'>
            <table style='width: 100%; border-collapse: collapse; font-size: 13px;'>
              <tr>
                <td style='color: #64748b; padding-bottom: 6px;'>Código do Pedido:</td>
                <td style='text-align: right; font-weight: 800; color: #0f172a; padding-bottom: 6px;'>#{$pedidoId}</td>
              </tr>
              <tr>
                <td style='color: #64748b; padding-bottom: 6px;'>Forma de Pagamento:</td>
                <td style='text-align: right; font-weight: 700; color: #0f172a; padding-bottom: 6px;'>{$metodo}</td>
              </tr>
              <tr>
                <td style='color: #64748b;'>Endereço de Entrega:</td>
                <td style='text-align: right; font-weight: 600; color: #334155;'>{$enderecoCompleto}</td>
              </tr>
            </table>
          </div>

          <!-- Tabela de Itens Comprados -->
          <h3 style='font-size: 15px; text-transform: uppercase; letter-spacing: 0.5px; color: #0f172a; margin: 0 0 12px; border-bottom: 2px solid #0f172a; padding-bottom: 8px;'>
            Peças Adquiridas
          </h3>
          <table style='width: 100%; border-collapse: collapse; margin-bottom: 16px;'>
            <thead>
              <tr style='background: #f1f5f9; color: #475569; font-size: 12px; text-transform: uppercase;'>
                <th style='padding: 8px 10px; text-align: left;'>Item</th>
                <th style='padding: 8px 10px; text-align: center;'>Qtd</th>
                <th style='padding: 8px 10px; text-align: right;'>Valor</th>
              </tr>
            </thead>
            <tbody>
              {$itensHtml}
            </tbody>
          </table>

          <!-- Total Pago -->
          <div style='text-align: right; padding: 14px 10px; background: #ecfdf5; border-radius: 8px; border: 1px solid #a7f3d0;'>
            <span style='font-size: 14px; color: #065f46; font-weight: 700; margin-right: 8px;'>Total Pago:</span>
            <span style='font-size: 20px; color: #059669; font-weight: 900;'>R$ {$valorTotal}</span>
          </div>

          <!-- Suporte WhatsApp -->
          <div style='margin-top: 24px; padding: 16px; background: #eff6ff; border-left: 4px solid #3b82f6; border-radius: 0 8px 8px 0;'>
            <h4 style='margin: 0 0 4px; font-size: 13px; color: #1e40af;'>📦 Dúvidas sobre o Envio ou Rastreio?</h4>
            <p style='margin: 0; font-size: 12px; color: #3b82f6; line-height: 1.4;'>
              Fale direto com nosso atendimento exclusivo pelo WhatsApp: <strong>(27) 99285-6174</strong>
            </p>
          </div>

        </div>

        <!-- Rodapé do E-mail -->
        <div style='background: #f8fafc; border-top: 1px solid #e2e8f0; padding: 20px; text-align: center;'>
          <p style='margin: 0; font-size: 12px; color: #64748b; font-weight: 600;'>Vicent Imports &bull; Colatina - ES</p>
          <p style='margin: 4px 0 0; font-size: 11px; color: #94a3b8;'>Qualidade premium, estilo e autenticidade para o seu guarda-roupa.</p>
        </div>

      </div>
    </body>
    </html>
    ";

    // 1. Dispara e-mail para o cliente
    $resultadoCliente = false;
    if (!empty($destinatario)) {
        $resultadoCliente = dispararEmailVicent($destinatario, $assuntoCliente, $corpoCliente);
    }

    // 2. Dispara notificação de nova venda para o Gmail da loja/administrador
    $caminhoConfig = __DIR__ . DIRECTORY_SEPARATOR . 'config_pagamento.json';
    $config = file_exists($caminhoConfig) ? (json_decode(file_get_contents($caminhoConfig), true) ?? []) : [];
    $emailLojista = trim($config['smtp_user'] ?? '');

    $resultadoLoja = false;
    if (!empty($emailLojista) && strtolower($emailLojista) !== strtolower($destinatario)) {
        $assuntoLoja = "🛍️ Nova Venda Aprovada! Pedido #{$pedidoId} - R$ {$valorTotal}";
        $corpoLoja = "
        <!DOCTYPE html>
        <html lang='pt-BR'>
        <head><meta charset='UTF-8'></head>
        <body style='font-family: Arial, sans-serif; background: #f8fafc; padding: 20px;'>
          <div style='max-width: 600px; margin: 0 auto; background: #ffffff; border-radius: 8px; padding: 24px; border: 1px solid #e2e8f0;'>
            <h2 style='color: #059669; margin-top: 0;'>🎉 Nova Venda na Vicent Imports!</h2>
            <p>Um cliente acabou de comprar no site. Seguem os dados para separação e envio:</p>
            <hr style='border: none; border-top: 1px solid #eee; margin: 15px 0;'>
            <p><strong>Pedido:</strong> #{$pedidoId}</p>
            <p><strong>Cliente:</strong> {$nome} ({$destinatario})</p>
            <p><strong>Telefone / WhatsApp:</strong> {$telefone}</p>
            <p><strong>Endereço de Entrega:</strong> {$enderecoCompleto}</p>
            <p><strong>Forma de Pagamento:</strong> {$metodo}</p>
            <p><strong>Valor Total:</strong> <span style='font-size: 18px; color: #059669; font-weight: bold;'>R$ {$valorTotal}</span></p>
            <h4 style='margin: 15px 0 8px;'>Peças Compradas:</h4>
            <table style='width: 100%; border-collapse: collapse; font-size: 13px;'>
              {$itensHtml}
            </table>
            <div style='margin-top: 20px;'>
              <a href='http://localhost:8000/admin.php#tabela-pedidos' style='display: inline-block; background: #0f172a; color: #ffffff; text-decoration: none; padding: 10px 20px; border-radius: 6px; font-weight: bold; font-size: 13px;'>Acessar Painel Admin</a>
            </div>
          </div>
        </body>
        </html>
        ";
        $resultadoLoja = dispararEmailVicent($emailLojista, $assuntoLoja, $corpoLoja);
    }

    return [
        'cliente' => $resultadoCliente,
        'loja' => $resultadoLoja
    ];
}
