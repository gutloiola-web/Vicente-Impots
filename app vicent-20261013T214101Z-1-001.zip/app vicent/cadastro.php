<?php
date_default_timezone_set('America/Sao_Paulo');
/**
 * ============================================================================
 * VICENT IMPORTS - CADASTRO DE CLIENTE / CRIAÇÃO DE CONTA
 * ============================================================================
 */

session_start();

// Se o usuário já estiver logado, redireciona para sua conta ou home
if (!empty($_SESSION['user_logged']) && $_SESSION['user_logged'] === true) {
    header('Location: minha-conta.php');
    exit;
}

$caminhoUsuarios = __DIR__ . DIRECTORY_SEPARATOR . 'usuarios.json';
$erro = '';
$sucesso = '';

function obterUsuarios($caminho) {
    if (!file_exists($caminho)) {
        return [];
    }
    $conteudo = file_get_contents($caminho);
    $dados = json_decode($conteudo, true);
    return is_array($dados) ? $dados : [];
}

function salvarUsuarios($caminho, $usuarios) {
    $json = json_encode(array_values($usuarios), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    return file_put_contents($caminho, $json, LOCK_EX);
}

// Processamento do Formulário de Cadastro
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = trim($_POST['nome'] ?? '');
    $email = trim(strtolower($_POST['email'] ?? ''));
    $telefone = trim($_POST['telefone'] ?? '');
    $senha = $_POST['senha'] ?? '';
    $confirmaSenha = $_POST['confirma_senha'] ?? '';

    // Validações básicas
    if (empty($nome) || empty($email) || empty($senha)) {
        $erro = 'Por favor, preencha todos os campos obrigatórios.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $erro = 'Por favor, insira um e-mail válido.';
    } elseif (strlen($senha) < 6) {
        $erro = 'A senha deve ter pelo menos 6 caracteres para sua segurança.';
    } elseif ($senha !== $confirmaSenha) {
        $erro = 'As senhas digitadas não coincidem. Tente novamente.';
    } else {
        $usuarios = obterUsuarios($caminhoUsuarios);

        // Verifica se o e-mail já está cadastrado
        $emailExiste = false;
        foreach ($usuarios as $u) {
            if (isset($u['email']) && strtolower($u['email']) === $email) {
                $emailExiste = true;
                break;
            }
        }

        if ($emailExiste) {
            $erro = 'Este e-mail já está cadastrado. Tente fazer login ou use outro e-mail.';
        } else {
            // Gera o novo ID
            $novoId = 1;
            if (!empty($usuarios)) {
                $ids = array_column($usuarios, 'id');
                $novoId = max($ids) + 1;
            }

            // Cria o registro com senha criptografada de forma segura
            $novoUsuario = [
                'id' => $novoId,
                'nome' => $nome,
                'email' => $email,
                'telefone' => $telefone,
                'senha' => password_hash($senha, PASSWORD_DEFAULT),
                'role' => 'cliente',
                'data_cadastro' => date('Y-m-d H:i:s')
            ];

            $usuarios[] = $novoUsuario;
            
            if (salvarUsuarios($caminhoUsuarios, $usuarios)) {
                // Inicia a sessão automaticamente para o novo cliente
                $_SESSION['user_logged'] = true;
                $_SESSION['user_id'] = $novoId;
                $_SESSION['user_name'] = $nome;
                $_SESSION['user_email'] = $email;
                $_SESSION['user_role'] = 'cliente';

                header('Location: index.php?msg=conta_criada');
                exit;
            } else {
                $erro = 'Houve um erro ao salvar sua conta. Tente novamente.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Criar Conta | Vicente Imports</title>
  
  <link rel="icon" type="image/png" href="images/logo.png">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
  <!-- Google Fonts Icons (https://fonts.google.com/icons) -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
  
  <link rel="stylesheet" href="css/admin.css">
  <style>
    .btn-create-account {
      background-color: #111827;
      color: #ffffff;
      font-weight: 700;
      font-size: 0.95rem;
      padding: 13px;
      border-radius: var(--radius-sm);
      border: none;
      cursor: pointer;
      text-transform: uppercase;
      letter-spacing: 1px;
      transition: var(--transition);
      margin-top: 10px;
    }
    .btn-create-account:hover {
      background-color: var(--admin-gold);
      color: #000000;
      box-shadow: 0 4px 15px rgba(197, 155, 39, 0.35);
    }
  </style>
</head>
<body class="login-page">

  <div class="login-card" style="max-width: 480px;">
    
    <!-- Logo Oficial -->
    <a href="index.php">
      <img src="images/logo.png" alt="Vicente Imports Logo" class="login-logo">
    </a>
    
    <h1 class="login-title">Criar Conta</h1>
    <p class="login-subtitle">Junte-se à Vicente Imports e receba drops exclusivos</p>

    <!-- Feedback de Erro -->
    <?php if (!empty($erro)): ?>
      <div class="admin-alert admin-alert-danger" style="margin-bottom: 20px;">
        <span><?= htmlspecialchars($erro); ?></span>
      </div>
    <?php endif; ?>

    <!-- Formulário de Cadastro -->
    <form action="cadastro.php" method="POST" class="login-form" autocomplete="off">
      
      <div class="form-group">
        <label for="nome" class="form-label">Nome Completo *</label>
        <input 
          type="text" 
          id="nome" 
          name="nome" 
          class="form-control" 
          placeholder="Ex: João da Silva" 
          value="<?= htmlspecialchars($_POST['nome'] ?? ''); ?>" 
          required 
          autofocus
        >
      </div>

      <div class="form-group">
        <label for="email" class="form-label">E-mail *</label>
        <input 
          type="email" 
          id="email" 
          name="email" 
          class="form-control" 
          placeholder="seuemail@exemplo.com" 
          value="<?= htmlspecialchars($_POST['email'] ?? ''); ?>" 
          required
        >
      </div>

      <div class="form-group">
        <label for="telefone" class="form-label">WhatsApp / Telefone</label>
        <input 
          type="tel" 
          id="telefone" 
          name="telefone" 
          class="form-control" 
          placeholder="(27) 99999-9999" 
          maxlength="15"
          value="<?= htmlspecialchars($_POST['telefone'] ?? ''); ?>"
        >
      </div>

      <div class="form-group">
        <label for="senha" class="form-label">Senha (mínimo 6 dígitos) *</label>
        <div class="input-password-wrapper">
          <input 
            type="password" 
            id="senha" 
            name="senha" 
            class="form-control" 
            placeholder="Crie uma senha segura..." 
            required
          >
          <button type="button" class="btn-toggle-password" data-target="senha" aria-label="Ver senha" title="Ver senha">
            <span class="material-symbols-outlined icon-eye">visibility</span>
            <span class="material-symbols-outlined icon-eye-off" style="display: none;">visibility_off</span>
          </button>
        </div>
      </div>

      <div class="form-group">
        <label for="confirma_senha" class="form-label">Confirme sua Senha *</label>
        <div class="input-password-wrapper">
          <input 
            type="password" 
            id="confirma_senha" 
            name="confirma_senha" 
            class="form-control" 
            placeholder="Repita a senha..." 
            required
          >
          <button type="button" class="btn-toggle-password" data-target="confirma_senha" aria-label="Ver senha" title="Ver senha">
            <span class="material-symbols-outlined icon-eye">visibility</span>
            <span class="material-symbols-outlined icon-eye-off" style="display: none;">visibility_off</span>
          </button>
        </div>
      </div>

      <button type="submit" class="btn-create-account">Finalizar Cadastro</button>
    </form>

    <div style="margin-top: 24px; font-size: 0.85rem; color: var(--admin-text-muted);">
      Já possui uma conta? 
      <a href="login.php" style="color: var(--admin-gold); font-weight: 700; text-decoration: underline;">
        Fazer Login
      </a>
    </div>

    <div style="margin-top: 14px;">
      <a href="index.php" style="color: var(--admin-text-light); font-size: 0.8rem; text-decoration: none;">
        &larr; Voltar para a Loja Virtual
      </a>
    </div>

  </div>

  <script src="js/auth-utils.js"></script>
</body>
</html>
