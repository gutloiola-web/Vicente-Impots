<?php
date_default_timezone_set('America/Sao_Paulo');
/**
 * ============================================================================
 * VICENT IMPORTS - PAINEL DO CLIENTE (MINHA CONTA)
 * ============================================================================
 */

session_start();

// Verifica se o cliente ou admin está logado
if (empty($_SESSION['user_logged']) && empty($_SESSION['admin_logged'])) {
    header('Location: login.php?msg=restrito');
    exit;
}

$caminhoUsuarios = __DIR__ . DIRECTORY_SEPARATOR . 'usuarios.json';

function obterUsuarios($caminho) {
    if (!file_exists($caminho)) return [];
    $conteudo = file_get_contents($caminho);
    return $conteudo ? (json_decode($conteudo, true) ?? []) : [];
}

function salvarUsuarios($caminho, $usuarios) {
    $json = json_encode(array_values($usuarios), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    return file_put_contents($caminho, $json, LOCK_EX);
}

$usuarios = obterUsuarios($caminhoUsuarios);
$userId = $_SESSION['user_id'] ?? 0;
$userDados = null;

foreach ($usuarios as $u) {
    if ($u['id'] === $userId || (empty($userId) && isset($_SESSION['admin_user']) && ($u['usuario'] ?? '') === $_SESSION['admin_user'])) {
        $userDados = $u;
        break;
    }
}

$mensagem = '';
$erro = '';

// Atualização de dados cadastrais
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $novoNome = trim($_POST['nome'] ?? '');
    $novoTelefone = trim($_POST['telefone'] ?? '');
    $novaSenha = $_POST['nova_senha'] ?? '';

    if (!empty($novoNome) && $userDados) {
        foreach ($usuarios as &$u) {
            if ($u['id'] === $userDados['id']) {
                $u['nome'] = $novoNome;
                $u['telefone'] = $novoTelefone;
                if (!empty($novaSenha) && strlen($novaSenha) >= 6) {
                    $u['senha'] = password_hash($novaSenha, PASSWORD_DEFAULT);
                }
                $userDados = $u;
                $_SESSION['user_name'] = $novoNome;
                break;
            }
        }
        unset($u);

        if (salvarUsuarios($caminhoUsuarios, $usuarios)) {
            $mensagem = 'Dados atualizados com sucesso!';
        } else {
            $erro = 'Erro ao salvar as alterações.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Minha Conta | Vicente Imports</title>
  
  <link rel="icon" type="image/png" href="images/logo.png">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
  <!-- Google Fonts Icons (https://fonts.google.com/icons) -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
  
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="css/admin.css">
</head>
<body style="background-color: #f7f8fa; color: #12151a;">

  <!-- Header Simples -->
  <header style="background: #ffffff; border-bottom: 1px solid #e5e7eb; padding: 16px 0;">
    <div class="container" style="display: flex; justify-content: space-between; align-items: center;">
      <a href="index.php" style="display: flex; align-items: center; gap: 12px; text-decoration: none;">
        <img src="images/logo.png" alt="Logo" style="width: 44px; height: 44px; border-radius: 50%;">
        <span style="font-weight: 900; font-size: 1.1rem; letter-spacing: 1px; color: #111;">VICENTE IMPORTS</span>
      </a>
      <div style="display: flex; gap: 12px; align-items: center;">
        <?php if (!empty($_SESSION['admin_logged'])): ?>
          <a href="admin.php" style="background: linear-gradient(135deg, #c59b27, #926f14); color: #ffffff; padding: 8px 18px; font-size: 0.8rem; font-weight: 800; border-radius: 4px; text-decoration: none; text-transform: uppercase; letter-spacing: 0.5px; box-shadow: 0 2px 8px rgba(197, 155, 39, 0.3);">Painel do Admin</a>
        <?php endif; ?>
        <a href="index.php" class="btn-hero" style="padding: 8px 18px; font-size: 0.8rem;">Voltar à Loja</a>
        <a href="logout.php" style="background: #ef4444; color: #fff; padding: 8px 16px; border-radius: 4px; font-weight: 700; font-size: 0.8rem; text-decoration: none;">Sair</a>
      </div>
    </div>
  </header>

  <main class="container" style="padding: 40px 16px; max-width: 800px;">
    
    <div style="background: #ffffff; border: 1px solid #e5e7eb; border-radius: 12px; padding: 32px; box-shadow: 0 4px 20px rgba(0,0,0,0.04);">
      
      <div style="display: flex; align-items: center; gap: 18px; margin-bottom: 24px; padding-bottom: 20px; border-bottom: 1px solid #e5e7eb;">
        <div style="width: 64px; height: 64px; background: #111827; color: #fff; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 1.6rem; font-weight: 800;">
          <?= strtoupper(substr($userDados['nome'] ?? 'C', 0, 1)); ?>
        </div>
        <div>
          <h1 style="font-size: 1.4rem; font-weight: 800; color: #111827;">Olá, <?= htmlspecialchars($userDados['nome'] ?? 'Cliente'); ?>!</h1>
          <p style="color: #6b7280; font-size: 0.85rem;">Membro desde: <?= date('d/m/Y', strtotime($userDados['data_cadastro'] ?? 'now')); ?></p>
        </div>
      </div>

      <?php if ($mensagem): ?>
        <div class="admin-alert admin-alert-success" style="margin-bottom: 20px; color: #047857; background: #d1fae5; border-color: #a7f3d0;">
          <?= htmlspecialchars($mensagem); ?>
        </div>
      <?php endif; ?>

      <?php if ($erro): ?>
        <div class="admin-alert admin-alert-danger" style="margin-bottom: 20px;">
          <?= htmlspecialchars($erro); ?>
        </div>
      <?php endif; ?>

      <h2 style="font-size: 1.1rem; font-weight: 700; margin-bottom: 16px; color: #111;">Seus Dados Cadastrais</h2>

      <form action="minha-conta.php" method="POST" style="display: flex; flex-direction: column; gap: 16px;">
        
        <div>
          <label style="display: block; font-size: 0.8rem; font-weight: 700; text-transform: uppercase; color: #4b5563; margin-bottom: 6px;">Nome Completo</label>
          <input type="text" name="nome" value="<?= htmlspecialchars($userDados['nome'] ?? ''); ?>" style="width: 100%; padding: 12px; border: 1px solid #d1d5db; border-radius: 6px; font-size: 0.95rem;" required>
        </div>

        <div>
          <label style="display: block; font-size: 0.8rem; font-weight: 700; text-transform: uppercase; color: #4b5563; margin-bottom: 6px;">E-mail (Não editável)</label>
          <input type="email" value="<?= htmlspecialchars($userDados['email'] ?? ''); ?>" style="width: 100%; padding: 12px; border: 1px solid #e5e7eb; background: #f3f4f6; color: #6b7280; border-radius: 6px; font-size: 0.95rem;" readonly>
        </div>

        <div>
          <label style="display: block; font-size: 0.8rem; font-weight: 700; text-transform: uppercase; color: #4b5563; margin-bottom: 6px;">WhatsApp / Telefone</label>
          <input type="tel" name="telefone" id="telefone" value="<?= htmlspecialchars($userDados['telefone'] ?? ''); ?>" placeholder="(27) 99999-9999" maxlength="15" style="width: 100%; padding: 12px; border: 1px solid #d1d5db; border-radius: 6px; font-size: 0.95rem;">
        </div>

        <div>
          <label style="display: block; font-size: 0.8rem; font-weight: 700; text-transform: uppercase; color: #4b5563; margin-bottom: 6px;">Alterar Senha (deixe em branco se não quiser alterar)</label>
          <div class="input-password-wrapper">
            <input type="password" id="nova_senha" name="nova_senha" placeholder="Digite uma nova senha caso queira mudar..." style="width: 100%; padding: 12px; border: 1px solid #d1d5db; border-radius: 6px; font-size: 0.95rem;">
            <button type="button" class="btn-toggle-password" data-target="nova_senha" aria-label="Ver senha" title="Ver senha">
              <span class="material-symbols-outlined icon-eye">visibility</span>
              <span class="material-symbols-outlined icon-eye-off" style="display: none;">visibility_off</span>
            </button>
          </div>
        </div>

        <button type="submit" style="background: #111827; color: #fff; border: none; padding: 12px 24px; border-radius: 6px; font-weight: 700; font-size: 0.9rem; cursor: pointer; text-transform: uppercase; margin-top: 8px;">
          Salvar Alterações
        </button>

      </form>

      <?php if (!empty($_SESSION['admin_logged'])): ?>
        <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #e5e7eb;">
          <a href="admin.php" style="color: #c59b27; font-weight: 800; text-decoration: none;">&rarr; Ir para o Painel Administrativo de Produtos</a>
        </div>
      <?php endif; ?>

    </div>

    <!-- Seção: Minha Sacola de Compras -->
    <div style="background: #ffffff; border: 1px solid #e5e7eb; border-radius: 12px; padding: 32px; box-shadow: 0 4px 20px rgba(0,0,0,0.04); margin-top: 24px;">
      <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 20px; padding-bottom: 14px; border-bottom: 1px solid #e5e7eb; flex-wrap: wrap; gap: 10px;">
        <div style="display: flex; align-items: center; gap: 10px;">
          <span class="material-symbols-outlined" style="font-size: 24px; color: var(--color-gold);">shopping_bag</span>
          <h2 style="font-size: 1.2rem; font-weight: 800; color: #111827; margin: 0;">Minha Sacola de Compras</h2>
        </div>
        <a href="index.php#produtos" style="font-size: 0.82rem; font-weight: 700; color: var(--color-gold); text-decoration: none;">
          Adicionar Mais Peças &rarr;
        </a>
      </div>

      <div id="conta-carrinho-container">
        <p style="color: #6b7280; font-size: 0.88rem;">Carregando itens da sua sacola...</p>
      </div>
    </div>

    <!-- Seção: Meus Pedidos Realizados -->
    <div style="background: #ffffff; border: 1px solid #e5e7eb; border-radius: 12px; padding: 32px; box-shadow: 0 4px 20px rgba(0,0,0,0.04); margin-top: 24px;">
      <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 20px; padding-bottom: 14px; border-bottom: 1px solid #e5e7eb; flex-wrap: wrap; gap: 10px;">
        <div style="display: flex; align-items: center; gap: 10px;">
          <span class="material-symbols-outlined" style="font-size: 24px; color: #10b981;">receipt_long</span>
          <h2 style="font-size: 1.2rem; font-weight: 800; color: #111827; margin: 0;">Meus Pedidos Realizados</h2>
        </div>
      </div>

      <div id="conta-pedidos-container">
        <p style="color: #6b7280; font-size: 0.88rem;">Carregando histórico de pedidos...</p>
      </div>
    </div>

    <!-- Seção: Meus Favoritos Salvos -->
    <div style="background: #ffffff; border: 1px solid #e5e7eb; border-radius: 12px; padding: 32px; box-shadow: 0 4px 20px rgba(0,0,0,0.04); margin-top: 24px;">
      <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 20px; padding-bottom: 14px; border-bottom: 1px solid #e5e7eb; flex-wrap: wrap; gap: 10px;">
        <div style="display: flex; align-items: center; gap: 10px;">
          <span class="material-symbols-outlined" style="font-size: 24px; color: #ef4444;">favorite</span>
          <h2 style="font-size: 1.2rem; font-weight: 800; color: #111827; margin: 0;">Peças Favoritadas</h2>
        </div>
        <a href="index.php#produtos" style="font-size: 0.82rem; font-weight: 700; color: var(--color-gold); text-decoration: none;">
          Ver Catálogo Completo &rarr;
        </a>
      </div>

      <div id="conta-wishlist-container" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(180px, 1fr)); gap: 16px;">
        <p style="color: #6b7280; font-size: 0.88rem; grid-column: 1 / -1;">Carregando seus produtos favoritos...</p>
      </div>
    </div>

  </main>

  <script src="js/auth-utils.js"></script>
  <script>
    document.addEventListener('DOMContentLoaded', () => {
      const userId = '<?= $userId; ?>';

      // ==========================================
      // 1. CARREGAMENTO E RENDERIZAÇÃO DA SACOLA
      // ==========================================
      const cartContainer = document.getElementById('conta-carrinho-container');
      if (cartContainer) {
        const cartUserKey = 'vicente_imports_cart_user_' + userId;
        let userCart = [];
        try {
          const salvoCart = localStorage.getItem(cartUserKey);
          userCart = salvoCart ? JSON.parse(salvoCart) : [];
        } catch (e) {
          userCart = [];
        }

        // Se localStorage estiver vazio para esta conta, restaura do backend
        const serverCart = <?= json_encode($userDados['carrinho'] ?? []); ?>;
        if (userCart.length === 0 && Array.isArray(serverCart) && serverCart.length > 0) {
          userCart = serverCart;
          try {
            localStorage.setItem(cartUserKey, JSON.stringify(userCart));
          } catch (e) {}
        }

        function renderizarCarrinhoConta() {
          if (!userCart || userCart.length === 0) {
            cartContainer.innerHTML = `
              <div style="text-align: center; padding: 30px; color: #6b7280;">
                <span class="material-symbols-outlined" style="font-size: 44px; color: #d1d5db; margin-bottom: 10px; display: block;">shopping_bag</span>
                <p style="font-weight: 700; color: #111; margin-bottom: 6px;">Sua sacola nesta conta está vazia</p>
                <p style="font-size: 0.85rem; margin-bottom: 16px;">Explore nossa coleção e adicione as peças que você deseja comprar.</p>
                <a href="index.php#produtos" class="btn-hero" style="display: inline-block; padding: 8px 18px; font-size: 0.82rem;">Explorar Loja</a>
              </div>
            `;
            return;
          }

          const subtotal = userCart.reduce((acc, it) => acc + (Number(it.preco) * (it.qty || 1)), 0);
          const subtotalBRL = subtotal.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

          // Monta mensagem WhatsApp
          let msg = `👑 *PEDIDO - VICENTE IMPORTS*\n`;
          msg += `--------------------------------------------------\n`;
          userCart.forEach((it, idx) => {
            const precoItem = (Number(it.preco) * it.qty).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
            msg += `${idx + 1}. *${it.nome}*\n   Tamanho: ${it.tamanho} | Qtd: ${it.qty}\n   Subtotal: ${precoItem}\n\n`;
          });
          msg += `--------------------------------------------------\n`;
          msg += `*VALOR TOTAL:* ${subtotalBRL}\n\n`;
          msg += `Gostaria de combinar a entrega e finalizar meu pedido!`;
          const whatsappHref = `https://wa.me/5527992856174?text=${encodeURIComponent(msg)}`;

          let html = `
            <div style="display: flex; flex-direction: column; gap: 12px; margin-bottom: 20px;">
          `;

          userCart.forEach((item, index) => {
            const unitVal = Number(item.preco).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
            const totalItem = (Number(item.preco) * (item.qty || 1)).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
            html += `
              <div style="display: flex; align-items: center; justify-content: space-between; padding: 12px; background: #f9fafb; border: 1px solid #e5e7eb; border-radius: 8px; flex-wrap: wrap; gap: 12px;">
                <div style="display: flex; align-items: center; gap: 12px;">
                  <img src="${item.imagem || 'images/logo.png'}" alt="${item.nome}" style="width: 50px; height: 50px; object-fit: cover; border-radius: 6px; border: 1px solid #e5e7eb;" onerror="this.src='images/logo.png';">
                  <div>
                    <h4 style="font-size: 0.9rem; font-weight: 700; color: #111827; margin: 0 0 4px;">${item.nome}</h4>
                    <span style="font-size: 0.8rem; color: #6b7280;">Tamanho: <strong>${item.tamanho}</strong> &bull; Qtd: <strong>${item.qty}</strong> (${unitVal} un.)</span>
                  </div>
                </div>
                <div style="display: flex; align-items: center; gap: 14px;">
                  <span style="font-size: 0.95rem; font-weight: 800; color: #111827;">${totalItem}</span>
                  <button type="button" class="btn-remove-cart-item" data-index="${index}" title="Remover da sacola" style="background: none; border: 1px solid #fee2e2; color: #ef4444; border-radius: 4px; padding: 6px 10px; cursor: pointer; display: flex; align-items: center; gap: 4px; font-size: 0.78rem; font-weight: 700;">
                    <span class="material-symbols-outlined" style="font-size: 16px;">delete</span>
                    Remover
                  </button>
                </div>
              </div>
            `;
          });

          html += `
            </div>
            <div style="display: flex; align-items: center; justify-content: space-between; padding: 16px; background: #111827; border-radius: 8px; color: #fff; flex-wrap: wrap; gap: 12px;">
              <div>
                <span style="font-size: 0.8rem; color: #9ca3af; text-transform: uppercase; letter-spacing: 0.5px;">Subtotal da Sacola:</span>
                <div style="font-size: 1.3rem; font-weight: 900; color: var(--color-gold);">${subtotalBRL}</div>
              </div>
              <div style="display: flex; gap: 10px; flex-wrap: wrap;">
                <a href="index.php?checkout=abrir" style="background: linear-gradient(135deg, #c59b27, #e0b84c); color: #000; padding: 10px 20px; border-radius: 6px; font-size: 0.85rem; font-weight: 900; text-decoration: none; display: flex; align-items: center; gap: 6px; box-shadow: 0 4px 14px rgba(197,155,39,0.4);">
                  <span class="material-symbols-outlined" style="font-size: 18px;">payments</span>
                  Pagar Agora (Pix / Cartão)
                </a>
                <a href="${whatsappHref}" target="_blank" rel="noopener" style="background: #25d366; color: #fff; padding: 10px 20px; border-radius: 6px; font-size: 0.85rem; font-weight: 800; text-decoration: none; display: flex; align-items: center; gap: 6px; box-shadow: 0 4px 12px rgba(37,211,102,0.3);">
                  <span class="material-symbols-outlined" style="font-size: 18px;">chat</span>
                  Comprar pelo WhatsApp
                </a>
                <a href="index.php" style="background: rgba(255,255,255,0.1); color: #fff; padding: 10px 18px; border-radius: 6px; font-size: 0.85rem; font-weight: 700; text-decoration: none;">Ver Catálogo</a>
              </div>
            </div>
          `;

          cartContainer.innerHTML = html;

          cartContainer.querySelectorAll('.btn-remove-cart-item').forEach(btn => {
            btn.addEventListener('click', () => {
              const idx = parseInt(btn.getAttribute('data-index'), 10);
              userCart.splice(idx, 1);
              try {
                localStorage.setItem(cartUserKey, JSON.stringify(userCart));
              } catch (e) {}
              fetch('index.php?api=carrinho', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ carrinho: userCart })
              }).catch(() => {});
              renderizarCarrinhoConta();
            });
          });
        }

        renderizarCarrinhoConta();
      }

      // ==========================================
      // 2. CARREGAMENTO E RENDERIZAÇÃO DE FAVORITOS
      // ==========================================
      const favContainer = document.getElementById('conta-wishlist-container');
      if (favContainer) {
        const userWishlistKey = 'vicente_imports_wishlist_user_' + userId;
        let wishlist = [];
        try {
          const salvo = localStorage.getItem(userWishlistKey);
          wishlist = salvo ? JSON.parse(salvo) : [];
        } catch (e) {
          wishlist = [];
        }

        // Se localStorage estiver vazio para esta conta, carrega os favoritos salvos no backend
        const serverFavs = <?= json_encode($userDados['favoritos'] ?? []); ?>;
        if (wishlist.length === 0 && Array.isArray(serverFavs) && serverFavs.length > 0) {
          wishlist = serverFavs;
          try {
            localStorage.setItem(userWishlistKey, JSON.stringify(wishlist));
          } catch (e) {}
        }

        function renderizarFavoritosConta() {
          if (wishlist.length === 0) {
            favContainer.innerHTML = `
              <div style="grid-column: 1 / -1; text-align: center; padding: 30px; color: #6b7280;">
                <span class="material-symbols-outlined" style="font-size: 44px; color: #d1d5db; margin-bottom: 10px; display: block;">favorite_border</span>
                <p style="font-weight: 700; color: #111; margin-bottom: 6px;">Nenhuma peça favoritada nesta conta ainda</p>
                <p style="font-size: 0.85rem; margin-bottom: 16px;">Explore nossa loja e clique no coração das peças que você mais curtir.</p>
                <a href="index.php#produtos" class="btn-hero" style="display: inline-block; padding: 8px 18px; font-size: 0.82rem;">Explorar Coleção</a>
              </div>
            `;
            return;
          }

          favContainer.innerHTML = wishlist.map(item => {
            const precoNum = parseFloat(item.preco) || 0;
            const precoAntigoNum = item.preco_antigo ? parseFloat(item.preco_antigo) : 0;
            const temDesconto = precoAntigoNum > precoNum;
            const pctDesconto = temDesconto ? Math.round(((precoAntigoNum - precoNum) / precoAntigoNum) * 100) : 0;

            const precoBRL = precoNum.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
            const precoAntigoBRL = precoAntigoNum.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

            return `
              <div style="background: #f9fafb; border: 1px solid #e5e7eb; border-radius: 8px; overflow: hidden; display: flex; flex-direction: column; position: relative;">
                <div style="width: 100%; height: 160px; overflow: hidden; background: #fff; position: relative;">
                  <img src="${item.imagem}" alt="${item.nome}" style="width: 100%; height: 100%; object-fit: cover;">
                  ${temDesconto ? `<span style="position: absolute; top: 8px; left: 8px; background: #ef4444; color: #fff; font-size: 0.65rem; font-weight: 800; padding: 2px 6px; border-radius: 4px;">-${pctDesconto}% OFF</span>` : ''}
                </div>
                <div style="padding: 12px; display: flex; flex-direction: column; flex: 1; justify-content: space-between;">
                  <div>
                    <span style="font-size: 0.65rem; font-weight: 700; text-transform: uppercase; color: #9ca3af; letter-spacing: 0.5px;">${item.categoria || 'Moda'}</span>
                    <h4 style="font-size: 0.85rem; font-weight: 700; color: #111827; margin: 4px 0 8px; line-height: 1.3;">${item.nome}</h4>
                  </div>
                  <div>
                    <div style="margin-bottom: 10px;">
                      ${temDesconto ? `<div style="font-size: 0.72rem; color: #9ca3af; text-decoration: line-through;">De ${precoAntigoBRL}</div>` : ''}
                      <div style="font-size: 1rem; font-weight: 800; color: #059669;">${temDesconto ? `Por ${precoBRL}` : precoBRL}</div>
                    </div>
                    <div style="display: flex; gap: 6px;">
                      <a href="index.php#produtos" style="flex: 1; text-align: center; background: #111827; color: #fff; padding: 8px; font-size: 0.75rem; font-weight: 700; border-radius: 4px; text-decoration: none; text-transform: uppercase;">
                        Ver na Loja
                      </a>
                      <button type="button" class="btn-remover-fav" data-id="${item.id}" title="Remover dos favoritos" style="background: none; border: 1px solid #e5e7eb; color: #ef4444; border-radius: 4px; padding: 0 8px; cursor: pointer; display: flex; align-items: center; justify-content: center;">
                        <span class="material-symbols-outlined" style="font-size: 18px;">delete</span>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            `;
          }).join('');

          favContainer.querySelectorAll('.btn-remover-fav').forEach(btn => {
            btn.addEventListener('click', () => {
              const id = btn.getAttribute('data-id');
              wishlist = wishlist.filter(w => String(w.id) !== String(id));
              try {
                localStorage.setItem(userWishlistKey, JSON.stringify(wishlist));
              } catch (e) {}
              fetch('index.php?api=favoritos', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ favoritos: wishlist })
              }).catch(() => {});
              renderizarFavoritosConta();
            });
          });
        }

        renderizarFavoritosConta();
      }

      // ==========================================
      // 3. CARREGAMENTO DO HISTÓRICO DE PEDIDOS
      // ==========================================
      const pedidosContainer = document.getElementById('conta-pedidos-container');
      if (pedidosContainer) {
        fetch('index.php?api=meus_pedidos')
          .then(res => res.json())
          .then(data => {
            if (data.success && Array.isArray(data.pedidos) && data.pedidos.length > 0) {
              pedidosContainer.innerHTML = `
                <div style="display: flex; flex-direction: column; gap: 14px;">
                  ${data.pedidos.map(p => {
                    const statusAprovado = p.status === 'aprovado';
                    const badgeBg = statusAprovado ? '#d1fae5' : '#fef3c7';
                    const badgeColor = statusAprovado ? '#065f46' : '#92400e';
                    const statusText = statusAprovado ? 'Pagamento Aprovado' : 'Aguardando Pagamento';
                    const valorTotal = Number(p.subtotal).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

                    const metodoTexto = p.metodo_pagamento === 'cartao_credito'
                      ? `💳 Cartão de Crédito (${p.detalhes_cartao?.bandeira || 'Online'} final ${p.detalhes_cartao?.ultimos_digitos || ''} • ${p.detalhes_cartao?.parcelas || 1}x)`
                      : (p.metodo_pagamento === 'cartao_debito'
                        ? `💳 Cartão de Débito (${p.detalhes_cartao?.bandeira || 'Online'} final ${p.detalhes_cartao?.ultimos_digitos || ''})`
                        : (p.metodo_pagamento === 'point' ? '📟 Cartão na Maquininha' : '📱 Pix Instantâneo'));

                    const dataFormatadaPed = p.criado_em ? (function(raw) {
                      try {
                        const d = new Date(raw.replace(' ', 'T'));
                        if (isNaN(d.getTime())) return raw;
                        return d.toLocaleDateString('pt-BR') + ' às ' + d.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
                      } catch(e) { return raw; }
                    })(p.criado_em) : 'Data indisponível';

                    return `
                      <div style="background: #f9fafb; border: 1px solid #e5e7eb; border-radius: 8px; padding: 16px;">
                        <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px; margin-bottom: 12px; padding-bottom: 10px; border-bottom: 1px solid #eee;">
                          <div>
                            <strong style="font-size: 1rem; color: #111;">Pedido #${p.id}</strong>
                            <div style="font-size: 0.8rem; color: #6b7280; display: flex; align-items: center; gap: 8px; margin-top: 3px;">
                              <span>Realizado em: ${dataFormatadaPed}</span>
                              <span>&bull;</span>
                              <span style="font-weight: 600; color: #374151;">${metodoTexto}</span>
                            </div>
                          </div>
                          <div style="display: flex; align-items: center; gap: 12px;">
                            <span style="background: ${badgeBg}; color: ${badgeColor}; font-size: 0.75rem; font-weight: 800; padding: 4px 10px; border-radius: 999px; text-transform: uppercase;">${statusText}</span>
                            <strong style="font-size: 1.05rem; color: #111;">${valorTotal}</strong>
                          </div>
                        </div>

                        <div style="font-size: 0.82rem; color: #4b5563;">
                          <strong>Itens comprados:</strong>
                          <ul style="margin: 6px 0 0; padding-left: 20px; line-height: 1.6;">
                            ${(p.itens || []).map(it => `<li>${it.nome} (Tam: ${it.tamanho}) &bull; ${it.qty}x</li>`).join('')}
                          </ul>
                        </div>
                      </div>
                    `;
                  }).join('')}
                </div>
              `;
            } else {
              pedidosContainer.innerHTML = `
                <div style="text-align: center; padding: 30px; color: #6b7280;">
                  <span class="material-symbols-outlined" style="font-size: 44px; color: #d1d5db; margin-bottom: 10px; display: block;">receipt_long</span>
                  <p style="font-weight: 700; color: #111; margin-bottom: 6px;">Nenhum pedido finalizado ainda</p>
                  <p style="font-size: 0.85rem; margin-bottom: 16px;">Escolha suas peças exclusivas e pague com Pix ou Cartão!</p>
                  <a href="index.php#produtos" class="btn-hero" style="display: inline-block; padding: 8px 18px; font-size: 0.82rem;">Explorar Coleção</a>
                </div>
              `;
            }
          })
          .catch(() => {
            pedidosContainer.innerHTML = '<p style="color: #ef4444; font-size: 0.85rem;">Erro ao carregar histórico de pedidos.</p>';
          });
      }
    });
  </script>
</body>
</html>
