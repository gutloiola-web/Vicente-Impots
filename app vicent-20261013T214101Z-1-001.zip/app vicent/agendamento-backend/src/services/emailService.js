import { transporter } from '../config/mailer.js';
import dotenv from 'dotenv';

dotenv.config();

/**
 * Serviço de envio de e-mails transacionais com layout responsivo
 */
export const emailService = {
  /**
   * Envia o e-mail de confirmação do agendamento após o pagamento aprovado
   */
  async enviarConfirmacaoAgendamento({ cliente, agendamento }) {
    const from = process.env.SMTP_FROM || 'Agendamentos <nao-responda@loja.com>';
    const valorFormatado = Number(agendamento.valor).toLocaleString('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    });

    const dataFormatada = agendamento.data.includes('-')
      ? agendamento.data.split('-').reverse().join('/')
      : agendamento.data;

    const htmlContent = `
      <!DOCTYPE html>
      <html lang="pt-BR">
      <head>
        <meta charset="UTF-8">
        <style>
          body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; background-color: #f4f5f7; margin: 0; padding: 20px; color: #1f2937; }
          .card { max-width: 560px; margin: 0 auto; background: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 18px rgba(0,0,0,0.06); border: 1px solid #e5e7eb; }
          .header { background: linear-gradient(135deg, #111827 0%, #1f2937 100%); color: #ffffff; padding: 28px 24px; text-align: center; }
          .header h1 { margin: 0; font-size: 22px; font-weight: 800; letter-spacing: 0.5px; }
          .badge-approved { display: inline-block; background: #10b981; color: #ffffff; font-size: 12px; font-weight: 700; text-transform: uppercase; padding: 4px 12px; border-radius: 999px; margin-top: 10px; }
          .body { padding: 24px; }
          .greeting { font-size: 16px; margin-bottom: 16px; line-height: 1.5; }
          .details-box { background: #f9fafb; border: 1px solid #e5e7eb; border-radius: 8px; padding: 18px; margin: 20px 0; }
          .detail-row { display: flex; justify-content: space-between; padding: 8px 0; border-bottom: 1px solid #f0f1f3; font-size: 14px; }
          .detail-row:last-child { border-bottom: none; }
          .label { color: #6b7280; font-weight: 600; }
          .value { color: #111827; font-weight: 700; text-align: right; }
          .price-highlight { color: #059669; font-size: 16px; }
          .info-note { background: #eff6ff; border-left: 4px solid #3b82f6; padding: 12px 16px; font-size: 13px; color: #1e40af; border-radius: 0 6px 6px 0; margin-top: 18px; line-height: 1.5; }
          .footer { text-align: center; padding: 18px 24px; font-size: 12px; color: #9ca3af; background: #fafafa; border-top: 1px solid #f3f4f6; }
        </style>
      </head>
      <body>
        <div class="card">
          <div class="header">
            <h1>Agendamento Confirmado!</h1>
            <span class="badge-approved">Pagamento Aprovado</span>
          </div>

          <div class="body">
            <p class="greeting">Olá, <strong>${cliente.nome}</strong>! Seu horário foi reservado com sucesso e seu pagamento foi aprovado pelo Mercado Pago.</p>
            
            <div class="details-box">
              <div class="detail-row">
                <span class="label">Código do Agendamento:</span>
                <span class="value">#${agendamento.id}</span>
              </div>
              <div class="detail-row">
                <span class="label">Serviço:</span>
                <span class="value">${agendamento.servico}</span>
              </div>
              <div class="detail-row">
                <span class="label">Data:</span>
                <span class="value">${dataFormatada}</span>
              </div>
              <div class="detail-row">
                <span class="label">Horário:</span>
                <span class="value">${agendamento.horario}</span>
              </div>
              <div class="detail-row">
                <span class="label">Forma de Pagamento:</span>
                <span class="value">${agendamento.metodo_pagamento === 'pix' ? 'Pix Instantâneo' : 'Cartão na Maquininha (Point)'}</span>
              </div>
              <div class="detail-row">
                <span class="label">Valor Pago:</span>
                <span class="value price-highlight">${valorFormatado}</span>
              </div>
            </div>

            <div class="info-note">
              📍 <strong>Lembrete:</strong> Por favor, chegue com 5 a 10 minutos de antecedência. Caso necessite remarcar ou cancelar, entre em contato conosco com pelo menos 2 horas de antecedência.
            </div>
          </div>

          <div class="footer">
            Este é um e-mail automático gerado pelo sistema de agendamento.<br>
            Agradecemos a sua preferência!
          </div>
        </div>
      </body>
      </html>
    `;

    // Se SMTP não estiver configurado para envio real, loga para depuração
    if (!process.env.SMTP_USER || process.env.SMTP_USER === 'seu-email@gmail.com') {
      console.log('----------------------------------------------------');
      console.log('📧 [SIMULAÇÃO DE E-MAIL - SMTP PENDENTE]');
      console.log(`Para: ${cliente.email} (${cliente.nome})`);
      console.log(`Assunto: Confirmação de Agendamento #${agendamento.id} - ${agendamento.servico}`);
      console.log(`Serviço: ${agendamento.servico} | Data: ${dataFormatada} às ${agendamento.horario}`);
      console.log(`Valor: ${valorFormatado} | Status: APROVADO`);
      console.log('----------------------------------------------------');
      return { simulado: true, enviadoPara: cliente.email };
    }

    try {
      const info = await transporter.sendMail({
        from: from,
        to: cliente.email,
        subject: `Confirmação de Agendamento #${agendamento.id} - ${agendamento.servico}`,
        html: htmlContent
      });

      console.log(`✅ [E-mail Enviado] Confirmação entregue com sucesso para ${cliente.email} (MessageId: ${info.messageId})`);
      return { sucesso: true, messageId: info.messageId };
    } catch (error) {
      console.error(`❌ [Erro E-mail] Falha ao enviar confirmação para ${cliente.email}:`, error.message);
      throw error;
    }
  }
};
