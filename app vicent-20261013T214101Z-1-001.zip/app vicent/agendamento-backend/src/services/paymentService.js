import { payment } from '../config/mercadopago.js';
import dotenv from 'dotenv';

dotenv.config();

export const paymentService = {
  /**
   * 1. Gera cobrança Pix via API do Mercado Pago
   * Retorna os dados do Pix: Copia e Cola (qr_code) e imagem em Base64 (qr_code_base64)
   */
  async criarPagamentoPix({ agendamentoId, valor, descricao, cliente }) {
    const webhookUrl = process.env.WEBHOOK_BASE_URL
      ? `${process.env.WEBHOOK_BASE_URL}/api/webhook/mercadopago`
      : undefined;

    const payload = {
      transaction_amount: Number(valor),
      description: descricao || `Agendamento #${agendamentoId}`,
      payment_method_id: 'pix',
      payer: {
        email: cliente.email,
        first_name: cliente.nome?.split(' ')[0] || 'Cliente',
        last_name: cliente.nome?.split(' ').slice(1).join(' ') || ''
      },
      external_reference: String(agendamentoId),
      notification_url: webhookUrl
    };

    try {
      const resposta = await payment.create({ body: payload });
      const txData = resposta.point_of_interaction?.transaction_data;

      return {
        sucesso: true,
        payment_id: resposta.id,
        status: resposta.status,
        status_detail: resposta.status_detail,
        pix: {
          qr_code: txData?.qr_code || '', // Código Pix Copia e Cola
          qr_code_base64: txData?.qr_code_base64 || '', // Imagem QR Code Base64
          ticket_url: txData?.ticket_url || ''
        },
        valor: resposta.transaction_amount,
        criado_em: resposta.date_created
      };
    } catch (error) {
      console.error('❌ [Erro Mercado Pago Pix]:', error);
      throw new Error(error.message || 'Falha ao gerar cobrança Pix no Mercado Pago');
    }
  },

  /**
   * 2. Dispara a cobrança para a Maquininha Point Física da Loja
   * Utiliza a API oficial de Point Integration do Mercado Pago (/payment-intents)
   */
  async criarCobrancaPoint({ agendamentoId, valor, deviceId }) {
    const targetDevice = deviceId || process.env.MERCADO_PAGO_POINT_DEVICE_ID;
    const accessToken = process.env.MERCADO_PAGO_ACCESS_TOKEN;

    if (!targetDevice) {
      throw new Error('ID da maquininha Point não configurado (MERCADO_PAGO_POINT_DEVICE_ID).');
    }

    // A API Point espera o valor em centavos (ex: R$ 50,00 -> 5000)
    const amountInCents = Math.round(Number(valor) * 100);

    const url = `https://api.mercadopago.com/point/integration-api/devices/${targetDevice}/payment-intents`;

    const body = {
      amount: amountInCents,
      additional_info: {
        external_reference: String(agendamentoId),
        print_on_terminal: true
      }
    };

    try {
      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(body)
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || data.error || 'Erro ao enviar cobrança para a maquininha');
      }

      return {
        sucesso: true,
        intent_id: data.id,
        device_id: data.device_id,
        status: data.state, // 'OPEN' | 'ON_TERMINAL' | 'PROCESSING'
        amount: Number(valor),
        additional_info: data.additional_info
      };
    } catch (error) {
      console.error('❌ [Erro Mercado Pago Point]:', error);
      throw new Error(error.message || 'Falha ao disparar cobrança para a maquininha física');
    }
  },

  /**
   * 3. Consulta os detalhes de um pagamento pelo ID no Mercado Pago
   */
  async consultarPagamento(paymentId) {
    try {
      const resultado = await payment.get({ id: String(paymentId) });
      return resultado;
    } catch (error) {
      console.error(`❌ [Erro ao consultar pagamento ${paymentId}]:`, error);
      throw error;
    }
  },

  /**
   * 4. Lista as maquininhas Point vinculadas à conta do Mercado Pago
   */
  async listarDispositivosPoint() {
    const accessToken = process.env.MERCADO_PAGO_ACCESS_TOKEN;
    const url = 'https://api.mercadopago.com/point/integration-api/devices';

    try {
      const response = await fetch(url, {
        headers: {
          'Authorization': `Bearer ${accessToken}`
        }
      });
      return await response.json();
    } catch (error) {
      console.error('Erro ao consultar maquininhas:', error);
      throw error;
    }
  }
};
