import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const dbFilePath = path.join(__dirname, 'agendamentos.json');

// Garante que o arquivo de agendamentos exista
const carregarAgendamentos = () => {
  try {
    if (!fs.existsSync(dbFilePath)) {
      fs.writeFileSync(dbFilePath, JSON.stringify([], null, 2), 'utf-8');
      return [];
    }
    const dados = fs.readFileSync(dbFilePath, 'utf-8');
    return dados ? JSON.parse(dados) : [];
  } catch (error) {
    console.error('Erro ao carregar banco de agendamentos:', error);
    return [];
  }
};

const salvarAgendamentos = (lista) => {
  try {
    fs.writeFileSync(dbFilePath, JSON.stringify(lista, null, 2), 'utf-8');
  } catch (error) {
    console.error('Erro ao persistir agendamentos no arquivo:', error);
  }
};

export const db = {
  // Cria um novo agendamento com status inicial 'pendente'
  async criar(agendamento) {
    const lista = carregarAgendamentos();
    const novo = {
      ...agendamento,
      status: agendamento.status || 'pendente', // 'pendente' | 'aprovado' | 'cancelado' | 'expirado'
      criado_em: new Date().toISOString(),
      atualizado_em: new Date().toISOString()
    };
    lista.push(novo);
    salvarAgendamentos(lista);
    return novo;
  },

  // Busca por ID do agendamento (UUID ou numérico)
  async buscarPorId(id) {
    const lista = carregarAgendamentos();
    return lista.find(item => String(item.id) === String(id)) || null;
  },

  // Busca por ID do pagamento ou intent do Mercado Pago
  async buscarPorPaymentId(paymentId) {
    const lista = carregarAgendamentos();
    return lista.find(item => String(item.mercado_pago_payment_id) === String(paymentId)) || null;
  },

  // Atualiza o status do agendamento e anexa dados da transação
  async atualizarStatus(id, novoStatus, detalhesPagamento = {}) {
    const lista = carregarAgendamentos();
    const index = lista.findIndex(item => String(item.id) === String(id));

    if (index === -1) return null;

    lista[index].status = novoStatus;
    lista[index].atualizado_em = new Date().toISOString();

    if (detalhesPagamento.paymentId) {
      lista[index].mercado_pago_payment_id = detalhesPagamento.paymentId;
    }
    if (detalhesPagamento.metodo) {
      lista[index].metodo_pagamento = detalhesPagamento.metodo;
    }
    if (detalhesPagamento.dadosExtras) {
      lista[index].detalhes_pagamento = {
        ...lista[index].detalhes_pagamento,
        ...detalhesPagamento.dadosExtras
      };
    }

    salvarAgendamentos(lista);
    return lista[index];
  },

  // Lista todos os agendamentos registrados
  async listar() {
    return carregarAgendamentos();
  }
};
