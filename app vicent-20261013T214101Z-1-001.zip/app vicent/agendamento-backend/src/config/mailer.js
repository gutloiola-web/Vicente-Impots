import nodemailer from 'nodemailer';
import dotenv from 'dotenv';

dotenv.config();

// Cria o transporte SMTP com as credenciais do .env
export const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST || 'smtp.gmail.com',
  port: parseInt(process.env.SMTP_PORT || '587', 10),
  secure: process.env.SMTP_SECURE === 'true', // true para porta 465, false para 587
  auth: {
    user: process.env.SMTP_USER || '',
    pass: process.env.SMTP_PASS || ''
  }
});

// Testa a conexão SMTP na inicialização (sem interromper o app em caso de credenciais não preenchidas)
export const verificarConexaoEmail = async () => {
  if (!process.env.SMTP_USER || process.env.SMTP_USER === 'seu-email@gmail.com') {
    console.log('ℹ️ [E-mail] Configurações SMTP pendentes no .env. Disparos de e-mail serão simulados no console.');
    return false;
  }

  try {
    await transporter.verify();
    console.log('✅ [E-mail] Servidor SMTP conectado e pronto para envios.');
    return true;
  } catch (error) {
    console.warn('⚠️ [E-mail] Aviso: Não foi possível conectar ao servidor SMTP:', error.message);
    return false;
  }
};
