import { MercadoPagoConfig, Payment } from 'mercadopago';
import dotenv from 'dotenv';

dotenv.config();

const accessToken = process.env.MERCADO_PAGO_ACCESS_TOKEN || '';

if (!accessToken || accessToken.startsWith('TEST-00000000')) {
  console.warn('⚠️ [Mercado Pago] Atenção: Configure seu MERCADO_PAGO_ACCESS_TOKEN no arquivo .env');
}

// Inicializa a configuração oficial do SDK v2 do Mercado Pago
export const client = new MercadoPagoConfig({
  accessToken: accessToken,
  options: {
    timeout: 7000
  }
});

// Instância de Payment para pagamentos Pix, Boleto e Cartão online
export const payment = new Payment(client);
