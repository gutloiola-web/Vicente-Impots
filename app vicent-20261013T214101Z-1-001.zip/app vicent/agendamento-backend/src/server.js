import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import apiRoutes from './routes/index.js';
import { verificarConexaoEmail } from './config/mailer.js';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;

// Middlewares Globais
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Log simples de requisições no console
app.use((req, res, next) => {
  const timestamp = new Date().toLocaleTimeString('pt-BR');
  console.log(`[${timestamp}] ${req.method} ${req.url}`);
  next();
});

// Rota de Healthcheck
app.get('/health', (req, res) => {
  res.json({
    status: 'ok',
    servico: 'API de Agendamento e Pagamentos',
    timestamp: new Date().toISOString()
  });
});

// Rota Inicial com Guia Rápido dos Endpoints
app.get('/', (req, res) => {
  res.json({
    projeto: 'Sistema de Agendamento com Mercado Pago & E-mail Automático',
    versao: '1.0.0',
    endpoints_principais: {
      agendamentos: {
        criar: 'POST /api/agendamentos',
        listar: 'GET /api/agendamentos',
        detalhar: 'GET /api/agendamentos/:id'
      },
      pagamentos: {
        gerar_pix: 'POST /api/pagamentos/pix',
        disparar_point: 'POST /api/pagamentos/point',
        listar_dispositivos: 'GET /api/pagamentos/point/dispositivos'
      },
      webhook: {
        notificacao_mercado_pago: 'POST /api/webhook/mercadopago'
      }
    }
  });
});

// Montagem das rotas da API
app.use('/api', apiRoutes);

// Tratamento de rota não encontrada (404)
app.use((req, res) => {
  res.status(404).json({
    sucesso: false,
    mensagem: `Rota ${req.method} ${req.originalUrl} não encontrada.`
  });
});

// Tratamento global de erros
app.use((err, req, res, next) => {
  console.error('❌ Erro não tratado na aplicação:', err);
  res.status(500).json({
    sucesso: false,
    mensagem: err.message || 'Erro interno no servidor.'
  });
});

// Inicia o servidor HTTP
app.listen(PORT, async () => {
  console.log('====================================================');
  console.log(`🚀 Servidor de Agendamentos rodando na porta ${PORT}`);
  console.log(`🔗 URL Base: http://localhost:${PORT}`);
  console.log(`🔔 Webhook URL: http://localhost:${PORT}/api/webhook/mercadopago`);
  console.log('====================================================');

  // Verifica a conexão SMTP
  await verificarConexaoEmail();
});
