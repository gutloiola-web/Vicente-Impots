import { Router } from 'express';
import { agendamentoController } from '../controllers/agendamentoController.js';

const router = Router();

// POST /api/agendamentos - Cria um agendamento com status pendente
router.post('/', agendamentoController.criar);

// GET /api/agendamentos - Lista todos os agendamentos
router.get('/', agendamentoController.listar);

// GET /api/agendamentos/:id - Consulta dados de um agendamento específico
router.get('/:id', agendamentoController.obterPorId);

export default router;
