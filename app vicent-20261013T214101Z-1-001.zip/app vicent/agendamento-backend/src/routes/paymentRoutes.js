import { Router } from 'express';
import { paymentController } from '../controllers/paymentController.js';

const router = Router();

// POST /api/pagamentos/pix - Gera o QR Code e código Copia e Cola via Pix
router.post('/pix', paymentController.pagarComPix);

// POST /api/pagamentos/point - Dispara cobrança para a Maquininha Point Física
router.post('/point', paymentController.pagarComPoint);

// GET /api/pagamentos/point/dispositivos - Lista as maquininhas Point disponíveis na conta
router.get('/point/dispositivos', paymentController.listarMaquininhas);

export default router;
