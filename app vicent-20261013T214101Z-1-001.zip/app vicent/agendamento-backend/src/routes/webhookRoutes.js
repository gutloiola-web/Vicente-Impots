import { Router } from 'express';
import { webhookController } from '../controllers/webhookController.js';

const router = Router();

// POST /api/webhook/mercadopago - Endpoint de notificação instantânea do Mercado Pago
router.post('/mercadopago', webhookController.handleMercadoPagoWebhook);

// GET /api/webhook/mercadopago - Suporte a verificações de ping do Mercado Pago
router.get('/mercadopago', (req, res) => {
  res.status(200).send('Webhook Mercado Pago Endpoint Ativo');
});

export default router;
