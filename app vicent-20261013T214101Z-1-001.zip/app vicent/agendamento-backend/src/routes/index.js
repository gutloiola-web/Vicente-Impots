import { Router } from 'express';
import agendamentoRoutes from './agendamentoRoutes.js';
import paymentRoutes from './paymentRoutes.js';
import webhookRoutes from './webhookRoutes.js';

const router = Router();

router.use('/agendamentos', agendamentoRoutes);
router.use('/pagamentos', paymentRoutes);
router.use('/webhook', webhookRoutes);

export default router;
