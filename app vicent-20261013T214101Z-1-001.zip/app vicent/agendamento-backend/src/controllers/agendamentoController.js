import { db } from '../db/database.js';
import { v4 as uuidv4 } from 'uuid';

export const agendamentoController = {
  /**
   * Registra um novo agendamento com status inicial 'pendente'
   */
  async criar(req, res) {
    try {
      const { cliente, servico, data, horario, valor, metodo_pagamento, observacoes } = req.body;

      // Validação básica dos campos obrigatórios
      if (!cliente || !cliente.nome || !cliente.email || !servico || !data || !horario || !valor) {
        return res.status(400).json({
          sucesso: false,
          mensagem: 'Campos obrigatórios: cliente (nome, email), servico, data, horario e valor.'
        });
      }

      // Valida formato de e-mail
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(cliente.email)) {
        return res.status(400).json({
          sucesso: false,
          mensagem: 'E-mail do cliente inválido.'
        });
      }

      const novoAgendamento = await db.criar({
        id: uuidv4().substring(0, 8).toUpperCase(), // ID limpo e amigável (ex: A3F89C12)
        cliente: {
          nome: cliente.nome.trim(),
          email: cliente.email.trim().toLowerCase(),
          telefone: cliente.telefone || ''
        },
        servico: servico.trim(),
        data: data.trim(),
        horario: horario.trim(),
        valor: Number(valor),
        metodo_pagamento: metodo_pagamento || 'pix', // 'pix' ou 'point'
        observacoes: observacoes || '',
        status: 'pendente'
      });

      return res.status(201).json({
        sucesso: true,
        mensagem: 'Agendamento criado com sucesso! Aguardando confirmação do pagamento.',
        agendamento: novoAgendamento
      });
    } catch (error) {
      console.error('Erro ao criar agendamento:', error);
      return res.status(500).json({
        sucesso: false,
        mensagem: 'Erro interno ao salvar agendamento.'
      });
    }
  },

  /**
   * Consulta os dados e o status de um agendamento pelo ID
   */
  async obterPorId(req, res) {
    try {
      const { id } = req.params;
      const agendamento = await db.buscarPorId(id);

      if (!agendamento) {
        return res.status(404).json({
          sucesso: false,
          mensagem: 'Agendamento não encontrado.'
        });
      }

      return res.json({
        sucesso: true,
        agendamento
      });
    } catch (error) {
      return res.status(500).json({
        sucesso: false,
        mensagem: 'Erro ao buscar agendamento.'
      });
    }
  },

  /**
   * Lista todos os agendamentos registrados no sistema
   */
  async listar(req, res) {
    try {
      const agendamentos = await db.listar();
      return res.json({
        sucesso: true,
        total: agendamentos.length,
        agendamentos
      });
    } catch (error) {
      return res.status(500).json({
        sucesso: false,
        mensagem: 'Erro ao listar agendamentos.'
      });
    }
  }
};
