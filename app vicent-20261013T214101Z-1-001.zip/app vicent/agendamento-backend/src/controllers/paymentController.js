import { db } from '../db/database.js';
import { paymentService } from '../services/paymentService.js';

export const paymentController = {
  /**
   * 1. Gera cobrança Pix para o agendamento
   * Retorna os códigos para exibição na tela do cliente (QR Code e Copia e Cola)
   */
  async pagarComPix(req, res) {
    try {
      const { agendamento_id } = req.body;

      if (!agendamento_id) {
        return res.status(400).json({
          sucesso: false,
          mensagem: 'O campo agendamento_id é obrigatório.'
        });
      }

      const agendamento = await db.buscarPorId(agendamento_id);
      if (!agendamento) {
        return res.status(404).json({
          sucesso: false,
          mensagem: 'Agendamento não encontrado.'
        });
      }

      if (agendamento.status === 'aprovado') {
        return res.status(400).json({
          sucesso: false,
          mensagem: 'Este agendamento já foi pago e aprovado!'
        });
      }

      // Gera o Pix no Mercado Pago
      const pixResultado = await paymentService.criarPagamentoPix({
        agendamentoId: agendamento.id,
        valor: agendamento.valor,
        descricao: `Agendamento: ${agendamento.servico} (${agendamento.data} ${agendamento.horario})`,
        cliente: agendamento.cliente
      });

      // Vincula o ID do pagamento do Mercado Pago ao agendamento
      await db.atualizarStatus(agendamento.id, 'pendente', {
        paymentId: pixResultado.payment_id,
        metodo: 'pix',
        dadosExtras: {
          pix_criado_em: pixResultado.criado_em
        }
      });

      return res.json({
        sucesso: true,
        mensagem: 'Cobrança Pix gerada com sucesso!',
        agendamento_id: agendamento.id,
        payment_id: pixResultado.payment_id,
        status: pixResultado.status,
        valor: pixResultado.valor,
        pix: {
          copia_e_cola: pixResultado.pix.qr_code,
          qr_code_base64: pixResultado.pix.qr_code_base64,
          ticket_url: pixResultado.pix.ticket_url
        }
      });
    } catch (error) {
      console.error('Erro na rota de Pix:', error);
      return res.status(500).json({
        sucesso: false,
        mensagem: error.message || 'Erro ao processar cobrança Pix.'
      });
    }
  },

  /**
   * 2. Dispara a cobrança para a Maquininha Point Física da Loja
   */
  async pagarComPoint(req, res) {
    try {
      const { agendamento_id, device_id } = req.body;

      if (!agendamento_id) {
        return res.status(400).json({
          sucesso: false,
          mensagem: 'O campo agendamento_id é obrigatório.'
        });
      }

      const agendamento = await db.buscarPorId(agendamento_id);
      if (!agendamento) {
        return res.status(404).json({
          sucesso: false,
          mensagem: 'Agendamento não encontrado.'
        });
      }

      if (agendamento.status === 'aprovado') {
        return res.status(400).json({
          sucesso: false,
          mensagem: 'Este agendamento já foi pago e aprovado!'
        });
      }

      // Dispara a cobrança para o terminal físico
      const resultadoPoint = await paymentService.criarCobrancaPoint({
        agendamentoId: agendamento.id,
        valor: agendamento.valor,
        deviceId: device_id
      });

      // Vincula o intent_id ao agendamento
      await db.atualizarStatus(agendamento.id, 'processando_terminal', {
        paymentId: resultadoPoint.intent_id,
        metodo: 'point',
        dadosExtras: {
          device_id: resultadoPoint.device_id,
          point_intent_id: resultadoPoint.intent_id
        }
      });

      return res.json({
        sucesso: true,
        mensagem: 'Cobrança enviada para a maquininha! O cliente pode inserir ou aproximar o cartão.',
        agendamento_id: agendamento.id,
        intent_id: resultadoPoint.intent_id,
        device_id: resultadoPoint.device_id,
        status: resultadoPoint.status,
        valor: resultadoPoint.amount
      });
    } catch (error) {
      console.error('Erro na rota de Maquininha Point:', error);
      return res.status(500).json({
        sucesso: false,
        mensagem: error.message || 'Erro ao enviar cobrança para a maquininha física.'
      });
    }
  },

  /**
   * 3. Rota auxiliar para listar maquininhas Point disponíveis na conta
   */
  async listarMaquininhas(req, res) {
    try {
      const maquininhas = await paymentService.listarDispositivosPoint();
      return res.json({
        sucesso: true,
        maquininhas
      });
    } catch (error) {
      return res.status(500).json({
        sucesso: false,
        mensagem: 'Falha ao consultar dispositivos Point.'
      });
    }
  }
};
