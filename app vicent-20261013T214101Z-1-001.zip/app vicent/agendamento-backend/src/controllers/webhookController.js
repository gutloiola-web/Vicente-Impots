import { paymentService } from '../services/paymentService.js';
import { emailService } from '../services/emailService.js';
import { db } from '../db/database.js';

export const webhookController = {
  /**
   * Endpoint oficial de Webhook do Mercado Pago
   * Escuta notificações em tempo real de pagamentos Pix e Point
   */
  async handleMercadoPagoWebhook(req, res) {
    // Responde HTTP 200 imediatamente para o Mercado Pago não reenviar a notificação
    res.status(200).json({ status: 'received' });

    try {
      const body = req.body || {};
      const query = req.query || {};

      console.log('🔔 [Webhook Mercado Pago Recebido]:', JSON.stringify({ body, query }));

      // Identifica o ID da transação (pode vir no body ou na query string)
      const paymentId = body.data?.id || query['data.id'] || query.id || body.id;
      const topic = body.type || body.topic || query.type || query.topic;

      // Se for notificação de pagamento ou atualização de pagamento
      if (topic === 'payment' || body.action?.startsWith('payment') || (!topic && paymentId)) {
        if (!paymentId) {
          console.warn('⚠️ [Webhook] Notificação de pagamento sem ID.');
          return;
        }

        console.log(`🔍 [Webhook] Consultando detalhes do pagamento #${paymentId} no Mercado Pago...`);
        const dadosPagamento = await paymentService.consultarPagamento(paymentId);

        const status = dadosPagamento.status; // 'approved' | 'pending' | 'in_process' | 'rejected' | 'cancelled'
        const agendamentoId = dadosPagamento.external_reference;

        console.log(`📊 [Webhook] Status do pagamento #${paymentId}: ${status} | Agendamento: #${agendamentoId}`);

        if (!agendamentoId) {
          console.warn(`⚠️ [Webhook] Pagamento #${paymentId} não possui external_reference (agendamento_id).`);
          return;
        }

        // Busca o agendamento no banco de dados
        const agendamento = await db.buscarPorId(agendamentoId);
        if (!agendamento) {
          console.error(`❌ [Webhook] Agendamento #${agendamentoId} não localizado no banco.`);
          return;
        }

        // 1. SE O PAGAMENTO FOI APROVADO ('approved')
        if (status === 'approved') {
          // Idempotência: Se já estava aprovado antes, evita disparar e-mail duplicado
          if (agendamento.status === 'aprovado') {
            console.log(`ℹ️ [Webhook] Agendamento #${agendamentoId} já estava aprovado. Ignorando reprocessamento.`);
            return;
          }

          // Atualiza o agendamento para aprovado no banco de dados
          const agendamentoAtualizado = await db.atualizarStatus(agendamentoId, 'aprovado', {
            paymentId: paymentId,
            metodo: dadosPagamento.payment_method_id || agendamento.metodo_pagamento,
            dadosExtras: {
              data_aprovacao: dadosPagamento.date_approved,
              valor_recebido: dadosPagamento.transaction_amount,
              metodo_tipo: dadosPagamento.payment_type_id
            }
          });

          console.log(`🎉 [Webhook] Agendamento #${agendamentoId} atualizado para 'aprovado' no banco de dados!`);

          // 2. DISPARO AUTOMÁTICO DO E-MAIL DE CONFIRMAÇÃO
          try {
            console.log(`✉️ [Webhook] Disparando e-mail de confirmação para ${agendamento.cliente.email}...`);
            await emailService.enviarConfirmacaoAgendamento({
              cliente: agendamento.cliente,
              agendamento: agendamentoAtualizado
            });
          } catch (emailError) {
            console.error(`⚠️ [Webhook] O agendamento foi aprovado, mas falhou ao enviar o e-mail:`, emailError.message);
          }

        } else if (status === 'cancelled' || status === 'rejected') {
          // Atualiza para cancelado caso a cobrança tenha sido rejeitada
          await db.atualizarStatus(agendamentoId, 'cancelado', {
            paymentId: paymentId
          });
          console.log(`⚠️ [Webhook] Agendamento #${agendamentoId} cancelado pelo Mercado Pago.`);
        }
      }
    } catch (error) {
      console.error('❌ [Webhook Erro de Processamento]:', error.message);
    }
  }
};
