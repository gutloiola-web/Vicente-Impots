# 📅 Backend de Agendamento com Mercado Pago (Pix & Point) e Disparo de E-mails

Sistema completo de backend desenvolvido em **Node.js (Express)** integrado à API oficial do **Mercado Pago** (pagamentos instantâneos via **Pix** e cobranças em **Maquininha física Point**) com **Webhook automatizado** para confirmação em tempo real e disparo de e-mails transacionais via **Nodemailer**.

---

## 🚀 Fluxo Completo da Aplicação

```mermaid
sequenceDiagram
    autonumber
    actor Cliente
    participant Frontend as Site / Frontend
    participant Backend as Backend Node.js
    participant MP as Mercado Pago API
    participant Point as Maquininha Point
    participant Email as Serviço de E-mail (SMTP)

    Cliente->>Frontend: Escolhe serviço, data e horário
    Frontend->>Backend: POST /api/agendamentos (Cria reserva pendente)
    Backend-->>Frontend: Retorna agendamento_id (#A3F89C12)

    alt Pagamento via Pix
        Frontend->>Backend: POST /api/pagamentos/pix { agendamento_id }
        Backend->>MP: Cria pagamento Pix (notification_url + external_reference)
        MP-->>Backend: Retorna QR Code (Base64) e Copia e Cola
        Backend-->>Frontend: Exibe QR Code na tela
        Cliente->>MP: Paga via aplicativo do banco
    else Pagamento via Maquininha (Point)
        Frontend->>Backend: POST /api/pagamentos/point { agendamento_id, device_id }
        Backend->>MP: Dispara intenção de pagamento no terminal Point
        MP->>Point: Acende a tela da maquininha com o valor
        Cliente->>Point: Insere ou aproxima o cartão e digita a senha
    end

    MP->>Backend: POST /api/webhook/mercadopago { type: "payment", data: { id: ... } }
    Backend->>MP: GET /v1/payments/{id} (Verifica autenticidade e status)
    MP-->>Backend: Status: "approved" | external_reference: "#A3F89C12"
    Backend->>Backend: Atualiza status do agendamento para "aprovado"
    Backend->>Email: Envia e-mail com detalhes da reserva e comprovante
    Email-->>Cliente: Cliente recebe e-mail de confirmação
```

---

## 📁 Estrutura de Arquivos

```
agendamento-backend/
├── package.json               # Dependências e scripts
├── .env.example               # Modelo de variáveis de ambiente
├── README.md                  # Documentação completa
└── src/
    ├── server.js              # Inicialização do Express, middlewares e rotas
    ├── config/
    │   ├── mercadopago.js     # Configuração do SDK v2 do Mercado Pago
    │   └── mailer.js          # Configuração do transporte SMTP (Nodemailer)
    ├── db/
    │   ├── database.js        # Camada de dados com persistência em JSON
    │   └── agendamentos.json  # Base de dados dos agendamentos
    ├── services/
    │   ├── paymentService.js  # Regras de negócio do Pix e Maquininha Point
    │   └── emailService.js    # Template HTML responsivo e disparo de e-mails
    ├── controllers/
    │   ├── agendamentoController.js # CRUD de agendamentos
    │   ├── paymentController.js     # Geração de Pix e ordens Point
    │   └── webhookController.js     # Recepção do webhook e gatilho de e-mail
    └── routes/
        ├── agendamentoRoutes.js
        ├── paymentRoutes.js
        ├── webhookRoutes.js
        └── index.js           # Agrupador central de rotas
```

---

## ⚙️ Instalação e Configuração

### 1. Instalar Dependências
```bash
cd agendamento-backend
npm install
```

### 2. Configurar Variáveis de Ambiente
Crie um arquivo `.env` na raiz do diretório `agendamento-backend/` copiando o modelo `.env.example`:

```ini
PORT=3000

# 1. Credenciais do Mercado Pago (https://www.mercadopago.com.br/developers/panel)
MERCADO_PAGO_ACCESS_TOKEN=APP_USR-seu_token_aqui

# 2. ID da Maquininha Point (opcional se usar apenas Pix)
MERCADO_PAGO_POINT_DEVICE_ID=GERTEC_MP35P_12345678

# 3. URL Pública para o Webhook receber as notificações (ex: ngrok)
WEBHOOK_BASE_URL=https://seu-dominio-ou-ngrok.ngrok-free.app

# 4. Configurações de E-mail (Gmail, SendGrid, Amazon SES, Mailtrap, etc.)
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_SECURE=false
SMTP_USER=seu-email@gmail.com
SMTP_PASS=sua-senha-de-app-16-digitos
SMTP_FROM="Agendamentos <seu-email@gmail.com>"
```

> **Dica para Gmail:** Para usar o Gmail como SMTP, acesse sua Conta Google > Segurança > **Senhas de App** e gere uma senha de 16 letras para o Nodemailer.

---

## 📡 Documentação das Rotas da API

### 1. Criar um Agendamento
- **Endpoint:** `POST /api/agendamentos`
- **Body (JSON):**
```json
{
  "cliente": {
    "nome": "Carlos Silva",
    "email": "carlos@exemplo.com",
    "telefone": "(27) 99999-8888"
  },
  "servico": "Corte de Cabelo & Barba",
  "data": "2026-09-25",
  "horario": "14:30",
  "valor": 75.00,
  "metodo_pagamento": "pix"
}
```
- **Resposta (201 Created):**
```json
{
  "sucesso": true,
  "mensagem": "Agendamento criado com sucesso! Aguardando confirmação do pagamento.",
  "agendamento": {
    "id": "A3F89C12",
    "status": "pendente",
    "cliente": { ... },
    "servico": "Corte de Cabelo & Barba",
    "valor": 75.00
  }
}
```

---

### 2. Gerar Cobrança Pix (QR Code + Copia e Cola)
- **Endpoint:** `POST /api/pagamentos/pix`
- **Body (JSON):**
```json
{
  "agendamento_id": "A3F89C12"
}
```
- **Resposta (200 OK):**
```json
{
  "sucesso": true,
  "agendamento_id": "A3F89C12",
  "payment_id": 1234567890,
  "status": "pending",
  "valor": 75.00,
  "pix": {
    "copia_e_cola": "00020126580014BR.GOV.BCB.PIX0136...",
    "qr_code_base64": "iVBORw0KGgoAAAANSUhEUgAA...",
    "ticket_url": "https://www.mercadopago.com.br/payments/1234567890/ticket"
  }
}
```

---

### 3. Disparar Cobrança para a Maquininha Física (Point)
- **Endpoint:** `POST /api/pagamentos/point`
- **Body (JSON):**
```json
{
  "agendamento_id": "A3F89C12",
  "device_id": "GERTEC_MP35P_12345678"
}
```
- **Resposta (200 OK):**
```json
{
  "sucesso": true,
  "mensagem": "Cobrança enviada para a maquininha! O cliente pode inserir ou aproximar o cartão.",
  "agendamento_id": "A3F89C12",
  "intent_id": "01234567-abcd-89ef-0123-abcdef012345",
  "device_id": "GERTEC_MP35P_12345678",
  "status": "OPEN",
  "valor": 75.00
}
```

---

### 4. Webhook do Mercado Pago (Confirmação Automática & Disparo de E-mail)
- **Endpoint:** `POST /api/webhook/mercadopago`
- **Comportamento:**
  1. O Mercado Pago envia a notificação quando o pagamento muda para `approved`.
  2. O backend responde `HTTP 200 { status: 'received' }` imediatamente.
  3. O backend consulta o Mercado Pago para confirmar a autenticidade do pagamento.
  4. O agendamento é alterado para `status: "aprovado"` no banco de dados.
  5. O `emailService` gera um layout HTML moderno e envia a confirmação para o e-mail do cliente com os detalhes da reserva.

---

## 🛠️ Como Testar Localmente com Webhook (ngrok)

1. Inicie o servidor:
```bash
npm run dev
```
2. Em outro terminal, exponha a porta 3000 para a internet com o [ngrok](https://ngrok.com/):
```bash
ngrok http 3000
```
3. Copie a URL gerada (ex: `https://abc123.ngrok-free.app`) e defina no seu `.env`:
```ini
WEBHOOK_BASE_URL=https://abc123.ngrok-free.app
```
4. Cadastre essa URL no painel do Mercado Pago:
   - Acesse **Mercado Pago Developers > Suas Aplicações > Notificações Webhooks**
   - Configure a URL: `https://abc123.ngrok-free.app/api/webhook/mercadopago`
   - Marque o evento **Pagamentos (Payments)**.
