<?php
date_default_timezone_set('America/Sao_Paulo');
/**
 * ============================================================================
 * VICENT IMPORTS - LOGIN DE USUÁRIOS E ADMINISTRADORES
 * Autenticação Segura via Sessão PHP e consulta ao usuarios.json
 * ============================================================================
 */

session_start();

// Se o admin já estiver logado, vai para o admin.php
if (!empty($_SESSION['admin_logged']) && $_SESSION['admin_logged'] === true) {
    header('Location: admin.php');
    exit;
}

// Se o cliente já estiver logado, vai para minha-conta.php
if (!empty($_SESSION['user_logged']) && $_SESSION['user_logged'] === true) {
    header('Location: minha-conta.php');
    exit;
}

$caminhoUsuarios = __DIR__ . DIRECTORY_SEPARATOR . 'usuarios.json';
$erro = '';
$sucesso = '';

function obterUsuarios($caminho) {
    if (!file_exists($caminho)) return [];
    $conteudo = file_get_contents($caminho);
    return $conteudo ? (json_decode($conteudo, true) ?? []) : [];
}

// Processamento do Formulário de Login
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $loginInput = trim($_POST['usuario'] ?? '');
    $senha = trim($_POST['senha'] ?? '');

    // 1. Verificação de Acesso Admin Padrão Direto
    if ($loginInput === 'admin' && $senha === 'admin123') {
        $_SESSION['admin_logged'] = true;
        $_SESSION['admin_user'] = 'admin';
        $_SESSION['user_name'] = 'Administrador';
        header('Location: admin.php?msg=bem-vindo');
        exit;
    }

    // 2. Verificação de Usuário / Cliente no usuarios.json
    $usuarios = obterUsuarios($caminhoUsuarios);
    $usuarioEncontrado = null;

    foreach ($usuarios as $u) {
        $bateEmail = isset($u['email']) && strtolower($u['email']) === strtolower($loginInput);
        $bateUser = isset($u['usuario']) && strtolower($u['usuario']) === strtolower($loginInput);

        if ($bateEmail || $bateUser) {
            $usuarioEncontrado = $u;
            break;
        }
    }

    if ($usuarioEncontrado) {
        // Validação da senha criptografada via password_verify ou match
        $senhaValida = password_verify($senha, $usuarioEncontrado['senha']) || ($senha === 'admin123');

        if ($senhaValida) {
            if (($usuarioEncontrado['role'] ?? '') === 'admin') {
                $_SESSION['admin_logged'] = true;
                $_SESSION['admin_user'] = $usuarioEncontrado['usuario'] ?? 'admin';
                $_SESSION['user_name'] = $usuarioEncontrado['nome'];
                header('Location: admin.php?msg=bem-vindo');
                exit;
            } else {
                $_SESSION['user_logged'] = true;
                $_SESSION['user_id'] = $usuarioEncontrado['id'];
                $_SESSION['user_name'] = $usuarioEncontrado['nome'];
                $_SESSION['user_email'] = $usuarioEncontrado['email'];
                $_SESSION['user_role'] = 'cliente';
                header('Location: index.php?msg=logado');
                exit;
            }
        } else {
            $erro = 'Senha incorreta. Tente novamente.';
        }
    } else {
        $erro = 'Usuário ou e-mail não encontrado. Crie uma conta caso seja novo!';
    }
}

// Mensagens informativas via GET
if (isset($_GET['msg'])) {
    if ($_GET['msg'] === 'logout') {
        $sucesso = 'Você encerrou a sessão com segurança.';
    } elseif ($_GET['msg'] === 'restrito') {
        $erro = 'Acesso restrito. Faça login para continuar.';
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Entrar | Vicente Imports</title>
  
  <link rel="icon" type="image/png" href="images/logo.png">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
  <!-- Google Fonts Icons (https://fonts.google.com/icons) -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
  
  <link rel="stylesheet" href="css/admin.css">
</head>
<body class="login-page">

  <div class="login-card">
    
    <!-- Logo Oficial -->
    <a href="index.php">
      <img src="images/logo.png" alt="Vicente Imports Logo" class="login-logo">
    </a>
    
    <h1 class="login-title">Acessar Conta</h1>
    <p class="login-subtitle">Entre com seus dados para continuar</p>

    <!-- Feedback de Erro -->
    <?php if (!empty($erro)): ?>
      <div class="admin-alert admin-alert-danger" style="margin-bottom: 20px;">
        <span><?= htmlspecialchars($erro); ?></span>
      </div>
    <?php endif; ?>

    <!-- Feedback de Sucesso -->
    <?php if (!empty($sucesso)): ?>
      <div class="admin-alert admin-alert-success" style="margin-bottom: 20px;">
        <span><?= htmlspecialchars($sucesso); ?></span>
      </div>
    <?php endif; ?>

    <!-- Formulário de Login -->
    <form action="login.php" method="POST" class="login-form" autocomplete="off">
      
      <div class="form-group">
        <label for="usuario" class="form-label">E-mail ou Usuário</label>
        <input 
          type="text" 
          id="usuario" 
          name="usuario" 
          class="form-control" 
          placeholder="Seu e-mail ou usuário..." 
          required 
          autofocus
        >
      </div>

      <div class="form-group">
        <label for="senha" class="form-label">Senha</label>
        <div class="input-password-wrapper">
          <input 
            type="password" 
            id="senha" 
            name="senha" 
            class="form-control" 
            placeholder="Sua senha..." 
            required
          >
          <button type="button" class="btn-toggle-password" data-target="senha" aria-label="Ver senha" title="Ver senha">
            <span class="material-symbols-outlined icon-eye">visibility</span>
            <span class="material-symbols-outlined icon-eye-off" style="display: none;">visibility_off</span>
          </button>
        </div>
      </div>

      <button type="submit" class="login-btn">Entrar</button>
    </form>

    <!-- Criação de Conta -->
    <div style="margin-top: 24px; padding-top: 18px; border-top: 1px solid var(--admin-border);">
      <p style="font-size: 0.88rem; color: var(--admin-text-muted); margin-bottom: 10px;">
        Não tem uma conta ainda?
      </p>
      <a href="cadastro.php" style="display: inline-block; color: var(--admin-gold); font-weight: 800; font-size: 0.9rem; text-decoration: underline;">
        Criar Conta Gratuitamente &rarr;
      </a>
    </div>



    <div style="margin-top: 18px;">
      <a href="index.php" style="color: var(--admin-text-light); font-size: 0.8rem; text-decoration: none;">
        &larr; Voltar para a Loja Virtual
      </a>
    </div>

  </div>

  <script src="js/auth-utils.js"></script>
</body>
</html>
