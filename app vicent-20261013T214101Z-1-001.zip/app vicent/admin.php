<?php
date_default_timezone_set('America/Sao_Paulo');
/**
 * ============================================================================
 * VICENT IMPORTS - PAINEL ADMINISTRATIVO (BACKOFFICE)
 * Gerenciamento de Produtos e Catálogo via produtos.json
 * ============================================================================
 */

session_start();

// 1. Verificação de Segurança (Controle de Acesso por Sessão)
if (empty($_SESSION['admin_logged']) || $_SESSION['admin_logged'] !== true) {
    header('Location: login.php?msg=restrito');
    exit;
}

$caminhoJson = __DIR__ . DIRECTORY_SEPARATOR . 'produtos.json';
$caminhoUsuarios = __DIR__ . DIRECTORY_SEPARATOR . 'usuarios.json';
$caminhoConfigPagamento = __DIR__ . DIRECTORY_SEPARATOR . 'config_pagamento.json';
$caminhoPedidos = __DIR__ . DIRECTORY_SEPARATOR . 'pedidos.json';
$pastaUploads = __DIR__ . DIRECTORY_SEPARATOR . 'images' . DIRECTORY_SEPARATOR . 'uploads';

// Garante que o diretório de uploads exista
if (!file_exists($pastaUploads)) {
    mkdir($pastaUploads, 0755, true);
}

/**
 * Função para carregar os produtos do arquivo JSON
 */
function carregarProdutos($caminho) {
    if (!file_exists($caminho)) {
        return [];
    }
    $conteudo = file_get_contents($caminho);
    $dados = json_decode($conteudo, true);
    return is_array($dados) ? $dados : [];
}

/**
 * Função para salvar os produtos no arquivo JSON
 */
function salvarProdutos($caminho, $produtos) {
    $json = json_encode(array_values($produtos), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    return file_put_contents($caminho, $json, LOCK_EX);
}

/**
 * Função para carregar os usuários do arquivo JSON
 */
function carregarUsuarios($caminho) {
    if (!file_exists($caminho)) {
        return [];
    }
    $conteudo = file_get_contents($caminho);
    $dados = json_decode($conteudo, true);
    return is_array($dados) ? $dados : [];
}

/**
 * Função para salvar os usuários no arquivo JSON
 */
function salvarUsuarios($caminho, $usuarios) {
    $json = json_encode(array_values($usuarios), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    return file_put_contents($caminho, $json, LOCK_EX);
}

/**
 * Funções para carregar e salvar configurações de pagamento
 */
function carregarConfigPagamento($caminho) {
    if (!file_exists($caminho)) return [];
    $conteudo = file_get_contents($caminho);
    return $conteudo ? (json_decode($conteudo, true) ?? []) : [];
}

function salvarConfigPagamento($caminho, $config) {
    $json = json_encode($config, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    return file_put_contents($caminho, $json, LOCK_EX);
}

/**
 * Funções para carregar e salvar pedidos da loja
 */
function carregarPedidos($caminho) {
    if (!file_exists($caminho)) return [];
    $conteudo = file_get_contents($caminho);
    return $conteudo ? (json_decode($conteudo, true) ?? []) : [];
}

function salvarPedidos($caminho, $pedidos) {
    $json = json_encode(array_values($pedidos), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    return file_put_contents($caminho, $json, LOCK_EX);
}

// Carrega os dados atuais
$produtos = carregarProdutos($caminhoJson);
$usuarios = carregarUsuarios($caminhoUsuarios);
$configPagamento = carregarConfigPagamento($caminhoConfigPagamento);
$pedidos = carregarPedidos($caminhoPedidos);
$mensagemAlerta = '';
$tipoAlerta = 'success';

// ============================================================================
// 2. PROCESSAMENTO DAS AÇÕES DO BACKEND (CRUD DE PRODUTOS E USUÁRIOS)
// ============================================================================

// --- AÇÃO: EXCLUIR PRODUTO (VIA GET) ---
if (isset($_GET['acao']) && $_GET['acao'] === 'excluir' && isset($_GET['id'])) {
    $idExcluir = intval($_GET['id']);
    $produtosFiltrados = [];
    $excluido = false;

    foreach ($produtos as $p) {
        if (intval($p['id']) === $idExcluir) {
            $excluido = true;
            continue; // Pula este item para remover
        }
        $produtosFiltrados[] = $p;
    }

    if ($excluido) {
        salvarProdutos($caminhoJson, $produtosFiltrados);
        header('Location: admin.php?msg=excluido');
        exit;
    }
}

// --- AÇÃO: ALTERNAR STATUS DE ESTOQUE (DISPONÍVEL / ESGOTADO) ---
if (isset($_GET['acao']) && $_GET['acao'] === 'alternar_esgotado' && isset($_GET['id'])) {
    $idAlternar = intval($_GET['id']);
    $alterado = false;

    foreach ($produtos as &$item) {
        if (intval($item['id']) === $idAlternar) {
            $item['esgotado'] = empty($item['esgotado']) ? true : false;
            $alterado = true;
            break;
        }
    }
    unset($item);

    if ($alterado) {
        salvarProdutos($caminhoJson, $produtos);
        header('Location: admin.php?msg=status_atualizado#tabela-produtos');
        exit;
    }
}

// --- AÇÃO: EXCLUIR USUÁRIO (VIA GET) ---
if (isset($_GET['acao']) && $_GET['acao'] === 'excluir_usuario' && isset($_GET['id'])) {
    $idExcluir = intval($_GET['id']);
    $usuariosAtualizados = [];
    $excluido = false;

    foreach ($usuarios as $u) {
        if (intval($u['id']) === $idExcluir) {
            // Protege a conta principal de administrador contra exclusão
            if (($u['usuario'] ?? '') === 'admin' || intval($u['id']) === 1) {
                header('Location: admin.php?msg=erro_admin_master#tabela-usuarios');
                exit;
            }
            $excluido = true;
            continue;
        }
        $usuariosAtualizados[] = $u;
    }

    if ($excluido) {
        salvarUsuarios($caminhoUsuarios, $usuariosAtualizados);
        header('Location: admin.php?msg=usuario_excluido#tabela-usuarios');
        exit;
    }
}


// --- AÇÃO: ADICIONAR OU EDITAR PRODUTO (VIA POST) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $acao = $_POST['acao'] ?? '';

    // Processamento de Galeria de Fotos (Até 4 Fotos: Frente, Costas, Detalhes, etc.)
    $galeria = [];
    $extensoesPermitidas = ['jpg', 'jpeg', 'png', 'webp', 'avif'];

    for ($i = 1; $i <= 4; $i++) {
        $fotoUrl = trim($_POST["imagem_url_$i"] ?? ($i === 1 ? ($_POST['imagem_url'] ?? '') : ''));
        $fotoExistente = trim($_POST["foto_existente_$i"] ?? '');
        $fileKey = "imagem_arquivo_$i";
        if ($i === 1 && !isset($_FILES[$fileKey]) && isset($_FILES['imagem_arquivo'])) {
            $fileKey = 'imagem_arquivo';
        }

        // 1. Se foi enviado um arquivo novo via upload
        if (isset($_FILES[$fileKey]) && $_FILES[$fileKey]['error'] === UPLOAD_ERR_OK) {
            $arquivo = $_FILES[$fileKey];
            $extensao = strtolower(pathinfo($arquivo['name'], PATHINFO_EXTENSION));

            if (in_array($extensao, $extensoesPermitidas)) {
                $novoNomeArquivo = 'prod_' . time() . '_' . uniqid() . '.' . $extensao;
                $destino = $pastaUploads . DIRECTORY_SEPARATOR . $novoNomeArquivo;

                if (move_uploaded_file($arquivo['tmp_name'], $destino)) {
                    $fotoUrl = 'images/uploads/' . $novoNomeArquivo;
                }
            }
        } elseif (empty($fotoUrl) && !empty($fotoExistente)) {
            // 2. Se não enviou novo arquivo nem URL nova, preserva a foto que já estava cadastrada
            $fotoUrl = $fotoExistente;
        }

        if (!empty($fotoUrl)) {
            $galeria[] = $fotoUrl;
        }
    }

    $urlImagem = !empty($galeria) ? $galeria[0] : trim($_POST['imagem_url'] ?? '');

    // Tratamento de Preço (suporta 189,90 ou 189.90 ou R$ 1.200,50)
    $precoInput = trim($_POST['preco'] ?? '0');
    $precoLimpo = str_replace(['R$', ' '], '', $precoInput);
    if (strpos($precoLimpo, ',') !== false) {
        $precoLimpo = str_replace('.', '', $precoLimpo); // remove separador de milhar se houver
        $precoLimpo = str_replace(',', '.', $precoLimpo); // vírgula decimal vira ponto
    }
    $precoFloat = round(floatval($precoLimpo), 2);

    // Tratamento de Preço Antigo (opcional, ex: 130,00 ou 130.00 para exibir "De R$ 130,00 por R$ 100,00")
    $precoAntigoInput = trim($_POST['preco_antigo'] ?? '');
    $precoAntigoFloat = null;
    if (!empty($precoAntigoInput)) {
        $precoAntigoLimpo = str_replace(['R$', ' '], '', $precoAntigoInput);
        if (strpos($precoAntigoLimpo, ',') !== false) {
            $precoAntigoLimpo = str_replace('.', '', $precoAntigoLimpo);
            $precoAntigoLimpo = str_replace(',', '.', $precoAntigoLimpo);
        }
        $valAntigo = round(floatval($precoAntigoLimpo), 2);
        if ($valAntigo > 0) {
            $precoAntigoFloat = $valAntigo;
        }
    }

    // Tratamento dos Tamanhos (converte string "P, M, G" em array)
    $tamanhosString = trim($_POST['tamanhos'] ?? '');
    $tamanhosArray = array_map('trim', explode(',', $tamanhosString));
    $tamanhosArray = array_values(array_filter($tamanhosArray));

    // Fallback caso imagem esteja vazia no cadastro
    if (empty($urlImagem) && $acao === 'adicionar') {
        $urlImagem = 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=800&q=80';
        $galeria = [$urlImagem];
    } elseif (!empty($urlImagem) && empty($galeria)) {
        $galeria = [$urlImagem];
    }

    // --- CADASTRO DE NOVO PRODUTO ---
    if ($acao === 'adicionar') {
        $novoId = 1;
        if (!empty($produtos)) {
            $ids = array_column($produtos, 'id');
            $novoId = max($ids) + 1;
        }

        $esgotado = !empty($_POST['esgotado']) ? true : false;

        $novoProduto = [
            'id' => $novoId,
            'nome' => trim($_POST['nome'] ?? 'Novo Produto'),
            'categoria' => trim($_POST['categoria'] ?? 'Geral'),
            'preco' => $precoFloat,
            'preco_antigo' => $precoAntigoFloat,
            'tamanhos' => !empty($tamanhosArray) ? $tamanhosArray : ['Único'],
            'imagem' => $urlImagem,
            'galeria' => !empty($galeria) ? $galeria : [$urlImagem],
            'descricao' => trim($_POST['descricao'] ?? ''),
            'destaque' => trim($_POST['destaque'] ?? ''),
            'esgotado' => $esgotado
        ];

        $produtos[] = $novoProduto;
        salvarProdutos($caminhoJson, $produtos);
        header('Location: admin.php?msg=adicionado');
        exit;
    }

    // --- EDIÇÃO DE PRODUTO EXISTENTE ---
    if ($acao === 'editar') {
        $idEditar = intval($_POST['id'] ?? 0);
        $editado = false;

        foreach ($produtos as &$item) {
            if (intval($item['id']) === $idEditar) {
                $item['nome'] = trim($_POST['nome'] ?? $item['nome']);
                $item['categoria'] = trim($_POST['categoria'] ?? $item['categoria']);
                $item['preco'] = $precoFloat;
                $item['preco_antigo'] = $precoAntigoFloat;
                $item['tamanhos'] = !empty($tamanhosArray) ? $tamanhosArray : $item['tamanhos'];
                if (!empty($galeria)) {
                    $item['galeria'] = $galeria;
                    $item['imagem'] = $galeria[0];
                } elseif (!empty($urlImagem)) {
                    $item['imagem'] = $urlImagem;
                    $item['galeria'] = [$urlImagem];
                }
                $item['descricao'] = trim($_POST['descricao'] ?? $item['descricao']);
                $item['destaque'] = trim($_POST['destaque'] ?? $item['destaque']);
                $item['esgotado'] = !empty($_POST['esgotado']) ? true : false;
                $editado = true;
                break;
            }
        }
        unset($item);

        if ($editado) {
            salvarProdutos($caminhoJson, $produtos);
            header('Location: admin.php?msg=editado');
            exit;
        }
    }
}

// --- AÇÃO: SALVAR CONFIGURAÇÕES DE PAGAMENTO (VIA POST) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['acao']) && $_POST['acao'] === 'salvar_config_pagamento') {
    $mpToken = trim($_POST['mercado_pago_access_token'] ?? '');
    $mpPointId = trim($_POST['mercado_pago_point_device_id'] ?? '');
    $chavePixManual = trim($_POST['chave_pix_manual'] ?? '');
    $smtpHost = trim($_POST['smtp_host'] ?? 'smtp.gmail.com');
    $smtpPort = intval($_POST['smtp_port'] ?? 587);
    $smtpUser = trim($_POST['smtp_user'] ?? '');
    $smtpPass = trim($_POST['smtp_pass'] ?? '');
    $smtpFrom = trim($_POST['smtp_from'] ?? 'Vicent Imports <contato@vicentimports.com.br>');

    $configPagamento = [
        'mercado_pago_access_token' => $mpToken,
        'mercado_pago_point_device_id' => $mpPointId,
        'chave_pix_manual' => $chavePixManual,
        'smtp_host' => $smtpHost,
        'smtp_port' => $smtpPort,
        'smtp_user' => $smtpUser,
        'smtp_pass' => $smtpPass,
        'smtp_from' => $smtpFrom
    ];

    salvarConfigPagamento($caminhoConfigPagamento, $configPagamento);
    header('Location: admin.php?msg=config_salva#config-pagamentos');
    exit;
}

// --- AÇÃO: APROVAR PEDIDO MANUALMENTE (VIA GET) ---
if (isset($_GET['acao']) && $_GET['acao'] === 'aprovar_pedido' && isset($_GET['id'])) {
    $pedidoIdAprovar = trim($_GET['id']);
    $aprovou = false;
    $pedidoAprovadoObj = null;

    foreach ($pedidos as &$ped) {
        if ($ped['id'] === $pedidoIdAprovar) {
            $ped['status'] = 'aprovado';
            $ped['atualizado_em'] = date('Y-m-d H:i:s');
            $aprovou = true;
            $pedidoAprovadoObj = $ped;
            break;
        }
    }
    unset($ped);

    if ($aprovou) {
        salvarPedidos($caminhoPedidos, $pedidos);
        if ($pedidoAprovadoObj) {
            require_once __DIR__ . DIRECTORY_SEPARATOR . 'mailer.php';
            processarEmailsPedido($pedidoAprovadoObj, 'aprovado');
        }
        header('Location: admin.php?msg=pedido_aprovado#tabela-pedidos');
        exit;
    }
}

// --- AÇÃO: EXCLUIR PEDIDO (VIA GET) ---
if (isset($_GET['acao']) && $_GET['acao'] === 'excluir_pedido' && isset($_GET['id'])) {
    $pedidoIdExcluir = trim($_GET['id']);
    $pedidosFiltrados = array_filter($pedidos, function($ped) use ($pedidoIdExcluir) {
        return ($ped['id'] ?? '') !== $pedidoIdExcluir;
    });

    salvarPedidos($caminhoPedidos, $pedidosFiltrados);
    header('Location: admin.php?msg=pedido_excluido#tabela-pedidos');
    exit;
}

// --- API: TESTAR CONEXÃO MERCADO PAGO ---
if (isset($_GET['api']) && $_GET['api'] === 'testar_mp') {
    header('Content-Type: application/json; charset=UTF-8');
    $input = json_decode(file_get_contents('php://input'), true) ?? $_POST;
    $token = trim($input['token'] ?? ($_GET['token'] ?? ($configPagamento['mercado_pago_access_token'] ?? '')));
    if (empty($token)) {
        echo json_encode(['success' => false, 'message' => 'Nenhum Access Token informado para teste.']);
        exit;
    }

    $ch = curl_init('https://api.mercadopago.com/users/me');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Authorization: Bearer ' . $token]);
    curl_setopt($ch, CURLOPT_TIMEOUT, 6);
    $res = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($code !== 200) {
        $dataErr = json_decode($res, true);
        $msgErr = $dataErr['message'] ?? 'Token inválido ou não autorizado.';
        echo json_encode(['success' => false, 'code' => $code, 'message' => $msgErr]);
        exit;
    }

    $userData = json_decode($res, true);
    $isTestUser = !empty($userData['test_data']['test_user']);
    $email = $userData['email'] ?? '';
    $nickname = $userData['nickname'] ?? '';

    // Verifica se métodos de pagamento incluem pix
    $ch2 = curl_init('https://api.mercadopago.com/v1/payment_methods');
    curl_setopt($ch2, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch2, CURLOPT_HTTPHEADER, ['Authorization: Bearer ' . $token]);
    curl_setopt($ch2, CURLOPT_TIMEOUT, 6);
    $res2 = curl_exec($ch2);
    curl_close($ch2);

    $methods = json_decode($res2, true);
    $temPix = false;
    if (is_array($methods)) {
        foreach ($methods as $m) {
            if (($m['id'] ?? '') === 'pix') { $temPix = true; break; }
        }
    }

    echo json_encode([
        'success' => true,
        'user' => [
            'nickname' => $nickname,
            'email' => $email,
            'is_test_user' => $isTestUser,
            'pix_disponivel' => $temPix
        ]
    ]);
    exit;
}

// Feedback de Mensagens do Sistema
if (isset($_GET['msg'])) {
    switch ($_GET['msg']) {
        case 'bem-vindo':
            $mensagemAlerta = 'Sessão iniciada com sucesso. Bem-vindo ao Backoffice da Vicent Imports!';
            $tipoAlerta = 'success';
            break;
        case 'adicionado':
            $mensagemAlerta = 'Produto cadastrado e publicado com sucesso no produtos.json!';
            $tipoAlerta = 'success';
            break;
        case 'editado':
            $mensagemAlerta = 'Produto atualizado com sucesso no catálogo!';
            $tipoAlerta = 'success';
            break;
        case 'excluido':
            $mensagemAlerta = 'Produto removido do catálogo com sucesso!';
            $tipoAlerta = 'danger';
            break;
        case 'usuario_excluido':
            $mensagemAlerta = 'Conta de usuário excluída com sucesso do sistema!';
            $tipoAlerta = 'danger';
            break;
        case 'erro_admin_master':
            $mensagemAlerta = 'A conta principal de Administrador Master não pode ser removida por segurança.';
            $tipoAlerta = 'danger';
            break;
        case 'config_salva':
            $mensagemAlerta = 'Configurações de Pagamento (Mercado Pago & Pix) atualizadas com sucesso!';
            $tipoAlerta = 'success';
            break;
        case 'pedido_aprovado':
            $mensagemAlerta = 'Status do pedido atualizado para APROVADO com sucesso!';
            $tipoAlerta = 'success';
            break;
        case 'pedido_excluido':
            $mensagemAlerta = 'Registro do pedido excluído com sucesso do sistema!';
            $tipoAlerta = 'danger';
            break;
    }
}

// 3. Métricas para o Dashboard
$totalProdutos = count($produtos);
$todasCategorias = array_unique(array_column($produtos, 'categoria'));
$totalCategorias = count($todasCategorias);

$somaPrecos = 0;
$maiorPreco = 0;
foreach ($produtos as $p) {
    $precoVal = floatval($p['preco'] ?? 0);
    $somaPrecos += $precoVal;
    if ($precoVal > $maiorPreco) $maiorPreco = $precoVal;
}
$precoMedio = $totalProdutos > 0 ? ($somaPrecos / $totalProdutos) : 0;

$totalUsuarios = count($usuarios);
$totalClientes = 0;
foreach ($usuarios as $u) {
    if (($u['role'] ?? '') === 'cliente') {
        $totalClientes++;
    }
}
$totalAdmins = $totalUsuarios - $totalClientes;

// Métricas de Vendas e Pedidos
$totalPedidos = count($pedidos);
$pedidosAprovados = 0;
$faturamentoTotal = 0;
foreach ($pedidos as $ped) {
    if (($ped['status'] ?? '') === 'aprovado') {
        $pedidosAprovados++;
        $faturamentoTotal += floatval($ped['subtotal'] ?? 0);
    }
}

// Identifica o modo atual do Mercado Pago
$tokenAtual = trim($configPagamento['mercado_pago_access_token'] ?? '');
if (empty($tokenAtual)) {
    $modoPagamento = 'demo';
    $statusPagamentoTexto = 'Modo Demonstração (Sem Token)';
    $statusPagamentoCor = '#9ca3af';
} elseif (str_starts_with($tokenAtual, 'APP_USR-')) {
    $modoPagamento = 'producao';
    $statusPagamentoTexto = 'Produção (Recebendo Dinheiro Real)';
    $statusPagamentoCor = '#10b981';
} else {
    $modoPagamento = 'sandbox';
    $statusPagamentoTexto = 'Ambiente de Testes / Sandbox';
    $statusPagamentoCor = '#f59e0b';
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dashboard Backoffice | Vicent Imports</title>
  
  <link rel="icon" type="image/png" href="images/logo.png">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
  <!-- Google Fonts Icons (https://fonts.google.com/icons) -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
  
  <link rel="stylesheet" href="css/admin.css">
</head>
<body>

  <div class="admin-wrapper">

    <!-- Sidebar Lateral -->
    <aside class="admin-sidebar" id="admin-sidebar">
      
      <div class="sidebar-header">
        <img src="images/logo.png" alt="Vicent Imports Logo" class="sidebar-logo">
        <div class="sidebar-brand">
          <h2>Vicente Imports</h2>
          <span>Backoffice Admin</span>
        </div>
      </div>

      <nav class="sidebar-nav">
        <a href="admin.php" class="nav-item active">
          <span class="material-symbols-outlined">dashboard</span>
          <span>Dashboard</span>
        </a>
        <a href="#tabela-pedidos" class="nav-item">
          <span class="material-symbols-outlined">receipt_long</span>
          <span>Pedidos da Loja</span>
          <span class="sidebar-badge" style="background-color: #3b82f6;"><?= $totalPedidos; ?></span>
        </a>
        <a href="#config-pagamentos" class="nav-item">
          <span class="material-symbols-outlined">payments</span>
          <span>Configurar Pagamento</span>
        </a>
        <a href="#tabela-usuarios" class="nav-item">
          <span class="material-symbols-outlined">group</span>
          <span>Contas Cadastradas</span>
          <span class="sidebar-badge"><?= $totalUsuarios; ?></span>
        </a>
        <a href="#cadastro-form" class="nav-item">
          <span class="material-symbols-outlined">add_circle</span>
          <span>Adicionar Produto</span>
        </a>
        <a href="#tabela-produtos" class="nav-item">
          <span class="material-symbols-outlined">inventory_2</span>
          <span>Catálogo JSON</span>
        </a>
        <a href="index.php" target="_blank" class="nav-item">
          <span class="material-symbols-outlined">storefront</span>
          <span>Ver Loja ao Vivo</span>
        </a>
      </nav>

      <div class="sidebar-footer">
        <div class="user-profile-badge">
          <div class="user-info">
            <span class="user-name"><?= htmlspecialchars($_SESSION['admin_user'] ?? 'Administrador'); ?></span>
            <span class="user-role">Sessão Ativa</span>
          </div>
          <a href="logout.php" class="btn-logout" title="Sair do Painel">
            <span class="material-symbols-outlined">logout</span>
          </a>
        </div>
      </div>

    </aside>

    <!-- Área de Conteúdo Principal -->
    <main class="admin-main">
      
      <!-- Topbar -->
      <header class="admin-topbar">
        <div class="topbar-title">
          <h1>Painel Administrativo & Controle</h1>
        </div>
        <div class="topbar-actions">
          <a href="index.php" target="_blank" class="btn-view-store">
            <span class="material-symbols-outlined" style="font-size: 18px;">storefront</span>
            Abrir Vitrine
          </a>
          <a href="logout.php" class="btn-action-delete" style="text-decoration: none;">Sair</a>
        </div>
      </header>

      <!-- Conteúdo Interno -->
      <div class="admin-content">

        <!-- Banner de Mensagens / Alertas -->
        <?php if (!empty($mensagemAlerta)): ?>
          <div class="admin-alert admin-alert-<?= $tipoAlerta; ?>" id="flash-alert">
            <span><?= htmlspecialchars($mensagemAlerta); ?></span>
            <button type="button" class="admin-alert-close" onclick="this.parentElement.remove();">&times;</button>
          </div>
        <?php endif; ?>

        <!-- Cards de Métricas / Resumo -->
        <section class="metrics-grid">
          
          <div class="metric-card">
            <div class="metric-icon purple">
              <span class="material-symbols-outlined">receipt_long</span>
            </div>
            <div class="metric-data">
              <h3><?= $totalPedidos; ?></h3>
              <p>Pedidos Realizados (<?= $pedidosAprovados; ?> pagos)</p>
            </div>
          </div>

          <div class="metric-card">
            <div class="metric-icon green">
              <span class="material-symbols-outlined">attach_money</span>
            </div>
            <div class="metric-data">
              <h3>R$ <?= number_format($faturamentoTotal, 2, ',', '.'); ?></h3>
              <p>Faturamento Aprovado</p>
            </div>
          </div>

          <div class="metric-card">
            <div class="metric-icon gold">
              <span class="material-symbols-outlined">account_balance_wallet</span>
            </div>
            <div class="metric-data">
              <h3 style="font-size: 1rem; color: <?= $statusPagamentoCor; ?>; display: flex; align-items: center; gap: 6px;">
                <span style="display: inline-block; width: 10px; height: 10px; border-radius: 50%; background: <?= $statusPagamentoCor; ?>;"></span>
                <?= $modoPagamento === 'producao' ? 'Ao Vivo' : ($modoPagamento === 'sandbox' ? 'Testes' : 'Demonstração'); ?>
              </h3>
              <p>Mercado Pago Status</p>
            </div>
          </div>

          <div class="metric-card">
            <div class="metric-icon blue">
              <span class="material-symbols-outlined">checkroom</span>
            </div>
            <div class="metric-data">
              <h3><?= $totalProdutos; ?></h3>
              <p>Produtos no Catálogo</p>
            </div>
          </div>

        </section>

        <!-- Formulário: Adicionar Novo Produto -->
        <section class="admin-card" id="cadastro-form">
          <div class="card-header">
            <h2>Cadastrar Nova Roupa / Peça</h2>
          </div>
          <div class="card-body">
            <form action="admin.php" method="POST" enctype="multipart/form-data" class="admin-form" autocomplete="off">
              <input type="hidden" name="acao" value="adicionar">

              <div class="form-grid-2" style="margin-bottom: 16px;">
                <div class="form-group">
                  <label class="form-label" for="add-nome">Nome da Peça *</label>
                  <input type="text" id="add-nome" name="nome" class="form-control" placeholder="Ex: Camisa Linho Slim Fit" required>
                </div>

                <div class="form-group">
                  <label class="form-label" for="add-categoria">Categoria *</label>
                  <select id="add-categoria" name="categoria" class="form-control" required>
                    <option value="Camisetas">Camisetas</option>
                    <option value="Calças">Calças</option>
                    <option value="Bermudas">Bermudas</option>
                    <option value="Chinelos">Chinelos</option>
                    <option value="Cuecas">Cuecas</option>
                    <option value="Jaquetas">Jaquetas</option>
                    <option value="Acessórios">Acessórios</option>
                  </select>
                </div>
              </div>

              <div class="form-grid-2" style="margin-bottom: 16px;">
                <div class="form-group">
                  <label class="form-label" for="add-preco">Preço Atual / Por (R$) *</label>
                  <input type="text" id="add-preco" name="preco" class="form-control" placeholder="Ex: 100,00" required>
                </div>

                <div class="form-group">
                  <label class="form-label" for="add-preco-antigo">
                    Preço Antigo / De (R$) 
                    <span style="color: var(--admin-text-muted); font-size: 0.72rem; font-weight: normal;">(Opcional - ex: 130,00 para tag de desconto)</span>
                  </label>
                  <input type="text" id="add-preco-antigo" name="preco_antigo" class="form-control" placeholder="Ex: 130,00 (gera tag de desconto automática)">
                </div>
              </div>

              <div class="form-grid-3" style="margin-bottom: 16px;">

                <div class="form-group">
                  <label class="form-label" for="add-tamanhos">Tamanhos (separados por vírgula) *</label>
                  <input type="text" id="add-tamanhos" name="tamanhos" class="form-control" placeholder="Ex: P, M, G, GG ou 38, 40, 42" required>
                </div>

                <div class="form-group">
                  <label class="form-label" for="add-destaque">Badge de Destaque</label>
                  <input type="text" id="add-destaque" name="destaque" class="form-control" placeholder="Ex: Drop Novo, Mais Vendido, Exclusivo">
                </div>

                <div class="form-group">
                  <label class="form-label" for="add-descricao">Descrição Detalhada da Roupa</label>
                  <input type="text" id="add-descricao" name="descricao" class="form-control" placeholder="Tecido, corte, caimento ou detalhes especiais...">
                </div>

                <div class="form-group" style="grid-column: 1 / -1;">
                  <label style="display: flex; align-items: center; gap: 10px; cursor: pointer; background: rgba(239, 68, 68, 0.08); padding: 12px 16px; border-radius: 8px; border: 1px solid rgba(239, 68, 68, 0.25);">
                    <input type="checkbox" name="esgotado" id="add-esgotado" value="1" style="width: 18px; height: 18px; cursor: pointer; accent-color: #ef4444;">
                    <div>
                      <span style="font-weight: 700; color: #ef4444; font-size: 0.9rem;">Marcar esta peça como ESGOTADA</span>
                      <div style="font-size: 0.75rem; color: #cbd5e1;">Exibe selo de ESGOTADO na vitrine e desativa o botão de compra para os clientes</div>
                    </div>
                  </label>
                </div>

              </div>

              <!-- Seção de Galeria de Fotos (Até 4 Fotos) -->
              <div style="background: rgba(255, 255, 255, 0.02); border: 1px solid var(--admin-border); border-radius: 8px; padding: 18px; margin-bottom: 22px;">
                <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 14px; flex-wrap: wrap; gap: 8px;">
                  <div>
                    <h4 style="font-size: 0.95rem; font-weight: 700; color: #fff; margin: 0; display: flex; align-items: center; gap: 8px;">
                      <span class="material-symbols-outlined" style="font-size: 20px; color: var(--admin-gold);">photo_library</span>
                      Galeria de Fotos do Produto (Até 4 Fotos)
                    </h4>
                    <p style="font-size: 0.75rem; color: var(--admin-text-muted); margin: 3px 0 0 0;">Foto 1 é a foto de capa (frente). As demais servem para costas, tecido/detalhes ou lookbook.</p>
                  </div>
                </div>

                <div class="form-grid-2" style="gap: 14px;">
                  <!-- Foto 1 (Principal) -->
                  <div style="background: rgba(0,0,0,0.25); border: 1px dashed var(--admin-border); border-radius: 8px; padding: 12px;">
                    <label class="form-label" style="font-weight: 700; color: var(--admin-gold); margin-bottom: 6px; display: block;">Foto 1 (Principal / Frente) *</label>
                    <input type="text" name="imagem_url_1" id="add-imagem-1" class="form-control" placeholder="URL ou caminho da foto 1..." style="margin-bottom: 8px;">
                    <input type="file" name="imagem_arquivo_1" id="add-upload-1" class="form-control" accept="image/*">
                    <img id="add-preview-1" src="" alt="Preview 1" style="display: none; max-width: 100px; max-height: 80px; object-fit: cover; border-radius: 4px; margin-top: 8px; border: 1px solid var(--admin-border);">
                  </div>

                  <!-- Foto 2 (Costas) -->
                  <div style="background: rgba(0,0,0,0.25); border: 1px dashed var(--admin-border); border-radius: 8px; padding: 12px;">
                    <label class="form-label" style="font-weight: 700; color: #e5e7eb; margin-bottom: 6px; display: block;">Foto 2 (Costas / Ângulo 2)</label>
                    <input type="text" name="imagem_url_2" id="add-imagem-2" class="form-control" placeholder="URL ou caminho da foto 2..." style="margin-bottom: 8px;">
                    <input type="file" name="imagem_arquivo_2" id="add-upload-2" class="form-control" accept="image/*">
                    <img id="add-preview-2" src="" alt="Preview 2" style="display: none; max-width: 100px; max-height: 80px; object-fit: cover; border-radius: 4px; margin-top: 8px; border: 1px solid var(--admin-border);">
                  </div>

                  <!-- Foto 3 (Detalhes) -->
                  <div style="background: rgba(0,0,0,0.25); border: 1px dashed var(--admin-border); border-radius: 8px; padding: 12px;">
                    <label class="form-label" style="font-weight: 700; color: #e5e7eb; margin-bottom: 6px; display: block;">Foto 3 (Detalhes / Tecido / Logo)</label>
                    <input type="text" name="imagem_url_3" id="add-imagem-3" class="form-control" placeholder="URL ou caminho da foto 3..." style="margin-bottom: 8px;">
                    <input type="file" name="imagem_arquivo_3" id="add-upload-3" class="form-control" accept="image/*">
                    <img id="add-preview-3" src="" alt="Preview 3" style="display: none; max-width: 100px; max-height: 80px; object-fit: cover; border-radius: 4px; margin-top: 8px; border: 1px solid var(--admin-border);">
                  </div>

                  <!-- Foto 4 (Adicional) -->
                  <div style="background: rgba(0,0,0,0.25); border: 1px dashed var(--admin-border); border-radius: 8px; padding: 12px;">
                    <label class="form-label" style="font-weight: 700; color: #e5e7eb; margin-bottom: 6px; display: block;">Foto 4 (Lookbook / Embalagem)</label>
                    <input type="text" name="imagem_url_4" id="add-imagem-4" class="form-control" placeholder="URL ou caminho da foto 4..." style="margin-bottom: 8px;">
                    <input type="file" name="imagem_arquivo_4" id="add-upload-4" class="form-control" accept="image/*">
                    <img id="add-preview-4" src="" alt="Preview 4" style="display: none; max-width: 100px; max-height: 80px; object-fit: cover; border-radius: 4px; margin-top: 8px; border: 1px solid var(--admin-border);">
                  </div>
                </div>
              </div>

              <button type="submit" class="btn-submit">
                <span class="material-symbols-outlined" style="font-size: 19px;">check_circle</span>
                Cadastrar e Publicar Produto
              </button>

            </form>
          </div>
        </section>

        <!-- Tabela: Listagem dos Produtos do produtos.json -->
        <section class="admin-card" id="tabela-produtos">
          <div class="card-header">
            <h2>Tabela de Produtos Cadastrados (<?= $totalProdutos; ?>)</h2>
            <span style="font-size: 0.8rem; color: var(--admin-text-muted);">Banco de dados: <code>produtos.json</code></span>
          </div>

          <div class="table-responsive">
            <table class="admin-table">
              <thead>
                <tr>
                  <th>Foto</th>
                  <th>ID</th>
                  <th>Nome & Descrição</th>
                  <th>Categoria</th>
                  <th>Preço</th>
                  <th>Tamanhos</th>
                  <th>Status</th>
                  <th>Destaque</th>
                  <th style="text-align: right;">Ações</th>
                </tr>
              </thead>
              <tbody>
                <?php if (empty($produtos)): ?>
                  <tr>
                    <td colspan="8" style="text-align: center; padding: 30px; color: var(--admin-text-muted);">
                      Nenhum produto cadastrado no momento. Use o formulário acima para adicionar!
                    </td>
                  </tr>
                <?php else: ?>
                  <?php foreach ($produtos as $p): ?>
                    <tr>
                      <td>
                        <img src="<?= htmlspecialchars($p['imagem'] ?? ''); ?>" alt="<?= htmlspecialchars($p['nome'] ?? ''); ?>" class="product-thumb" onerror="this.src='images/logo.png';">
                      </td>
                      <td><strong>#<?= $p['id']; ?></strong></td>
                      <td>
                        <div style="font-weight: 700; color: #ffffff; margin-bottom: 2px;">
                          <?= htmlspecialchars($p['nome']); ?>
                        </div>
                        <div style="font-size: 0.78rem; color: var(--admin-text-muted); max-width: 320px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
                          <?= htmlspecialchars($p['descricao'] ?? 'Sem descrição'); ?>
                        </div>
                      </td>
                      <td>
                        <span class="badge-tag"><?= htmlspecialchars($p['categoria']); ?></span>
                      </td>
                      <td>
                        <?php if (!empty($p['preco_antigo']) && floatval($p['preco_antigo']) > floatval($p['preco'])): 
                          $descontoPct = round(((floatval($p['preco_antigo']) - floatval($p['preco'])) / floatval($p['preco_antigo'])) * 100);
                        ?>
                          <div style="display: flex; flex-direction: column;">
                            <span style="font-size: 0.72rem; color: #9ca3af; text-decoration: line-through;">
                              De R$ <?= number_format(floatval($p['preco_antigo']), 2, ',', '.'); ?>
                            </span>
                            <span class="table-price" style="color: #10b981; font-weight: 800;">
                              Por R$ <?= number_format(floatval($p['preco']), 2, ',', '.'); ?>
                            </span>
                            <span class="badge-tag" style="background: rgba(16, 185, 129, 0.15); color: #10b981; border: 1px solid rgba(16, 185, 129, 0.3); font-size: 0.65rem; width: fit-content; margin-top: 3px; font-weight: 800;">
                              -<?= $descontoPct; ?>% OFF
                            </span>
                          </div>
                        <?php else: ?>
                          <span class="table-price">
                            R$ <?= number_format(floatval($p['preco']), 2, ',', '.'); ?>
                          </span>
                        <?php endif; ?>
                      </td>
                      <td>
                        <div style="display: flex; gap: 4px; flex-wrap: wrap;">
                          <?php foreach (($p['tamanhos'] ?? []) as $tam): ?>
                            <span class="badge-tag" style="font-size: 0.65rem;"><?= htmlspecialchars($tam); ?></span>
                          <?php endforeach; ?>
                        </div>
                      </td>
                      <td>
                        <?php if (!empty($p['esgotado'])): ?>
                          <span class="badge-tag" style="background: rgba(239, 68, 68, 0.18); color: #ef4444; border: 1px solid rgba(239, 68, 68, 0.35); font-weight: 800; display: inline-flex; align-items: center; gap: 4px;">
                            <span class="material-symbols-outlined" style="font-size: 13px;">block</span>
                            ESGOTADO
                          </span>
                        <?php else: ?>
                          <span class="badge-tag" style="background: rgba(16, 185, 129, 0.12); color: #10b981; border: 1px solid rgba(16, 185, 129, 0.25); display: inline-flex; align-items: center; gap: 4px;">
                            <span class="material-symbols-outlined" style="font-size: 13px;">check_circle</span>
                            Em Estoque
                          </span>
                        <?php endif; ?>
                      </td>
                      <td>
                        <?php if (!empty($p['destaque'])): ?>
                          <span class="badge-tag highlight"><?= htmlspecialchars($p['destaque']); ?></span>
                        <?php else: ?>
                          <span style="color: var(--admin-text-light); font-size: 0.75rem;">—</span>
                        <?php endif; ?>
                      </td>
                      <td style="text-align: right;">
                        <div class="table-actions" style="justify-content: flex-end;">
                          <!-- Botão Alternar Esgotado / Disponível -->
                          <?php if (!empty($p['esgotado'])): ?>
                            <a 
                              href="admin.php?acao=alternar_esgotado&id=<?= $p['id']; ?>" 
                              class="btn-action-view"
                              style="color: #10b981; border-color: rgba(16, 185, 129, 0.3); padding: 4px 8px; font-size: 0.75rem;" 
                              title="Marcar como Disponível (em estoque)"
                            >
                              <span class="material-symbols-outlined" style="font-size: 15px;">check_circle</span>
                              Ativar
                            </a>
                          <?php else: ?>
                            <a 
                              href="admin.php?acao=alternar_esgotado&id=<?= $p['id']; ?>" 
                              class="btn-action-view"
                              style="color: #ef4444; border-color: rgba(239, 68, 68, 0.3); padding: 4px 8px; font-size: 0.75rem;" 
                              title="Marcar como Esgotado"
                            >
                              <span class="material-symbols-outlined" style="font-size: 15px;">block</span>
                              Esgotar
                            </a>
                          <?php endif; ?>

                          <!-- Botão Editar -->
                          <button 
                            type="button" 
                            class="btn-action-edit"
                            data-id="<?= $p['id']; ?>"
                            data-nome="<?= htmlspecialchars($p['nome']); ?>"
                            data-categoria="<?= htmlspecialchars($p['categoria']); ?>"
                            data-preco="<?= number_format(floatval($p['preco']), 2, ',', '.'); ?>"
                            data-preco-antigo="<?= !empty($p['preco_antigo']) ? number_format(floatval($p['preco_antigo']), 2, ',', '.') : ''; ?>"
                            data-tamanhos="<?= htmlspecialchars(implode(', ', $p['tamanhos'] ?? [])); ?>"
                            data-imagem="<?= htmlspecialchars($p['imagem']); ?>"
                            data-galeria="<?= htmlspecialchars(json_encode($p['galeria'] ?? [$p['imagem']])); ?>"
                            data-descricao="<?= htmlspecialchars($p['descricao'] ?? ''); ?>"
                            data-destaque="<?= htmlspecialchars($p['destaque'] ?? ''); ?>"
                            data-esgotado="<?= !empty($p['esgotado']) ? '1' : '0'; ?>"
                          >
                            <span class="material-symbols-outlined">edit</span>
                            Editar
                          </button>

                          <!-- Botão Excluir -->
                          <a 
                            href="admin.php?acao=excluir&id=<?= $p['id']; ?>" 
                            class="btn-action-delete"
                            data-nome="<?= htmlspecialchars($p['nome']); ?>"
                          >
                            <span class="material-symbols-outlined">delete</span>
                            Excluir
                          </a>
                        </div>
                      </td>
                    </tr>
                  <?php endforeach; ?>
                <?php endif; ?>
              </tbody>
            </table>
          </div>
        </section>

        <!-- Tabela: Listagem de Usuários e Clientes Cadastrados -->
        <section class="admin-card" id="tabela-usuarios">
          <div class="card-header" style="flex-wrap: wrap; gap: 12px;">
            <div>
              <h2>Contas Cadastradas no Sistema (<?= $totalUsuarios; ?>)</h2>
              <span style="font-size: 0.8rem; color: var(--admin-text-muted);">Usuários registrados em <code>usuarios.json</code> &bull; <?= $totalClientes; ?> cliente(s) e <?= $totalAdmins; ?> administrador(es)</span>
            </div>
            <div style="display: flex; align-items: center; gap: 10px;">
              <input 
                type="text" 
                id="filtro-usuarios" 
                class="form-control" 
                placeholder="🔍 Filtrar nome, e-mail..." 
                style="max-width: 250px; padding: 7px 14px; font-size: 0.82rem;"
              >
            </div>
          </div>

          <div class="table-responsive">
            <table class="admin-table" id="tabela-usuarios-lista">
              <thead>
                <tr>
                  <th>Usuário</th>
                  <th>ID</th>
                  <th>E-mail</th>
                  <th>Telefone / WhatsApp</th>
                  <th>Nível / Perfil</th>
                  <th>Data do Cadastro</th>
                  <th style="text-align: right;">Ações</th>
                </tr>
              </thead>
              <tbody>
                <?php if (empty($usuarios)): ?>
                  <tr>
                    <td colspan="7" style="text-align: center; padding: 30px; color: var(--admin-text-muted);">
                      Nenhum usuário cadastrado no momento.
                    </td>
                  </tr>
                <?php else: ?>
                  <?php foreach ($usuarios as $u): 
                    $isAdmin = ($u['role'] ?? '') === 'admin' || ($u['usuario'] ?? '') === 'admin';
                    $dataFormatada = !empty($u['data_cadastro']) ? date('d/m/Y \à\s H:i', strtotime($u['data_cadastro'])) : 'Data não informada';
                    $telRaw = preg_replace('/[^0-9]/', '', $u['telefone'] ?? '');
                  ?>
                    <tr class="user-row">
                      <td>
                        <div style="display: flex; align-items: center; gap: 12px;">
                          <div class="user-avatar-circle <?= $isAdmin ? 'admin-avatar' : ''; ?>">
                            <?= strtoupper(mb_substr($u['nome'] ?? 'U', 0, 1, 'UTF-8')); ?>
                          </div>
                          <div>
                            <div style="font-weight: 700; color: #ffffff; font-size: 0.92rem;">
                              <?= htmlspecialchars($u['nome'] ?? 'Sem Nome'); ?>
                            </div>
                            <?php if (!empty($u['usuario'])): ?>
                              <div style="font-size: 0.78rem; color: #cbd5e1;">
                                @<?= htmlspecialchars($u['usuario']); ?>
                              </div>
                            <?php endif; ?>
                          </div>
                        </div>
                      </td>
                      <td><strong>#<?= $u['id'] ?? '-'; ?></strong></td>
                      <td>
                        <a href="mailto:<?= htmlspecialchars($u['email'] ?? ''); ?>" style="color: var(--admin-primary); text-decoration: none; font-weight: 500;">
                          <?= htmlspecialchars($u['email'] ?? 'Sem e-mail'); ?>
                        </a>
                      </td>
                      <td>
                        <?php if (!empty($u['telefone'])): ?>
                          <div style="display: flex; align-items: center; gap: 8px;">
                            <span><?= htmlspecialchars($u['telefone']); ?></span>
                            <?php if (!empty($telRaw)): ?>
                              <a href="https://wa.me/55<?= $telRaw; ?>" target="_blank" title="Abrir WhatsApp com este cliente" style="color: #25d366; display: inline-flex; align-items: center;">
                                <svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor"><path d="M12.031 6.172c-3.181 0-5.767 2.586-5.768 5.766-.001 1.298.38 2.27 1.019 3.287l-.711 2.598 2.669-.699c.969.586 1.761.88 2.79.88 3.183 0 5.77-2.587 5.77-5.767 0-3.18-2.587-5.765-5.769-5.765zm3.385 8.169c-.143.402-.832.744-1.155.779-.323.036-.74.174-2.482-.544-1.742-.718-2.859-2.518-2.946-2.633-.087-.116-.708-.941-.708-1.793s.449-1.272.609-1.446c.159-.175.347-.218.463-.218.116 0 .232 0 .333.006.107.006.25.04.387.368.145.348.492 1.201.536 1.288.043.087.072.189.014.305-.058.116-.087.189-.174.29-.087.102-.183.228-.261.306-.087.087-.179.182-.077.356.102.175.452.746.969 1.207.666.594 1.228.778 1.402.865.174.087.276.073.378-.044.102-.116.435-.508.551-.682.116-.174.232-.145.392-.087.159.058 1.014.478 1.188.565.174.087.29.13.333.203.044.072.044.42-.099.822z"/></svg>
                              </a>
                            <?php endif; ?>
                          </div>
                        <?php else: ?>
                          <span style="color: var(--admin-text-light); font-size: 0.8rem;">Não informado</span>
                        <?php endif; ?>
                      </td>
                      <td>
                        <?php if ($isAdmin): ?>
                          <span class="badge-tag highlight" style="display: inline-flex; align-items: center; gap: 4px;">
                            <span class="material-symbols-outlined" style="font-size: 13px;">star</span>
                            Administrador
                          </span>
                        <?php else: ?>
                          <span class="badge-tag" style="background-color: rgba(16, 185, 129, 0.12); color: var(--admin-success); border-color: rgba(16, 185, 129, 0.25);">
                            Cliente
                          </span>
                        <?php endif; ?>
                      </td>
                      <td style="white-space: nowrap;">
                        <span style="font-size: 0.82rem; font-weight: 600; color: #f1f5f9;">
                          <?= htmlspecialchars($dataFormatada); ?>
                        </span>
                      </td>
                      <td style="text-align: right;">
                        <div class="table-actions" style="justify-content: flex-end;">
                          <button 
                            type="button" 
                            class="btn-action-view-user"
                            data-id="<?= htmlspecialchars($u['id'] ?? ''); ?>"
                            data-nome="<?= htmlspecialchars($u['nome'] ?? ''); ?>"
                            data-usuario="<?= htmlspecialchars($u['usuario'] ?? ''); ?>"
                            data-email="<?= htmlspecialchars($u['email'] ?? ''); ?>"
                            data-telefone="<?= htmlspecialchars($u['telefone'] ?? ''); ?>"
                            data-role="<?= htmlspecialchars($u['role'] ?? 'cliente'); ?>"
                            data-data="<?= htmlspecialchars($dataFormatada); ?>"
                            data-is-admin="<?= $isAdmin ? '1' : '0'; ?>"
                          >
                            <span class="material-symbols-outlined">visibility</span>
                            Ver Dados
                          </button>

                          <?php if (!$isAdmin && intval($u['id']) !== 1): ?>
                            <a 
                              href="admin.php?acao=excluir_usuario&id=<?= $u['id']; ?>" 
                              class="btn-action-delete-user"
                              data-nome="<?= htmlspecialchars($u['nome'] ?? 'este usuário'); ?>"
                            >
                              <span class="material-symbols-outlined">delete</span>
                              Excluir
                            </a>
                          <?php else: ?>
                            <span class="badge-tag" style="opacity: 0.6; cursor: not-allowed;" title="Conta de administrador principal protegida">Protegido</span>
                          <?php endif; ?>
                        </div>
                      </td>
                    </tr>
                  <?php endforeach; ?>
                <?php endif; ?>
              </tbody>
            </table>
          </div>
        </section>

        <!-- SEÇÃO: CONFIGURAÇÕES DE PAGAMENTO & MERCADO PAGO -->
        <section class="admin-card" id="config-pagamentos" style="border: 1px solid rgba(197, 155, 39, 0.3);">
          <div class="card-header" style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 12px; background: rgba(197, 155, 39, 0.05);">
            <div>
              <h2 style="display: flex; align-items: center; gap: 8px; color: var(--admin-gold); margin: 0;">
                <span class="material-symbols-outlined" style="font-size: 24px;">payments</span>
                Configurações de Pagamento (Mercado Pago & Pix)
              </h2>
              <p style="font-size: 0.8rem; color: var(--admin-text-muted); margin-top: 4px;">
                Defina suas credenciais para receber dinheiro de verdade diretamente na sua conta do Mercado Pago e banco.
              </p>
            </div>
            <div>
              <span style="display: inline-flex; align-items: center; gap: 6px; padding: 6px 14px; border-radius: 20px; font-size: 0.8rem; font-weight: 700; background: rgba(0,0,0,0.4); border: 1px solid <?= $statusPagamentoCor; ?>; color: <?= $statusPagamentoCor; ?>;">
                <span style="width: 8px; height: 8px; border-radius: 50%; background: <?= $statusPagamentoCor; ?>;"></span>
                <?= $statusPagamentoTexto; ?>
              </span>
            </div>
          </div>

          <div class="card-body">

            <!-- Tutorial Rápido de Obtenção das Credenciais -->
            <div style="background: rgba(59, 130, 246, 0.08); border: 1px solid rgba(59, 130, 246, 0.25); border-radius: 10px; padding: 16px; margin-bottom: 24px;">
              <h4 style="color: #60a5fa; font-size: 0.95rem; margin: 0 0 8px; display: flex; align-items: center; gap: 8px;">
                <span class="material-symbols-outlined">help</span>
                Como pegar seu Access Token de Produção no Mercado Pago em 3 passos:
              </h4>
              <ol style="margin: 0 0 0 20px; font-size: 0.85rem; color: #cbd5e1; line-height: 1.6;">
                <li>Acesse o portal oficial: <a href="https://www.mercadopago.com.br/developers/panel" target="_blank" rel="noopener" style="color: #93c5fd; font-weight: 700; text-decoration: underline;">mercadopago.com.br/developers/panel</a> e entre com sua conta da loja.</li>
                <li>Vá em <strong>"Suas integrações"</strong> &rarr; Crie uma aplicação (ex: <em>Loja Vicent Imports</em>) ou clique na existente.</li>
                <li>No menu esquerdo, clique em <strong>"Credenciais de Produção"</strong> &rarr; Copie o campo <strong>Access Token</strong> (começa com <code>APP_USR-</code>) e cole no campo abaixo!</li>
              </ol>
            </div>

            <form action="admin.php" method="POST" class="admin-form" autocomplete="off">
              <input type="hidden" name="acao" value="salvar_config_pagamento">

              <!-- Grupo 1: Mercado Pago Oficial -->
              <div style="background: rgba(0,0,0,0.2); border: 1px solid var(--admin-border); border-radius: 10px; padding: 18px; margin-bottom: 20px;">
                <h3 style="font-size: 0.95rem; color: #fff; margin: 0 0 14px; display: flex; align-items: center; gap: 8px;">
                  <span class="material-symbols-outlined" style="color: #00b495;">bolt</span>
                  API Oficial Mercado Pago (Pix Automático & Webhooks)
                </h3>

                <div class="form-group" style="margin-bottom: 16px;">
                  <label class="form-label" for="mp-access-token">
                    Access Token do Mercado Pago (Produção ou Teste)
                    <span style="font-size: 0.75rem; color: var(--admin-text-muted); font-weight: normal;">(ex: APP_USR-xxxxxxxxxxxxxxxxxxxxxxx)</span>
                  </label>
                  <div style="display: flex; gap: 8px; flex-wrap: wrap;">
                    <input 
                      type="password" 
                      id="mp-access-token" 
                      name="mercado_pago_access_token" 
                      class="form-control" 
                      value="<?= htmlspecialchars($configPagamento['mercado_pago_access_token'] ?? ''); ?>" 
                      placeholder="Cole aqui seu Access Token (APP_USR-...)"
                      style="flex: 1; min-width: 260px; font-family: monospace; font-size: 0.85rem;"
                    >
                    <button type="button" class="btn-action-view" onclick="const f = document.getElementById('mp-access-token'); f.type = f.type === 'password' ? 'text' : 'password';" title="Ver / Ocultar Token" style="padding: 0 14px;">
                      <span class="material-symbols-outlined">visibility</span>
                    </button>
                    <button type="button" id="btn-testar-mp-token" class="btn-action-view" style="background: rgba(59, 130, 246, 0.15); border-color: rgba(59, 130, 246, 0.4); color: #60a5fa; font-weight: 700; padding: 0 16px; display: flex; align-items: center; gap: 6px;">
                      <span class="material-symbols-outlined" style="font-size: 16px;">bolt</span>
                      Testar Conexão
                    </button>
                  </div>
                  <div id="mp-test-feedback" style="display: none; margin-top: 10px; padding: 12px 14px; border-radius: 8px; font-size: 0.82rem; line-height: 1.5;"></div>
                  <small style="color: var(--admin-text-muted); font-size: 0.75rem; margin-top: 4px; display: block;">
                    Com este token, o site gera QR Codes Pix oficiais do Banco Central com aprovação automática em segundos via Webhook.
                  </small>
                </div>

                <div class="form-grid-2">
                  <div class="form-group">
                    <label class="form-label" for="mp-chave-manual">
                      Chave Pix da Loja (Manual / Fallback)
                      <span style="font-size: 0.72rem; color: var(--admin-text-muted); font-weight: normal;">(Opcional)</span>
                    </label>
                    <input 
                      type="text" 
                      id="mp-chave-manual" 
                      name="chave_pix_manual" 
                      class="form-control" 
                      value="<?= htmlspecialchars($configPagamento['chave_pix_manual'] ?? ''); ?>" 
                      placeholder="Ex: seu-email@pix.com.br ou 27999999999 ou CNPJ"
                    >
                    <small style="color: var(--admin-text-muted); font-size: 0.72rem; margin-top: 4px; display: block;">
                      Utilizada caso você queira receber direto na sua chave Pix manual.
                    </small>
                  </div>

                  <div class="form-group">
                    <label class="form-label" for="mp-point-id">
                      ID da Maquininha Point Física (Mercado Pago)
                      <span style="font-size: 0.72rem; color: var(--admin-text-muted); font-weight: normal;">(Opcional)</span>
                    </label>
                    <input 
                      type="text" 
                      id="mp-point-id" 
                      name="mercado_pago_point_device_id" 
                      class="form-control" 
                      value="<?= htmlspecialchars($configPagamento['mercado_pago_point_device_id'] ?? ''); ?>" 
                      placeholder="Ex: GERTEC_MP35P_12345678 ou PAX_A910_XXXX"
                    >
                    <small style="color: var(--admin-text-muted); font-size: 0.72rem; margin-top: 4px; display: block;">
                      Identificador da maquininha da loja física para disparar pagamentos por aproximação/chip.
                    </small>
                  </div>
                </div>
              </div>

              <!-- Grupo 2: Notificações por E-mail (SMTP) -->
              <div style="background: rgba(0,0,0,0.2); border: 1px solid var(--admin-border); border-radius: 10px; padding: 18px; margin-bottom: 20px;">
                <h3 style="font-size: 0.95rem; color: #fff; margin: 0 0 14px; display: flex; align-items: center; gap: 8px;">
                  <span class="material-symbols-outlined" style="color: #3b82f6;">mail</span>
                  Disparo de E-mails de Confirmação de Pedido (SMTP)
                </h3>

                <div class="form-grid-3" style="margin-bottom: 14px;">
                  <div class="form-group">
                    <label class="form-label" for="smtp-host">Servidor SMTP</label>
                    <input type="text" id="smtp-host" name="smtp_host" class="form-control" value="<?= htmlspecialchars($configPagamento['smtp_host'] ?? 'smtp.gmail.com'); ?>">
                  </div>
                  <div class="form-group">
                    <label class="form-label" for="smtp-port">Porta SMTP</label>
                    <input type="number" id="smtp-port" name="smtp_port" class="form-control" value="<?= htmlspecialchars((string)($configPagamento['smtp_port'] ?? 587)); ?>">
                  </div>
                  <div class="form-group">
                    <label class="form-label" for="smtp-from">Nome do Remetente</label>
                    <input type="text" id="smtp-from" name="smtp_from" class="form-control" value="<?= htmlspecialchars($configPagamento['smtp_from'] ?? 'Vicent Imports <contato@vicentimports.com.br>'); ?>">
                  </div>
                </div>

                <div class="form-grid-2">
                  <div class="form-group">
                    <label class="form-label" for="smtp-user">E-mail de Envio (Gmail / Hostinger / etc.)</label>
                    <input type="email" id="smtp-user" name="smtp_user" class="form-control" value="<?= htmlspecialchars($configPagamento['smtp_user'] ?? ''); ?>" placeholder="seuemail@gmail.com">
                  </div>
                  <div class="form-group">
                    <label class="form-label" for="smtp-pass">
                      Senha de Aplicativo (16 dígitos)
                      <span style="font-size: 0.72rem; color: var(--admin-text-muted); font-weight: normal;">(Google App Password)</span>
                    </label>
                    <input type="password" id="smtp-pass" name="smtp_pass" class="form-control" value="<?= htmlspecialchars($configPagamento['smtp_pass'] ?? ''); ?>" placeholder="Senha de app gerada no Google">
                  </div>
                </div>
              </div>

              <button type="submit" class="btn-submit" style="background: linear-gradient(135deg, #c59b27, #e0b84c); color: #000; font-weight: 800;">
                <span class="material-symbols-outlined" style="font-size: 20px;">save</span>
                Salvar Configurações de Pagamento
              </button>
            </form>

          </div>
        </section>

        <!-- SEÇÃO: GESTÃO DE PEDIDOS RECEBIDOS -->
        <section class="admin-card" id="tabela-pedidos">
          <div class="card-header" style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 10px;">
            <div>
              <h2>Pedidos Realizados na Loja</h2>
              <p style="font-size: 0.8rem; color: var(--admin-text-muted); margin-top: 4px;">
                Total de <strong><?= count($pedidos); ?></strong> pedidos registrados no sistema.
              </p>
            </div>
            <div style="display: flex; gap: 8px;">
              <span class="badge-tag" style="background: rgba(16, 185, 129, 0.15); color: #10b981; border-color: rgba(16, 185, 129, 0.3);">
                <?= $pedidosAprovados; ?> Aprovados
              </span>
              <span class="badge-tag" style="background: rgba(245, 158, 11, 0.15); color: #f59e0b; border-color: rgba(245, 158, 11, 0.3);">
                <?= count($pedidos) - $pedidosAprovados; ?> Pendentes
              </span>
            </div>
          </div>

          <div class="card-body" style="padding: 0;">
            <table class="admin-table">
              <thead>
                <tr>
                  <th style="width: 110px;">ID Pedido</th>
                  <th style="width: 140px;">Data</th>
                  <th>Cliente & Contato</th>
                  <th>Itens Comprados</th>
                  <th style="width: 120px;">Total</th>
                  <th style="width: 130px;">Método</th>
                  <th style="width: 120px;">Status</th>
                  <th style="width: 130px; text-align: right;">Ações</th>
                </tr>
              </thead>
              <tbody>
                <?php if (empty($pedidos)): ?>
                  <tr>
                    <td colspan="8" style="text-align: center; padding: 40px 20px; color: var(--admin-text-muted);">
                      <span class="material-symbols-outlined" style="font-size: 40px; display: block; margin-bottom: 8px; color: #4b5563;">receipt_long</span>
                      Nenhum pedido foi realizado na loja ainda.
                    </td>
                  </tr>
                <?php else: ?>
                  <?php 
                  $pedidosOrdenados = array_reverse($pedidos);
                  foreach ($pedidosOrdenados as $p): 
                    $status = $p['status'] ?? 'pendente';
                    $isAprovado = $status === 'aprovado';
                    $clienteNome = htmlspecialchars($p['cliente']['nome'] ?? 'Cliente');
                    $clienteEmail = htmlspecialchars($p['cliente']['email'] ?? '-');
                    $clienteTel = htmlspecialchars($p['cliente']['telefone'] ?? '-');
                    $clienteEnd = htmlspecialchars($p['cliente']['endereco'] ?? 'Não informado');
                    $totalPedBRL = number_format(floatval($p['subtotal'] ?? 0), 2, ',', '.');
                    $metodoTxt = ($p['metodo_pagamento'] ?? '') === 'point' ? 'Cartão Point' : 'Pix Instantâneo';
                  ?>
                    <tr>
                      <td style="white-space: nowrap;">
                        <strong style="color: var(--admin-gold); font-family: monospace; font-size: 0.88rem; letter-spacing: 0.5px;">#<?= htmlspecialchars($p['id'] ?? ''); ?></strong>
                      </td>
                      <td style="white-space: nowrap;">
                        <?php 
                          $criadoEmRaw = $p['criado_em'] ?? '';
                          $timestampPed = !empty($criadoEmRaw) ? strtotime($criadoEmRaw) : false;
                          $dataPedFormatada = $timestampPed ? date('d/m/Y', $timestampPed) : '-';
                          $horaPedFormatada = $timestampPed ? date('H:i:s', $timestampPed) : '';
                        ?>
                        <div style="font-size: 0.85rem; font-weight: 600; color: #f1f5f9;">
                          <?= $dataPedFormatada; ?>
                        </div>
                        <div style="font-size: 0.75rem; color: #94a3b8; margin-top: 1px;">
                          <?= $horaPedFormatada; ?>
                        </div>
                      </td>
                      <td style="min-width: 260px;">
                        <strong style="color: #ffffff; font-size: 0.92rem; display: block;"><?= $clienteNome; ?></strong>
                        <div style="font-size: 0.78rem; color: #cbd5e1; margin-top: 2px;">
                          <span><?= $clienteEmail; ?></span> &bull; <span><?= $clienteTel; ?></span>
                        </div>
                        <div style="font-size: 0.82rem; color: #f8fafc; margin-top: 6px; background: rgba(255, 255, 255, 0.08); border: 1px solid rgba(255, 255, 255, 0.15); padding: 6px 10px; border-radius: 6px; border-left: 3px solid var(--admin-gold); line-height: 1.45; word-break: break-word;">
                          <span style="color: var(--admin-gold); font-weight: 700; margin-right: 4px;">📍</span><?= $clienteEnd; ?>
                        </div>
                      </td>
                      <td>
                        <div style="display: flex; flex-direction: column; gap: 4px;">
                          <?php foreach (($p['itens'] ?? []) as $it): ?>
                            <div style="font-size: 0.78rem; display: flex; align-items: center; gap: 6px;">
                              <span style="background: rgba(255,255,255,0.12); color: #ffffff; padding: 2px 6px; border-radius: 4px; font-weight: 700;">
                                <?= intval($it['qty'] ?? 1); ?>x
                              </span>
                              <span style="color: #f1f5f9; font-weight: 500;"><?= htmlspecialchars($it['nome'] ?? 'Item'); ?></span>
                              <span style="color: #94a3b8; font-size: 0.74rem;">(<?= htmlspecialchars($it['tamanho'] ?? '-'); ?>)</span>
                            </div>
                          <?php endforeach; ?>
                        </div>
                      </td>
                      <td>
                        <strong style="color: #fff;">R$ <?= $totalPedBRL; ?></strong>
                      </td>
                      <td>
                        <span class="badge-tag" style="font-size: 0.72rem;">
                          <?= $metodoTxt; ?>
                        </span>
                      </td>
                      <td>
                        <?php if ($isAprovado): ?>
                          <span class="badge-tag" style="background: rgba(16, 185, 129, 0.15); color: #10b981; border-color: rgba(16, 185, 129, 0.3); display: inline-flex; align-items: center; gap: 4px;">
                            <span class="material-symbols-outlined" style="font-size: 14px;">check_circle</span>
                            Aprovado
                          </span>
                        <?php else: ?>
                          <span class="badge-tag" style="background: rgba(245, 158, 11, 0.15); color: #f59e0b; border-color: rgba(245, 158, 11, 0.3); display: inline-flex; align-items: center; gap: 4px;">
                            <span class="material-symbols-outlined" style="font-size: 14px;">hourglass_top</span>
                            Pendente
                          </span>
                        <?php endif; ?>
                      </td>
                      <td style="text-align: right;">
                        <div class="table-actions" style="justify-content: flex-end;">
                          <?php if (!$isAprovado): ?>
                            <a 
                              href="admin.php?acao=aprovar_pedido&id=<?= urlencode($p['id']); ?>" 
                              class="btn-action-view" 
                              style="color: #10b981; border-color: rgba(16, 185, 129, 0.3); padding: 4px 8px; font-size: 0.75rem;" 
                              title="Marcar como Aprovado"
                              onclick="return confirm('Confirmar a aprovação deste pedido #<?= $p['id']; ?>?');"
                            >
                              <span class="material-symbols-outlined" style="font-size: 15px;">check</span>
                              Aprovar
                            </a>
                          <?php endif; ?>

                          <a 
                            href="admin.php?acao=excluir_pedido&id=<?= urlencode($p['id']); ?>" 
                            class="btn-action-delete-user" 
                            style="padding: 4px 8px;" 
                            title="Excluir Pedido"
                            onclick="return confirm('Deseja realmente remover o registro deste pedido?');"
                          >
                            <span class="material-symbols-outlined" style="font-size: 15px;">delete</span>
                          </a>
                        </div>
                      </td>
                    </tr>
                  <?php endforeach; ?>
                <?php endif; ?>
              </tbody>
            </table>
          </div>
        </section>

      </div>

    </main>

  </div>

  <!-- Modal de Edição de Produto -->
  <div class="admin-modal-overlay" id="edit-modal-overlay">
    <div class="admin-modal">
      <div class="modal-header">
        <h3>Editar Produto Cadastrado</h3>
        <button type="button" class="modal-close" id="btn-close-modal">&times;</button>
      </div>

      <form action="admin.php" method="POST" enctype="multipart/form-data">
        <input type="hidden" name="acao" value="editar">
        <input type="hidden" name="id" id="edit-id">

        <div class="modal-body">
          
          <div class="form-group">
            <label class="form-label" for="edit-nome">Nome do Produto</label>
            <input type="text" name="nome" id="edit-nome" class="form-control" required>
          </div>

          <div class="form-grid-2">
            <div class="form-group">
              <label class="form-label" for="edit-categoria">Categoria</label>
              <select name="categoria" id="edit-categoria" class="form-control" required>
                <option value="Camisetas">Camisetas</option>
                <option value="Calças">Calças</option>
                <option value="Bermudas">Bermudas</option>
                <option value="Chinelos">Chinelos</option>
                <option value="Cuecas">Cuecas</option>
                <option value="Jaquetas">Jaquetas</option>
                <option value="Acessórios">Acessórios</option>
              </select>
            </div>

            <div class="form-group">
              <label class="form-label" for="edit-destaque">Selo de Destaque</label>
              <input type="text" name="destaque" id="edit-destaque" class="form-control" placeholder="Ex: Drop Novo, Mais Vendido">
            </div>
          </div>

          <div class="form-grid-2">
            <div class="form-group">
              <label class="form-label" for="edit-preco">Preço Atual / Por (R$) *</label>
              <input type="text" name="preco" id="edit-preco" class="form-control" required>
            </div>

            <div class="form-group">
              <label class="form-label" for="edit-preco-antigo">
                Preço Antigo / De (R$) 
                <span style="font-size: 0.72rem; color: var(--admin-text-muted); font-weight: normal;">(Opcional - ex: 130,00)</span>
              </label>
              <input type="text" name="preco_antigo" id="edit-preco-antigo" class="form-control" placeholder="Ex: 130,00 (tag de desconto)">
            </div>
          </div>

          <div class="form-group">
            <label class="form-label" for="edit-tamanhos">Tamanhos (separados por vírgula)</label>
            <input type="text" name="tamanhos" id="edit-tamanhos" class="form-control" required>
          </div>

          <!-- Galeria de Fotos no Modal de Edição (Até 4 fotos) -->
          <div style="background: rgba(255,255,255,0.02); border: 1px solid var(--admin-border); border-radius: 8px; padding: 14px; margin-bottom: 16px;">
            <label class="form-label" style="font-weight: 700; color: #fff; margin-bottom: 8px; display: flex; align-items: center; gap: 6px;">
              <span class="material-symbols-outlined" style="font-size: 18px; color: var(--admin-gold);">photo_library</span>
              Galeria de Fotos (Até 4 Fotos)
            </label>
            <p style="font-size: 0.75rem; color: var(--admin-text-muted); margin-bottom: 12px;">Preencha a URL ou envie novos arquivos para atualizar as fotos da peça.</p>

            <div class="form-grid-2" style="gap: 12px;">
              <!-- Foto 1 -->
              <div style="background: rgba(0,0,0,0.2); border: 1px dashed var(--admin-border); border-radius: 6px; padding: 10px;">
                <label class="form-label" style="font-size: 0.75rem; color: var(--admin-gold); margin-bottom: 4px; display: block;">Foto 1 (Principal)</label>
                <input type="hidden" name="foto_existente_1" id="edit-foto-existente-1">
                <input type="text" name="imagem_url_1" id="edit-imagem-1" class="form-control" placeholder="URL ou caminho da foto 1..." style="margin-bottom: 6px;">
                <input type="file" name="imagem_arquivo_1" id="edit-upload-1" class="form-control" accept="image/*">
                <img id="edit-preview-1" src="" alt="Preview 1" style="display: none; max-width: 80px; max-height: 60px; object-fit: cover; border-radius: 4px; margin-top: 6px; border: 1px solid var(--admin-border);">
              </div>

              <!-- Foto 2 -->
              <div style="background: rgba(0,0,0,0.2); border: 1px dashed var(--admin-border); border-radius: 6px; padding: 10px;">
                <label class="form-label" style="font-size: 0.75rem; color: #e5e7eb; margin-bottom: 4px; display: block;">Foto 2 (Costas)</label>
                <input type="hidden" name="foto_existente_2" id="edit-foto-existente-2">
                <input type="text" name="imagem_url_2" id="edit-imagem-2" class="form-control" placeholder="URL ou caminho da foto 2..." style="margin-bottom: 6px;">
                <input type="file" name="imagem_arquivo_2" id="edit-upload-2" class="form-control" accept="image/*">
                <img id="edit-preview-2" src="" alt="Preview 2" style="display: none; max-width: 80px; max-height: 60px; object-fit: cover; border-radius: 4px; margin-top: 6px; border: 1px solid var(--admin-border);">
              </div>

              <!-- Foto 3 -->
              <div style="background: rgba(0,0,0,0.2); border: 1px dashed var(--admin-border); border-radius: 6px; padding: 10px;">
                <label class="form-label" style="font-size: 0.75rem; color: #e5e7eb; margin-bottom: 4px; display: block;">Foto 3 (Detalhes / Tecido)</label>
                <input type="hidden" name="foto_existente_3" id="edit-foto-existente-3">
                <input type="text" name="imagem_url_3" id="edit-imagem-3" class="form-control" placeholder="URL ou caminho da foto 3..." style="margin-bottom: 6px;">
                <input type="file" name="imagem_arquivo_3" id="edit-upload-3" class="form-control" accept="image/*">
                <img id="edit-preview-3" src="" alt="Preview 3" style="display: none; max-width: 80px; max-height: 60px; object-fit: cover; border-radius: 4px; margin-top: 6px; border: 1px solid var(--admin-border);">
              </div>

              <!-- Foto 4 -->
              <div style="background: rgba(0,0,0,0.2); border: 1px dashed var(--admin-border); border-radius: 6px; padding: 10px;">
                <label class="form-label" style="font-size: 0.75rem; color: #e5e7eb; margin-bottom: 4px; display: block;">Foto 4 (Outro Ângulo)</label>
                <input type="hidden" name="foto_existente_4" id="edit-foto-existente-4">
                <input type="text" name="imagem_url_4" id="edit-imagem-4" class="form-control" placeholder="URL ou caminho da foto 4..." style="margin-bottom: 6px;">
                <input type="file" name="imagem_arquivo_4" id="edit-upload-4" class="form-control" accept="image/*">
                <img id="edit-preview-4" src="" alt="Preview 4" style="display: none; max-width: 80px; max-height: 60px; object-fit: cover; border-radius: 4px; margin-top: 6px; border: 1px solid var(--admin-border);">
              </div>
            </div>
          </div>

          <div class="form-group">
            <label class="form-label" for="edit-descricao">Descrição</label>
            <textarea name="descricao" id="edit-descricao" rows="3" class="form-control" style="resize: vertical;"></textarea>
          </div>

          <div class="form-group">
            <label style="display: flex; align-items: center; gap: 10px; cursor: pointer; background: rgba(239, 68, 68, 0.08); padding: 12px 16px; border-radius: 8px; border: 1px solid rgba(239, 68, 68, 0.25);">
              <input type="checkbox" name="esgotado" id="edit-esgotado" value="1" style="width: 18px; height: 18px; cursor: pointer; accent-color: #ef4444;">
              <div>
                <span style="font-weight: 700; color: #ef4444; font-size: 0.9rem;">Marcar esta peça como ESGOTADA</span>
                <div style="font-size: 0.75rem; color: #cbd5e1;">Exibe selo de ESGOTADO na vitrine e desativa o botão de compra para os clientes</div>
              </div>
            </label>
          </div>

        </div>

        <div class="modal-footer">
          <button type="button" class="btn-cancel" id="btn-cancel-modal">Cancelar</button>
          <button type="submit" class="btn-submit">Salvar Alterações</button>
        </div>
      </form>
    </div>
  </div>

  <!-- Modal de Detalhes / Ficha Cadastral do Usuário -->
  <div class="admin-modal-overlay" id="user-modal-overlay">
    <div class="admin-modal user-details-modal">
      <div class="modal-header">
        <div style="display: flex; align-items: center; gap: 10px;">
          <div class="modal-header-icon">
            <span class="material-symbols-outlined" style="font-size: 22px;">badge</span>
          </div>
          <div>
            <h3>Ficha Cadastral do Usuário</h3>
            <span style="font-size: 0.75rem; color: var(--admin-text-muted);">Informações detalhadas da conta registrada</span>
          </div>
        </div>
        <button type="button" class="modal-close" id="btn-close-user-modal">&times;</button>
      </div>

      <div class="modal-body">
        <!-- Perfil Principal com Avatar -->
        <div class="user-modal-profile">
          <div class="user-avatar-circle modal-large-avatar" id="modal-user-avatar">U</div>
          <div class="user-modal-profile-info">
            <div style="display: flex; align-items: center; gap: 8px; flex-wrap: wrap;">
              <h2 id="modal-user-nome" style="font-size: 1.25rem; font-weight: 800; color: #ffffff;">Nome do Usuário</h2>
              <span id="modal-user-badge" class="badge-tag">Cliente</span>
            </div>
            <p id="modal-user-username" style="font-size: 0.85rem; color: var(--admin-text-muted); margin-top: 2px;">@usuario</p>
          </div>
        </div>

        <!-- Grade com Dados do Usuário -->
        <div class="user-details-grid">
          <div class="user-detail-card">
            <span class="detail-label">ID do Sistema</span>
            <span class="detail-value" id="modal-user-id">#0</span>
          </div>

          <div class="user-detail-card">
            <span class="detail-label">Nível de Acesso</span>
            <span class="detail-value" id="modal-user-role">Cliente</span>
          </div>

          <div class="user-detail-card full-width">
            <div style="display: flex; justify-content: space-between; align-items: center;">
              <span class="detail-label">Endereço de E-mail</span>
              <button type="button" class="btn-copy-field" id="btn-copy-email" title="Copiar e-mail">
                <span class="material-symbols-outlined">content_copy</span>
                <span class="copy-text">Copiar</span>
              </button>
            </div>
            <a href="#" id="modal-user-email-link" class="detail-value highlight-link" target="_blank">email@exemplo.com</a>
          </div>

          <div class="user-detail-card full-width">
            <div style="display: flex; justify-content: space-between; align-items: center;">
              <span class="detail-label">WhatsApp / Telefone</span>
              <button type="button" class="btn-copy-field" id="btn-copy-tel" title="Copiar telefone">
                <span class="material-symbols-outlined">content_copy</span>
                <span class="copy-text">Copiar</span>
              </button>
            </div>
            <div style="display: flex; align-items: center; justify-content: space-between; gap: 8px; margin-top: 4px;">
              <span class="detail-value" id="modal-user-telefone">Não informado</span>
            </div>
          </div>

          <div class="user-detail-card">
            <span class="detail-label">Data e Hora de Cadastro</span>
            <span class="detail-value" id="modal-user-data">--/--/----</span>
          </div>

          <div class="user-detail-card">
            <span class="detail-label">Status da Conta</span>
            <span class="detail-value" style="color: var(--admin-success); display: inline-flex; align-items: center; gap: 6px;">
              <span style="width: 8px; height: 8px; border-radius: 50%; background-color: var(--admin-success); display: inline-block;"></span>
              Ativa no Sistema
            </span>
          </div>

          <div class="user-detail-card full-width">
            <span class="detail-label">Segurança & Criptografia</span>
            <div style="font-size: 0.82rem; color: var(--admin-text-muted); display: flex; align-items: center; gap: 8px; margin-top: 4px;">
              <span class="material-symbols-outlined" style="font-size: 16px; color: var(--admin-gold);">lock</span>
              <span>Senha armazenada com hash criptográfico seguro (Bcrypt)</span>
            </div>
          </div>
        </div>
      </div>

      <div class="modal-footer" style="justify-content: space-between;">
        <div style="display: flex; gap: 8px;">
          <a href="#" id="modal-btn-whatsapp" target="_blank" class="btn-whatsapp-action" style="display: none;">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M12.031 6.172c-3.181 0-5.767 2.586-5.768 5.766-.001 1.298.38 2.27 1.019 3.287l-.711 2.598 2.669-.699c.969.586 1.761.88 2.79.88 3.183 0 5.77-2.587 5.77-5.767 0-3.18-2.587-5.765-5.769-5.765zm3.385 8.169c-.143.402-.832.744-1.155.779-.323.036-.74.174-2.482-.544-1.742-.718-2.859-2.518-2.946-2.633-.087-.116-.708-.941-.708-1.793s.449-1.272.609-1.446c.159-.175.347-.218.463-.218.116 0 .232 0 .333.006.107.006.25.04.387.368.145.348.492 1.201.536 1.288.043.087.072.189.014.305-.058.116-.087.189-.174.29-.087.102-.183.228-.261.306-.087.087-.179.182-.077.356.102.175.452.746.969 1.207.666.594 1.228.778 1.402.865.174.087.29.13.333.203.044.072.044.42-.099.822z"/></svg>
            Chamar no WhatsApp
          </a>
          <a href="#" id="modal-btn-email" class="btn-email-action">
            <span class="material-symbols-outlined" style="font-size: 16px;">mail</span>
            Enviar E-mail
          </a>
        </div>
        <button type="button" class="btn-cancel" id="btn-cancel-user-modal">Fechar</button>
      </div>
    </div>
  </div>

  <script src="js/admin.js"></script>
</body>
</html>
